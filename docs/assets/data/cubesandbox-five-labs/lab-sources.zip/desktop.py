from lab import *
with ExitStack() as st:
 cfg=endpoint(st);s=vm(cfg,template=os.environ['LAB_BROWSER_TEMPLATE'],timeout=320);st.callback(s.kill)
 s.files.write('/tmp/handoff.tcl',(D/'sheet.tcl').read_text())
 shell(s,'nohup env DISPLAY=:1 wish /tmp/handoff.tcl </dev/null >/tmp/handoff-wish.log 2>&1 &')
 s.files.write('/tmp/xfocus.py',(D/'xfocus.py').read_text())
 shell(s,'nohup python3 /tmp/xfocus.py </dev/null >/tmp/xfocus.log 2>&1 &')
 flags=dict(os.environ,LAB_VHOST=s.get_host(9000),LAB_PORT=str(cfg.proxy_port),LAB_TRAFFIC=s.traffic_access_token or '')
 def screen(phase):
  subprocess.run([sys.executable,str(D/'vnc-client.py'),phase],env=flags,check=True,timeout=65)
 assert b'noVNC' in web(cfg,s,9000,'/novnc/vnc.html')
 screen('before');physical=shell(s,'cat /tmp/note-length 2>/dev/null || echo 0')=='14'
 if not physical:screen('reference')
 assert shell(s,'cat /tmp/note-length')=='14'
 assert shell(s,'test ! -e /tmp/handoff-report.txt && echo unsaved')=='unsaved'
 snap=s.create_snapshot();st.callback(Sandbox.delete_snapshot,snap.snapshot_id,config=cfg)
 t=time.monotonic();s.pause();paused=time.monotonic();mode='same-id resume';error=None; reachable=False
 try:s.resume(timeout=180)
 except Exception as e:
  if '130593' not in str(e):raise
  error='130593'
 resumed=time.monotonic()
 if error:
  for _ in range(6):
   try:
    if b'noVNC' in web(cfg,s,9000,'/novnc/vnc.html',timeout=2):reachable=True;break
   except Exception:time.sleep(2)
  if not reachable:
   mode='new instance from full snapshot'
   s=vm(cfg,snap.snapshot_id,timeout=180);st.callback(s.kill)
   flags['LAB_VHOST']=s.get_host(9000);flags['LAB_TRAFFIC']=s.traffic_access_token or ''
 screen('after' if physical else 'operator');value=shell(s,'cat /tmp/handoff-report.txt');assert value=='Check lot 1048 - approved',value
 save('desktop',{'remote_keyboard':physical,'display':'Debian 13 X11','client':'noVNC in Chromium','before_pause':'Check lot 1048','saved_before_pause':False,'after_reconnect_and_save':value,'pause_ms':round(1000*(paused-t)),'resume_call_ms':round(1000*(resumed-paused)),'resume_api_error':error,'handoff_route':mode})
 print('desktop handoff',mode,'resume_api_error',error,flush=True)
