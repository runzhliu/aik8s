import ctypes as c,time
from pathlib import Path
x=c.CDLL('libX11.so.6');x.XOpenDisplay.restype=c.c_void_p
d=c.c_void_p(x.XOpenDisplay(b':1'));w=c.c_ulong(int(Path('/tmp/entry-window').read_text().strip(),16))
for _ in range(600):
 x.XSetInputFocus(d,w,1,0);x.XFlush(d);time.sleep(.2)
