from lab import *
import concurrent.futures,re,difflib
base={'fee.py':'def fee(cents):\n    return 0\n','legacy.txt':'Deprecated placeholder\n','POLICY.md':'Preview pricing\n'}
def plan(label):
 rate=5 if label=='A' else 8
 prompt=f"""You are coding agent {label}. A teaching repository contains fee.py, legacy.txt and POLICY.md. Implement a {rate} percent fee rounded down, in integer cents. Return a JSON object of file changes only. fee.py must be a two-line Python function def fee(cents): and return cents * {rate} // 100 (or equivalent). POLICY.md must describe the percentage in English. """+('Remove legacy.txt using JSON null.' if label=='A' else 'Leave legacy.txt unchanged; omit it from output.')
 raw,modelid=model(prompt)
 j=json.loads(re.sub(r'^\s*```(?:json)?\s*|\s*```\s*$','',raw.strip()))
 assert set(j)==({'fee.py','POLICY.md','legacy.txt'} if label=='A' else {'fee.py','POLICY.md'})
 assert isinstance(j['fee.py'],str) and isinstance(j['POLICY.md'],str) and len(j['fee.py'])<800
 if label=='A':assert j['legacy.txt'] is None
 return j
with ExitStack() as st:
 cfg=endpoint(st);root=vm(cfg,template=os.environ['LAB_GIT_TEMPLATE'],timeout=420);st.callback(root.kill)
 shell(root,'command -v git && mkdir -p /tmp/five/source && chmod 755 /tmp/five')
 for k,v in base.items():root.files.write('/tmp/five/source/'+k,v)
 shell(root,'cd /tmp/five/source && git init -q && git add . && git -c user.email=lab@example.invalid -c user.name=Lab commit -qm initial && chmod -R a-w .')
 children=root.fork(count=2,timeout=300)
 for child in children:
  if isinstance(child,BaseException):raise child
  st.callback(child.kill)
 def work(item):
  label,child=item
  shell(child,"git -c safe.directory='*' clone --quiet --no-hardlinks /tmp/five/source /tmp/work")
  j=plan(label)
  for f,v in j.items():
   if v is None:shell(child,'rm /tmp/work/legacy.txt')
   else:child.files.write('/tmp/work/'+f,v.rstrip()+'\n')
  rate=5 if label=='A' else 8
  sample=shell(child,"cd /tmp/work && python3 -c "+shlex.quote(f"from fee import fee; xs=[0,99,100,12345]; result=[fee(x) for x in xs]; assert result==[x*{rate}//100 for x in xs];print(result)"))
  diff=shell(child,'cd /tmp/work && rm -rf __pycache__ && git add -A && git diff --cached --no-ext-diff')+'\n'
  assert not shell(child,'cd /tmp/five/source && git status --porcelain')
  return {'branch':label,'patch':diff,'fees':json.loads(sample),'base_clean':True}
 with concurrent.futures.ThreadPoolExecutor(2) as pool:results=list(pool.map(work,zip('AB',children)))
 for r in results:root.files.write('/tmp/'+r['branch']+'.patch',r['patch'])
 shell(root,'git clone --quiet --no-hardlinks /tmp/five/source /tmp/review && cd /tmp/review && git apply --check /tmp/A.patch && git apply /tmp/A.patch && test ! -e legacy.txt')
 accepted=shell(root,"cd /tmp/review && python3 -c 'from fee import fee; print(fee(12345))'")
 rr=shell(root,'cd /tmp/review && { git apply --check /tmp/B.patch 2>/dev/null && echo applied || echo conflict; }')
 assert rr=='conflict' and accepted=='617'
 save('edits',{'agents':results,'accepted':'A','fee_after_merge':int(accepted),'conflicting_patch_rejected':True,'parent_base_clean':not shell(root,'cd /tmp/five/source && git status --porcelain')})
 print('two real model patches; selected A, conflict detected')
