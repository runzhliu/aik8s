from lab import *
import statistics,math
def web(cfg,sb,port,path):
 return shell(sb,'curl --noproxy "*" --max-time 10 -fsS http://127.0.0.1:'+str(port)+path,timeout=18)
rows=[];errors=[]; snaps={}
with ExitStack() as st:
 cfg=endpoint(st);sb=vm(cfg,timeout=240)
 try:
  sb.files.write('/tmp/index_service.py',(D/'index_service.py').read_text())
  shell(sb,'nohup python3 /tmp/index_service.py </dev/null >/tmp/index-service.log 2>&1 &')
  for k in range(15):
   try:web(cfg,sb,8074,'/alive');break
   except Exception:time.sleep(.25)
  for mode in ('lazy','warm'):
   if mode=='warm':assert json.loads(web(cfg,sb,8074,'/prepare'))['ready']
   print('capturing',mode,flush=True);sn=sb.create_snapshot();snaps[mode]=sn.snapshot_id
   st.callback(Sandbox.delete_snapshot,sn.snapshot_id,config=cfg)
 finally:sb.kill()
 for i in range(20):
  for mode in (('lazy','warm') if i%2==0 else ('warm','lazy')):
   cur=None
   try:
    start=time.perf_counter();cur=vm(cfg,snaps[mode]);created=time.perf_counter()
    init=json.loads(web(cfg,cur,8074,'/alive')); assert init['ready']==(mode=='warm'),init
    assert json.loads(web(cfg,cur,8074,'/prepare'))['ready'];ready=time.perf_counter()
    ans=json.loads(web(cfg,cur,8074,'/query'));done=time.perf_counter()
    assert ans['hits']==sum(1 for n in range(16000) if n%37==7 and n%23==3)
    rows.append({'round':i+1,'mode':mode,'create_ms':round((created-start)*1000,1),'ready_ms':round((ready-start)*1000,1),'first_result_ms':round((done-start)*1000,1),'hits':ans['hits']})
   except Exception as e:errors.append({'round':i+1,'mode':mode,'type':type(e).__name__});print('attempt error',str(e)[:180])
   finally:
    if cur:cur.kill()
   save('prewarm',{'rows':rows,'errors':errors});print('completed',i+1,mode,len(rows),flush=True)
 # Validate one real model call from the office after the measured fixed task in each variant.
 validations=[]
 for mode in ('lazy','warm'):
  cur=vm(cfg,snaps[mode])
  try:
   web(cfg,cur,8074,'/prepare');ans=json.loads(web(cfg,cur,8074,'/query'))
   reply,name=model('Reply with just the decimal integer from this tool result: '+json.dumps(ans))
   validations.append({'mode':mode,'answer':reply.strip(),'model_family':name,'matches':reply.strip()==str(ans['hits'])})
  finally:cur.kill()
 save('prewarm',{'rows':rows,'errors':errors,'model_checks':validations})
