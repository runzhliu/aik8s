// Copyright (c) 2026 Tencent Inc.
// SPDX-License-Identifier: Apache-2.0

package app

import (
	"bytes"
	"context"
	"encoding/json"
	"github.com/agiledragon/gomonkey/v2"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/stretchr/testify/require"
	"github.com/tencentcloud/CubeSandbox/CubeMaster/pkg/base/config"
	"github.com/tencentcloud/CubeSandbox/CubeMaster/pkg/base/constants"
	"github.com/tencentcloud/CubeSandbox/CubeMaster/pkg/service/httpservice/cube"
	"github.com/tencentcloud/CubeSandbox/CubeMaster/pkg/service/sandbox"
	"github.com/tencentcloud/CubeSandbox/CubeMaster/pkg/service/sandbox/types"
	"github.com/tencentcloud/CubeSandbox/CubeMaster/pkg/task"
	"github.com/tencentcloud/CubeSandbox/CubeMaster/pkg/templatecenter"
	"github.com/tencentcloud/CubeSandbox/CubeMaster/pkg/webhook"
	"github.com/tencentcloud/CubeSandbox/pkgs/CubeLog"
	"io"
 "os"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func TestLabDelegatedCreate(t *testing.T) {
    mode := "enabled"
    path, e := filepath.Abs("../../../conf.yaml")
	require.NoError(t, e)
	t.Setenv("CUBE_MASTER_CONFIG_PATH", path)
	cfg, e := config.Init()
	require.NoError(t, e)
	bodies := make(chan []byte, 4)
 deliveries := make(chan string, 4)
 attempt := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		bodies <- b
 deliveries <- r.Header.Get("e2b-delivery-id")
 attempt++
 if attempt==1 {w.WriteHeader(503);return}
		w.WriteHeader(204)
	}))
	defer srv.Close()
	cfg.Webhooks = config.DefaultWebhookConf()
	cfg.Webhooks.Enabled = mode != "disabled"
	cfg.Webhooks.Invalid = mode == "invalid"
	cfg.Webhooks.AllowHTTP = true
	cfg.Webhooks.AllowedCIDRs = []string{"127.0.0.0/8"}
	cfg.Webhooks.Subscriptions = []config.WebhookSubscription{{ID: uuid.NewString(), Enabled: true, URL: srv.URL, Events: []string{webhook.TypeCreated}}}
	a := New()
	a.startWebhooks(context.Background(), cfg)
	defer a.webhooks.Shutdown(context.Background())
	defer sandbox.SetWebhookPublisher(nil)
	defer task.SetWebhookPublisher(nil)
	defer templatecenter.SetWebhookPublisher(nil)
	var actual string
 before := webhookCounter(t, "capture", "accepted")
	p := gomonkey.NewPatches()
	defer p.Reset()
	if mode != "enabled" {
		p.ApplyFunc(webhook.UserMetadata, func(map[string]string) webhook.LifecycleFields { panic("App disabled metadata") })
		p.ApplyFunc(webhook.PrepareLifecycle, func(*types.CreateCubeSandboxReq) (string, webhook.LifecycleFields) { panic("App disabled fields") })
		p.ApplyFunc(webhook.Capture, func(webhook.CaptureInput) (*webhook.CapturedEvent, error) { panic("App disabled Capture") })
	}
	// Exercise App -> Holder -> producer -> Runtime -> HTTP. Business creation
	// has its own tests; do not start scheduler/metrics workers in this wiring test.
	createCalls := 0
	p.ApplyFunc(sandbox.CreateSandbox, func(ctx context.Context, req *types.CreateCubeSandboxReq) *types.CreateCubeSandboxRes {
		createCalls++
		require.NotNil(t, CubeLog.GetTraceInfo(ctx))
		
        labRequest,err:=json.Marshal(map[string]interface{}{ "templateID":os.Getenv("LAB_BASE_TEMPLATE"), "timeout":180, "allowInternetAccess":false });require.NoError(t,err)
        res, err:=http.Post(os.Getenv("LAB_API")+"/sandboxes","application/json",bytes.NewReader(labRequest))
        require.NoError(t,err);defer res.Body.Close()
        require.Less(t,res.StatusCode,300)
        var created struct{SandboxID string `json:"sandboxID"`}
        require.NoError(t,json.NewDecoder(res.Body).Decode(&created));require.NotEmpty(t,created.SandboxID)
        actual=created.SandboxID;require.NoError(t,os.WriteFile("/tmp/lab-id",[]byte(actual),0600))
        return &types.CreateCubeSandboxRes{Ret: &types.Ret{RetCode: 200}, SandboxID: actual}
	})
	req := &types.CreateCubeSandboxReq{Volumes: []*types.Volume{{Name: "tmp", VolumeSource: &types.VolumeSource{EmptyDir: &types.EmptyDirVolumeSource{}}}}, Request: &types.Request{RequestID: "r"}, InsIp: "127.0.0.1", InstanceType: "cubebox", Annotations: map[string]string{constants.AnnotationsDebug: "true"}, Containers: []*types.Container{{Image: &types.ImageSpec{}, Resources: &types.Resource{Cpu: "1", Mem: "1Gi"}}}}
	payload, e := json.Marshal(req)
	require.NoError(t, e)
	router := gin.New()
	cube.RegisterCubeRoutes(router.Group("/cube"))
	w := httptest.NewRecorder()
	router.ServeHTTP(w, httptest.NewRequest("POST", "/cube/sandbox", bytes.NewReader(payload)).WithContext(CubeLog.WithRequestTrace(context.Background(), &CubeLog.RequestTrace{})))
	require.Equal(t, 1, createCalls)
	require.Equal(t, 200, w.Code)
	require.Contains(t, w.Body.String(), actual)
	if mode != "enabled" {
		require.Equal(t, before, webhookCounter(t, "capture", "accepted"))
		require.Empty(t, bodies)
		return
	}

 var firstEvent,firstDelivery string
 for i:=1;i<=2;i++ {
 select {case body:=<-bodies:
   var ev struct{ID string `json:"id"`; Type string `json:"type"`; SandboxID string `json:"sandbox_id"`}
   require.NoError(t,json.Unmarshal(body,&ev)); d:=<-deliveries;require.NotEmpty(t,d);require.NotEmpty(t,ev.ID)
   require.Equal(t,actual,ev.SandboxID);require.Equal(t,webhook.TypeCreated,ev.Type)
   if i==1 {firstEvent=ev.ID;firstDelivery=d} else {require.Equal(t,firstEvent, ev.ID);require.NotEqual(t,firstDelivery,d)}
   t.Logf("receiver attempt=%d event=%s same_actual_sandbox=true HTTP=%d",i,ev.Type,map[int]int{1:503,2:204}[i])
 case <-time.After(14*time.Second):t.Fatal("receiver timeout")}
 }
 t.Log("real allocation succeeded; event ID stable; delivery ID changed")
}
