from lab import *
import csv,io
def skill(v):
 return ("import json,sys\nfrom pathlib import Path\n"+"x=json.loads(Path('/tmp/session/input.json').read_text());t=sum(x)\n"+
    ("s='total='+str(t)+'\\n'\n" if v==1 else "s=json.dumps({'schema':2,'total':t},sort_keys=True)+'\\n'\n")+
    "Path('/tmp/session/report').write_text(s);print(s.strip())\n")
def call(sb,step):
 skillmd=shell(sb,'cat /opt/skills/report/SKILL.md')
 reply,_=model("You are a reporting assistant. Read this installed skill: "+skillmd+". User asks: "+step+". Select exactly one available action: prepare_input or render_report. Return only the literal action name.")
 return reply.strip().strip('`').lower()
def run_snapshot(cfg,v,st):
 source=vm(cfg); 
 try:
  shell(source,'mkdir -p /opt/skills/report')
  source.files.write('/opt/skills/report/SKILL.md',f'# Report v{v}\nUse prepare_input to stage a draft. Use render_report to finish using the installed formatter.')
  source.files.write('/opt/skills/report/render.py',skill(v))
  sn=source.create_snapshot(mode='fs-only');st.callback(Sandbox.delete_snapshot,sn.snapshot_id,config=cfg)
  return sn.snapshot_id
 finally:source.kill()
def stage(sb):
 shell(sb,"mkdir -p /tmp/session");sb.files.write('/tmp/session/input.json','[12, 17, 13]')
def finish(sb):
 action=call(sb,'Finish the report from my saved input.');assert action=='render_report',action
 return shell(sb,'python3 /opt/skills/report/render.py')
with ExitStack() as stack:
 cfg=endpoint(stack);registry={'current':run_snapshot(cfg,1,stack)}
 a=vm(cfg,registry['current'],timeout=350);stack.callback(a.kill)
 first=call(a,'Start a draft with my input, do not generate the finished report yet.');assert first=='prepare_input',first
 stage(a);old=registry['current'];registry['current']=run_snapshot(cfg,2,stack)
 b=vm(cfg,registry['current']);stack.callback(b.kill);stage(b)
 result_b=finish(b);result_a=finish(a)
 registry['current']=old;c=vm(cfg,registry['current']);stack.callback(c.kill);stage(c);result_c=finish(c)
 assert result_a==result_c=='total=42' and json.loads(result_b)=={'schema':2,'total':42}
 save('skills',{'input':[12,17,13],'initial_action':first,'sessions':[{'name':'A','opened':'before v2','installed':1,'output':result_a},{'name':'B','opened':'after v2','installed':2,'output':result_b},{'name':'C','opened':'after rollback','installed':1,'output':result_c}],'b_after_rollback':shell(b,'cat /tmp/session/report'),'same_a_input_after_switch':json.loads(shell(a,'cat /tmp/session/input.json'))})
 print('v1 draft, v2 new user, rollback, existing sessions all checked')
