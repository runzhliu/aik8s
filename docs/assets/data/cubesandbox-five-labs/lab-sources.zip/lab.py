from contextlib import ExitStack
from pathlib import Path
import json,sys,shlex,time,os,urllib.request,subprocess,hashlib
D=Path(__file__).resolve().parent
from cubesandbox import Config,Sandbox

def endpoint(stack):
    (D/'out').mkdir(exist_ok=True)
    return Config()

http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def save(name,obj):
 p=D/'out'/(name+'.json');temp=p.with_suffix('.tmp');temp.write_text(json.dumps(obj,indent=2,ensure_ascii=False));temp.replace(p)
def vm(cfg,template=None,timeout=240):
 return Sandbox.create(template=template or os.environ["LAB_CODE_TEMPLATE"],config=cfg,timeout=timeout,allow_internet_access=False,metadata={'purpose':'publication-lab-nov23'})
def shell(sb,cmd,timeout=45):
 r=sb.commands.run(cmd,timeout=timeout)
 if r.exit_code:raise RuntimeError('guest exit '+str(r.exit_code)+': '+r.stderr[-380:])
 return r.stdout.strip()
def py(sb,code):return shell(sb,'python3 -c '+shlex.quote(code))
def web(cfg,sb,port,path,timeout=25):
 headers={'Host':sb.get_host(port)}
 if sb.traffic_access_token:headers['e2b-traffic-access-token']=sb.traffic_access_token
 with http.open(urllib.request.Request(f'http://127.0.0.1:{cfg.proxy_port}'+path,headers=headers),timeout=timeout) as r:return r.read()
def model(prompt):
    # Point the driver at an authorized chat-completions endpoint.
    url=os.environ['LAB_CHAT_COMPLETIONS_URL']
    headers={'Content-Type':'application/json'}
    if os.getenv('LAB_MODEL_KEY'):
        headers['Authorization']='Bearer '+os.environ['LAB_MODEL_KEY']
    body={'model':os.environ['LAB_MODEL'],'messages':[{'role':'user','content':prompt}],
          'stream':False,'max_tokens':1000}
    if os.getenv('LAB_MODEL_EXTRA_JSON'):
        body.update(json.loads(os.environ['LAB_MODEL_EXTRA_JSON']))
    req=urllib.request.Request(url,data=json.dumps(body).encode(),headers=headers)
    with urllib.request.urlopen(req,timeout=80) as response:
        result=json.load(response)
    return result['choices'][0]['message']['content'],result['model']
