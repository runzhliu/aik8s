import hashlib,json,sqlite3
from http.server import HTTPServer,BaseHTTPRequestHandler
db=None
def prepare():
 global db
 if db is not None:return
 con=sqlite3.connect(':memory:')
 con.execute('create virtual table records using fts5(body)')
 con.executemany('insert into records values (?)',((f"runbook component{i%37} symptom{i%23} recovery "+hashlib.sha256(str(i).encode()).hexdigest(),) for i in range(16000)))
 con.commit();db=con
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path=='/prepare':prepare()
  status=200 if db is not None or self.path=='/alive' else 503
  value=db.execute("select count(*) from records where records match 'component7 AND symptom3'").fetchone()[0] if self.path=='/query' and db else 0
  b=json.dumps({'ready':db is not None,'hits':value}).encode();self.send_response(status);self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 def log_message(self,*a):pass
HTTPServer(('0.0.0.0',8074),Handler).serve_forever()
