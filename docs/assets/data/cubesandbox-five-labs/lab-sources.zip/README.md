# Reproduce the CubeSandbox labs / 复现实验

Use an isolated CubeSandbox installation with the v0.8.0 Python SDK, Python 3, Playwright and Chrome. These scripts create short-lived instances and snapshots and remove them on exit. A forced process kill can interrupt cleanup; use a dedicated account and inspect its resources. Model calls are made by the driver, outside the guests.

使用独立测试环境。驱动使用 v0.8.0 Python SDK、Python 3、Playwright 和 Chrome。脚本会创建临时实例和快照，在正常退出时回收。模型凭据仅留在驱动侧。强制杀掉驱动后请核对实验资源。

Set CUBE_API_URL, CUBE_API_KEY if required, CUBE_PROXY_NODE_IP, CUBE_PROXY_PORT_HTTP and CUBE_SANDBOX_DOMAIN for your lab. The desktop forwarder expects a localhost TCP forward to CubeProxy at CUBE_PROXY_PORT_HTTP. LAB_CODE_TEMPLATE needs Python 3, sqlite3 with FTS5 and curl. LAB_GIT_TEMPLATE additionally needs Git and fork support. LAB_BROWSER_TEMPLATE uses the Debian X11 template described in the article, with DISPLAY=:1, wish, x11vnc, and noVNC proxied under /novnc/ and /websockify on exposed port 9000. The browser driver launches a separate Chrome client for each connection.

将 SDK 的地址和上述模板变量设置为自己测试环境的值。桌面转发器要求 CubeProxy 端口已转发到本机回环地址。请先验证模板有对应软件。

Set LAB_CHAT_COMPLETIONS_URL to your full chat-completions URL, LAB_MODEL to the served model and LAB_MODEL_KEY when authentication is required. Optional LAB_MODEL_EXTRA_JSON passes provider-specific parameters. Our model used {"thinking":{"type":"disabled"}}. Ensure secrets come from your private environment.

    python3 prewarm.py
    python3 edit.py
    python3 skill.py
    python3 desktop.py

Each entry point writes its results into out/. The desktop lab's small dispatch application stores the report only after Save. It has two pointer-operable actions for cases where direct keys do not reach the guest. Scripts exercise real models; different outputs can fail strict assertions.

对照实验会输出原始结果到 out/。若模型输出、桌面路由或模板与文章不同，断言可能失败。

## Isolated webhook handler / 独立测试夹具

Use the upstream TencentCloud/CubeSandbox commit 6843e3f97e67. Copy lab_observation_test.go into CubeMaster/cmd/cubemaster/app and run from CubeMaster. LAB_API must be an authorized lab endpoint reachable by this process; the fixture expects a local trusted CubeAPI with matching access requirements. LAB_BASE_TEMPLATE is the local base template name. The fixture writes the created ID to /tmp/lab-id and uses a 180-second instance lifetime. Query the console logs before expiry. In a shared shell, run this in a disposable container to keep the ID file private. The upstream trace test records spans in memory; the article printed their names and statuses from the recorder. There is no five-service exporter deployment in this fixture.

    go test -gcflags=all=-l -v ./cmd/cubemaster/app -run '^TestLabDelegatedCreate$'
    go test -gcflags=all=-l -v ./pkg/webhook -run '^TestRuntime(TimeoutMetricsAndRetryExhaustion|FiniteRetryStableSnapshot)$'
    go test -gcflags=all=-l -v ./pkg/service/sandbox -run '^TestUpdate(ResumeSuccessEmitsSiblingStagesWithRealWorker|PauseFailureMarksRuntimeStage)$'

应在隔离环境执行，记录真实沙箱 ID 后在其过期前查询控制台日志。上游 worker 测试使用内存 span recorder。若改变模板、网络或 SDK，请记录版本后重新验收。
