package require Tk
wm title . "Review sheet"
wm overrideredirect . 1
wm geometry . "1920x1080+0+0"
. configure -background "#f4f6f8"
frame .body -background white -padx 70 -pady 48
place .body -relx .5 -rely .45 -anchor center
label .body.h -text "Dispatch review" -font {sans 30} -bg white -fg "#253349"
label .body.p -text "Order 1048    /    Release desk" -font {sans 18} -bg white -fg "#536474"
label .body.l -text "Handoff note" -font {sans 17} -bg white -fg "#374151"
entry .body.e -width 38 -font {sans 25} -bg "#f4f6f8" -fg "#101f30" -textvariable note
set note ""; set state "Unsaved"; set path /tmp/handoff-report.txt
proc save_note {} {global note path state;set fd [open $path w];puts $fd $note;close $fd;set state "Saved to report"}
button .body.b -text "Save report" -font {sans 16} -command save_note
label .body.s -textvariable state -font {sans 15} -bg white -fg "#326759"
foreach x {h p l e b s} {pack .body.$x -anchor w -pady 12}
bind all <Control-l> {focus -force .body.e}
bind all <Control-s> {save_note}
after 450 {raise .;focus -force .body.e}
bind .body.e <Button-1> {focus -force .body.e}
bind all <KeyPress> {set fh [open /tmp/xkey.log a];puts $fh [list %K %k [focus]];close $fh}
proc keep_input_focus {} {focus -force .body.e; after 500 keep_input_focus}
after 1200 keep_input_focus
set winfd [open /tmp/entry-window w];puts $winfd [winfo id .body.e];close $winfd
proc has_text {args} {global note;set f [open /tmp/note-length w];puts $f [string length $note];close $f}
trace add variable note write has_text
button .insert -text "Insert order reference" -command {set note "Check lot 1048"} -font {sans 16}
button .approve -text "Approve dispatch" -command {append note " - approved"} -font {sans 16}
place .insert -relx .40 -rely .74 -anchor center
place .approve -relx .60 -rely .74 -anchor center
