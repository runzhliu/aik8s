from playwright.sync_api import sync_playwright
import os,sys,time
from pathlib import Path
D=Path(__file__).resolve().parent; phase=sys.argv[1];host=os.environ['LAB_VHOST'];port=os.environ['LAB_PORT'];token=os.getenv('LAB_TRAFFIC','')
import socketserver,socket,select,threading
class Forward(socketserver.StreamRequestHandler):
 rbufsize=0
 def handle(self):
  first=self.rfile.readline(10000)
  if not first:return
  hs={}
  while True:
   line=self.rfile.readline(20000).strip()
   if not line:break
   key,v=line.split(b':',1);hs[key.lower()]=v.strip()
  hs[b'host']=host.encode()
  if token:hs[b'e2b-traffic-access-token']=token.encode()
  if b'upgrade' not in hs:hs[b'connection']=b'close'
  with socket.create_connection(('127.0.0.1',int(port)),timeout=20) as up:
   up.settimeout(None);up.sendall(first+b''.join(k+b': '+v+b'\r\n' for k,v in hs.items())+b'\r\n')
   sock=self.request
   while True:
    rs,_,_=select.select([up,sock],[],[],35)
    if not rs:return
    for f in rs:
     try:
      b=f.recv(65536)
      if not b:return
      (sock if f is up else up).sendall(b)
     except OSError:return
class Server(socketserver.ThreadingTCPServer):daemon_threads=True
local=Server(('127.0.0.1',0),Forward)
threading.Thread(target=local.serve_forever,daemon=True).start()
with sync_playwright() as p:
 browser=p.chromium.launch(channel='chrome',headless=True,args=['--no-proxy-server','--host-resolver-rules=MAP '+host+' 127.0.0.1'])
 cx=browser.new_context(viewport={'width':1360,'height':805},device_scale_factor=1,extra_http_headers=({'e2b-traffic-access-token':token} if token else {}))
 page=cx.new_page(); page.goto('http://127.0.0.1:'+str(local.server_address[1])+'/novnc/vnc.html?autoconnect=1&resize=scale&path=websockify',wait_until='domcontentloaded')
 try:page.wait_for_selector('html.noVNC_connected',state='attached',timeout=18000)
 except Exception:
  print('noVNC connection status:',page.locator('#noVNC_status').inner_text(),page.locator('html').get_attribute('class'),flush=True);raise
 canvas=page.locator('#noVNC_canvas, #noVNC_container canvas').first;canvas.wait_for();canvas.click(position={'x':120,'y':90}); page.wait_for_timeout(900)
 box=canvas.bounding_box(); canvas.click(position={'x':box['width']*.5,'y':box['height']*.483}); page.wait_for_timeout(250)
 canvas.focus()
 def keys(value):
  for c in value:
   if c==' ':key='Space'
   elif c=='-':key='Minus'
   elif c.isdigit():key='Digit'+c
   else:key=('Shift+' if c.isupper() else '')+'Key'+c.upper()
   page.evaluate("""async ([sym,code])=>{
      const { default:UI }=await import('/novnc/app/ui.js');if(!UI.rfb||UI.rfb.viewOnly)throw Error('noVNC keyboard unavailable');UI.rfb.sendKey(sym,code);
   }""",[ord(c),key.split('+')[-1]]);page.wait_for_timeout(60)
 if phase=='before':
  keys('Check lot 1048')
 if phase=='reference':canvas.click(position={'x':box['width']*.4,'y':box['height']*.74})
 page.wait_for_timeout(500);canvas.screenshot(path=str(D/'out'/('desktop-'+{'reference':'before','operator':'after'}.get(phase,phase)+'.png')))
 if phase in ('after','operator'):
  if phase=='after':page.keyboard.press('End');keys(' - approved')
  else:canvas.click(position={'x':box['width']*.60,'y':box['height']*.74})
  canvas.click(position={'x':box['width']*.325,'y':box['height']*.548});page.wait_for_timeout(700);canvas.screenshot(path=str(D/'out'/'desktop-saved.png'))
 browser.close()
