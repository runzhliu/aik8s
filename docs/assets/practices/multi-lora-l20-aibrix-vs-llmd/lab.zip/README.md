# Multi-LoRA on 2x L20: AIBrix v0.8.0 vs. CNCF llm-d EPP v1.0.0 Lab Kit

Reproducible manifests and async streaming SSE benchmark harness for comparing:
1. Single-L20 `--max-loras` sweep (`4 / 8 / 20`) with `Qwen3-8B` BF16 + 20 PEFT LoRA adapters (`r=16`, 87.4 MB each).
2. 2x1 L20 (`--max-loras=10`) routing: Round-Robin vs. `llm-d` EPP `v1.0.0` (`lora-affinity-scorer`) vs. AIBrix `v0.8.0` (`ModelAdapter`).
3. 70% hotspot skew (`replicas: 1` vs. hot-adapter scale-out) and noisy-neighbor isolation (`InferenceObjective` priority flow control vs. Redis per-user RPM/TPM rate limiting).

## Files
- `llmd-controlplane.yaml`: `InferencePool`, `InferenceObjective` (`+10` / `-10`), `EndpointPickerConfig`, `epp-qwen3-8b`, and standalone `envoy` (`v1.33.2`) with `ext_proc` + `ORIGINAL_DST` + Round-Robin baseline listener.
- `vllm-qwen3-8b-lora.yaml`: `Qwen3-8B` vLLM Deployment with deterministic 21-LoRA PEFT Safetensors InitContainer.
- `aibrix-modeladapter-sample.yaml`: Sample `ModelAdapter` (`model.aibrix.ai/v1alpha1`) for single-replica pinned placement (`replicas: 1`) and all-pod hotspot scaling (omit `replicas`).
- `bench_lora.py`: Async streaming SSE harness measuring per-request TTFT, TPOT, E2E, complete-stream status, and `target-pod` / `x-upstream-host` routing attribution.
