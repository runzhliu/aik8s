#!/usr/bin/env python3
"""In-cluster Multi-LoRA benchmark harness for Qwen3-8B on L20.

Measures per-request streaming SSE TTFT, TPOT, E2E, HTTP status, complete-stream
validity, and target-pod / x-upstream-host routing attribution across:
  - Stage 1: Single-GPU --max-loras sweep (4 / 8 / 20)
  - Stage 2: 2xL20 Round-Robin vs AIBrix v0.8.0 vs llm-d EPP v1.0.0 (uniform & hotspot)
  - Stage 3: Noisy neighbor isolation (baseline vs AIBrix rate-limit vs EPP priority shedding)
"""
import argparse
import asyncio
import json
import math
import random
import re
import time
from collections import Counter
from pathlib import Path
import aiohttp


def pct(vals, p):
    if not vals:
        return None
    s = sorted(vals)
    k = (len(s) - 1) * (p / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return round(s[int(k)], 2)
    return round(s[f] + (s[c] - s[f]) * (k - f), 2)


def make_prompt(nonce: str, repeats: int) -> str:
    sentence = "Kubernetes inference gateways route multi-LoRA requests while balancing adapter locality, queue depth, and KV cache headroom. "
    return f"Request {nonce}. " + (sentence * repeats) + "Summarize the main scheduling tradeoff in concise technical prose."


async def scrape_vllm_metrics(session: aiohttp.ClientSession, pod_ips: list[str]) -> dict:
    out = {}
    for ip in pod_ips:
        url = f"http://{ip}:8000/metrics"
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as r:
                txt = await r.text()
            snap = {"running": None, "waiting": None, "kv_usage": None, "active_loras": [], "waiting_loras": []}
            for line in txt.splitlines():
                if line.startswith("#") or not line.strip():
                    continue
                if line.startswith("vllm:num_requests_running"):
                    snap["running"] = float(line.split()[-1])
                elif line.startswith("vllm:num_requests_waiting"):
                    snap["waiting"] = float(line.split()[-1])
                elif line.startswith("vllm:kv_cache_usage_perc") or line.startswith("vllm:gpu_cache_usage_perc"):
                    snap["kv_usage"] = float(line.split()[-1])
                elif line.startswith("vllm:lora_requests_info"):
                    m_run = re.search(r'running_lora_adapters="([^"]*)"', line)
                    m_wait = re.search(r'waiting_lora_adapters="([^"]*)"', line)
                    val = float(line.split()[-1])
                    if m_run and m_run.group(1):
                        snap["active_loras"].append({"ts": val, "adapters": [x for x in m_run.group(1).split(",") if x]})
                    if m_wait and m_wait.group(1):
                        snap["waiting_loras"].append({"ts": val, "adapters": [x for x in m_wait.group(1).split(",") if x]})
            out[ip] = snap
        except Exception as e:
            out[ip] = {"error": str(e)}
    return out


async def send_one(
    session: aiohttp.ClientSession,
    endpoint: str,
    req_id: int,
    model: str,
    prompt: str,
    max_tokens: int,
    extra_headers: dict,
    tag: str,
    timeout_s: float = 120.0,
) -> dict:
    url = endpoint.rstrip("/") + "/v1/completions"
    payload = {
        "model": model,
        "prompt": prompt,
        "max_tokens": max_tokens,
        "temperature": 0.0,
        "ignore_eos": True,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    headers = {"Content-Type": "application/json", **extra_headers}
    t0 = time.perf_counter()
    first_tok_t = None
    last_tok_t = None
    content_chunks = 0
    saw_done = False
    prompt_tokens = 0
    completion_tokens = 0
    target_pod = ""
    status = 0
    err = ""
    try:
        async with session.post(url, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout_s)) as resp:
            status = resp.status
            target_pod = resp.headers.get("target-pod") or resp.headers.get("x-upstream-host") or ""
            if status != 200:
                body = (await resp.text())[:300]
                err = f"HTTP {status}: {body}"
            else:
                buf = ""
                async for raw in resp.content.iter_any():
                    buf += raw.decode("utf-8", errors="ignore")
                    while "\n" in buf:
                        line, buf = buf.split("\n", 1)
                        line = line.strip()
                        if not line.startswith("data:"):
                            continue
                        data_str = line[5:].strip()
                        if data_str == "[DONE]":
                            saw_done = True
                            continue
                        try:
                            obj = json.loads(data_str)
                        except Exception:
                            continue
                        choices = obj.get("choices") or []
                        if choices:
                            txt = choices[0].get("text") or ""
                            if txt:
                                now = time.perf_counter()
                                if first_tok_t is None:
                                    first_tok_t = now
                                last_tok_t = now
                                content_chunks += 1
                        usage = obj.get("usage")
                        if usage:
                            prompt_tokens = usage.get("prompt_tokens", prompt_tokens)
                            completion_tokens = usage.get("completion_tokens", completion_tokens)
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
    t_end = time.perf_counter()
    complete = (status == 200 and content_chunks > 0 and saw_done and completion_tokens > 0)
    ttft_ms = round((first_tok_t - t0) * 1000.0, 2) if first_tok_t else None
    e2e_ms = round((t_end - t0) * 1000.0, 2)
    tpot_ms = None
    if first_tok_t and last_tok_t and completion_tokens > 1:
        tpot_ms = round(((last_tok_t - first_tok_t) * 1000.0) / (completion_tokens - 1), 2)
    return {
        "req_id": req_id,
        "tag": tag,
        "model": model,
        "status": status,
        "complete": complete,
        "ttft_ms": ttft_ms,
        "tpot_ms": tpot_ms,
        "e2e_ms": e2e_ms,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "target_pod": target_pod,
        "error": err,
    }


def summarize_group(recs: list[dict], wall_s: float) -> dict:
    ok = [r for r in recs if r["complete"]]
    ttfts = [r["ttft_ms"] for r in ok if r["ttft_ms"] is not None]
    tpots = [r["tpot_ms"] for r in ok if r["tpot_ms"] is not None]
    e2es = [r["e2e_ms"] for r in ok]
    codes = Counter(r["status"] for r in recs)
    pods = Counter(r["target_pod"] for r in ok if r["target_pod"])
    by_model_pod = {}
    for r in ok:
        by_model_pod.setdefault(r["model"], Counter())[r["target_pod"]] += 1
    out_tok = sum(r["completion_tokens"] for r in ok)
    in_tok = sum(r["prompt_tokens"] for r in ok)
    return {
        "total": len(recs),
        "complete": len(ok),
        "status_codes": dict(codes),
        "wall_s": round(wall_s, 2),
        "output_tok_s": round(out_tok / wall_s, 2) if wall_s > 0 else 0.0,
        "input_tok_s": round(in_tok / wall_s, 2) if wall_s > 0 else 0.0,
        "ttft_p50_ms": pct(ttfts, 50),
        "ttft_p95_ms": pct(ttfts, 95),
        "ttft_p99_ms": pct(ttfts, 99),
        "ttft_mean_ms": round(sum(ttfts) / len(ttfts), 2) if ttfts else None,
        "tpot_p50_ms": pct(tpots, 50),
        "tpot_p95_ms": pct(tpots, 95),
        "e2e_p50_ms": pct(e2es, 50),
        "e2e_p95_ms": pct(e2es, 95),
        "e2e_p99_ms": pct(e2es, 99),
        "target_pods": dict(pods),
        "per_model_pods": {m: dict(c) for m, c in sorted(by_model_pod.items())},
    }


async def run_load_adapters(pod_ip: str, adapters: list[str], lora_root: str):
    results = []
    async with aiohttp.ClientSession() as sess:
        for name in adapters:
            t0 = time.perf_counter()
            url = f"http://{pod_ip}:8000/v1/load_lora_adapter"
            body = {"lora_name": name, "lora_path": f"{lora_root}/{name}"}
            async with sess.post(url, json=body, timeout=aiohttp.ClientTimeout(total=60)) as r:
                txt = await r.text()
                dt = round((time.perf_counter() - t0) * 1000.0, 2)
                results.append({"adapter": name, "status": r.status, "ms": dt, "body": txt[:160]})
    print(json.dumps({"pod_ip": pod_ip, "loaded": len(results), "results": results}, indent=2))


async def run_bench(args):
    rng = random.Random(args.seed)
    models = [f"lora-{i:02d}" for i in range(1, args.num_loras + 1)]
    base_headers = {}
    for kv in args.header or []:
        k, v = kv.split(":", 1)
        base_headers[k.strip()] = v.strip()

    conn = aiohttp.TCPConnector(limit=256)
    async with aiohttp.ClientSession(connector=conn) as session:
        pod_ips = [x for x in (args.pod_ips or "").split(",") if x]
        metrics_before = await scrape_vllm_metrics(session, pod_ips) if pod_ips else {}

        # Optional warmup (1 short request on base model)
        if args.warmup:
            await send_one(session, args.endpoint, -1, models[0], make_prompt("warmup", 4), 8, base_headers, "warmup")

        records = []
        t_start = time.perf_counter()

        if args.mode in ("uniform", "hotspot"):
            queue = asyncio.Queue()
            for i in range(args.requests):
                if args.mode == "uniform":
                    m = models[i % len(models)] if args.round_robin_models else rng.choice(models)
                else:
                    m = models[0] if rng.random() < args.hot_ratio else rng.choice(models[1:])
                prompt = make_prompt(f"{args.seed}-{i:04d}", args.prompt_repeats)
                queue.put_nowait((i, m, prompt, args.max_tokens, base_headers, args.mode))

            async def worker():
                while True:
                    try:
                        req_id, m, prompt, mt, hdrs, tag = queue.get_nowait()
                    except asyncio.QueueEmpty:
                        return
                    rec = await send_one(session, args.endpoint, req_id, m, prompt, mt, hdrs, tag, timeout_s=args.timeout)
                    records.append(rec)
                    queue.task_done()

            tasks = [asyncio.create_task(worker()) for _ in range(args.concurrency)]
            await asyncio.gather(*tasks)

        elif args.mode == "noisy":
            # 19 normal LoRAs (steady concurrency, short 450-tok prompts) vs 1 noisy LoRA (lora-20, heavy 3500-tok prompts)
            normal_models = models[:-1]
            noisy_model = models[-1]
            normal_hdrs = dict(base_headers)
            noisy_hdrs = dict(base_headers)
            for kv in args.normal_header or []:
                k, v = kv.split(":", 1)
                normal_hdrs[k.strip()] = v.strip()
            for kv in args.noisy_header or []:
                k, v = kv.split(":", 1)
                noisy_hdrs[k.strip()] = v.strip()

            stop_noisy = asyncio.Event()
            req_counter = [0]

            async def normal_worker(wid: int):
                per_w = args.requests // args.concurrency
                for j in range(per_w):
                    rid = req_counter[0]; req_counter[0] += 1
                    m = normal_models[(wid * per_w + j) % len(normal_models)]
                    prompt = make_prompt(f"norm-{args.seed}-{wid}-{j}", args.prompt_repeats)
                    rec = await send_one(session, args.endpoint, rid, m, prompt, args.max_tokens, normal_hdrs, "normal", timeout_s=args.timeout)
                    records.append(rec)

            async def noisy_worker(wid: int):
                j = 0
                while not stop_noisy.is_set():
                    rid = 10000 + wid * 1000 + j
                    j += 1
                    prompt = make_prompt(f"noisy-{args.seed}-{wid}-{j}", args.noisy_repeats)
                    rec = await send_one(session, args.endpoint, rid, noisy_model, prompt, args.noisy_max_tokens, noisy_hdrs, "noisy", timeout_s=args.timeout)
                    records.append(rec)
                    if rec["status"] == 429:
                        await asyncio.sleep(0.05)

            n_tasks = [asyncio.create_task(noisy_worker(w)) for w in range(args.noisy_concurrency)]
            await asyncio.sleep(1.5)  # let noisy neighbor saturate before measuring normal traffic
            t_norm_start = time.perf_counter()
            norm_tasks = [asyncio.create_task(normal_worker(w)) for w in range(args.concurrency)]
            await asyncio.gather(*norm_tasks)
            t_norm_wall = time.perf_counter() - t_norm_start
            stop_noisy.set()
            await asyncio.gather(*n_tasks, return_exceptions=True)

        wall_s = time.perf_counter() - t_start
        metrics_after = await scrape_vllm_metrics(session, pod_ips) if pod_ips else {}

    out = {
        "args": vars(args),
        "wall_s": round(wall_s, 2),
        "summary": summarize_group(records, wall_s),
        "metrics_before": metrics_before,
        "metrics_after": metrics_after,
    }
    if args.mode == "noisy":
        norm_recs = [r for r in records if r["tag"] == "normal"]
        noisy_recs = [r for r in records if r["tag"] == "noisy"]
        out["normal_summary"] = summarize_group(norm_recs, t_norm_wall)
        out["noisy_summary"] = summarize_group(noisy_recs, wall_s)

    if args.output:
        p = Path(args.output)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({**out, "records": records}, indent=2) + "\n")
    print(json.dumps(out, indent=2))


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    ld = sub.add_parser("load")
    ld.add_argument("--pod-ip", required=True)
    ld.add_argument("--adapters", required=True)
    ld.add_argument("--lora-root", default="/loras")

    bn = sub.add_parser("bench")
    bn.add_argument("--endpoint", required=True)
    bn.add_argument("--mode", choices=["uniform", "hotspot", "noisy"], default="uniform")
    bn.add_argument("--num-loras", type=int, default=20)
    bn.add_argument("--requests", type=int, default=120)
    bn.add_argument("--concurrency", type=int, default=12)
    bn.add_argument("--prompt-repeats", type=int, default=22)  # ~450 tokens
    bn.add_argument("--max-tokens", type=int, default=64)
    bn.add_argument("--hot-ratio", type=float, default=0.70)
    bn.add_argument("--noisy-concurrency", type=int, default=12)
    bn.add_argument("--noisy-repeats", type=int, default=160)  # ~3300 tokens
    bn.add_argument("--noisy-max-tokens", type=int, default=128)
    bn.add_argument("--round-robin-models", action="store_true")
    bn.add_argument("--seed", type=int, default=42)
    bn.add_argument("--timeout", type=float, default=120.0)
    bn.add_argument("--warmup", action="store_true")
    bn.add_argument("--pod-ips", default="")
    bn.add_argument("--header", action="append")
    bn.add_argument("--normal-header", action="append")
    bn.add_argument("--noisy-header", action="append")
    bn.add_argument("--output", default="")

    args = ap.parse_args()
    if args.cmd == "load":
        asyncio.run(run_load_adapters(args.pod_ip, args.adapters.split(","), args.lora_root))
    else:
        asyncio.run(run_bench(args))


if __name__ == "__main__":
    main()
