# Volcano 1.16.0 scheduling lab

Use an idle, disposable cluster with exactly two schedulable workers advertising eight available simulated NVIDIA-B300-SXM6-AC devices each. Use kubectl, jq and Bash. The scheduler configurations replace the complete volcano-scheduler.conf. A scheduler restart and the eviction actions affect all workloads using that scheduler. Confirm there are no other active Volcano workloads. The v116-placement-lab namespace, v116-lab-* queue, priority and HyperNode names and the volcano.sh/nodegroup-name labels on both workers must be unused. Choose two workers whose Kubernetes hostnames match the Node names.

In the extracted directory on a dedicated test context:

```sh
export A=first-worker B=second-worker
export N=v116-placement-lab
K=volcano-system
CM=volcano-scheduler-configmap
kubectl config current-context
kubectl get nodes -L nvidia.com/gpu.product,volcano.sh/nodegroup-name
kubectl get pg -A
kubectl get hypernode,queue,priorityclass
kubectl -n "$K" get cm "$CM" -o json | jq -jer '.data["volcano-scheduler.conf"]' > original.conf
use_config() {
  kubectl -n "$K" patch cm "$CM" --type merge -p "$(jq -n --rawfile s "$1" '{data:{"volcano-scheduler.conf":$s}}')" || return
  kubectl -n "$K" delete pod -l app=volcano-scheduler || return
  kubectl -n "$K" rollout status deployment/volcano-scheduler --timeout=120s
}
load() { sed -e "s/WORKER_A/$A/g" -e "s/WORKER_B/$B/g" "$1" | kubectl create -f -; }
ready() { kubectl -n "$N" wait --for=condition=Ready pod -l "experiment=$1" --timeout=90s; }
list() { kubectl -n "$N" get pods -o wide; kubectl -n "$N" get pg; }
reset_round() {
  kubectl -n "$N" delete pod --all --wait
  kubectl -n "$N" delete pg --all --wait
}
load namespace.json
```

## 1. Single-node footprint

```sh
use_config default.conf
load packing/split.json
ready hold-a && ready hold-b
load packing/large.json
sleep 15
list
reset_round
load packing/packed.json
ready hold-a && ready hold-b
load packing/large.json
ready large
list
reset_round
for conf in default.conf gpu-score.conf; do
  use_config "$conf"
  for i in $(seq 0 7); do load "packing/small-$i.json" && ready "small-$i" || break; done
  load packing/large.json
  sleep 15
  list
  reset_round
done
```

## 2. Limit use of the serving worker

```sh
kubectl label node "$A" volcano.sh/nodegroup-name=v116-lab-train
kubectl label node "$B" volcano.sh/nodegroup-name=v116-lab-serve
use_config borrow.conf
load borrow/queue.json
load borrow/home.json && ready train-full
for i in 0 1; do load "borrow/borrow-$i.json" && ready "borrow-$i"; done
load borrow/borrow-2.json
sleep 10
list
kubectl annotate queue v116-lab-burst 'volcano.sh/nodegroup-resource-limits={"v116-lab-serve":{"nvidia.com/gpu":"3"}}' --overwrite
ready borrow-2
list
reset_round
kubectl delete -f borrow/queue.json
kubectl label node "$A" "$B" volcano.sh/nodegroup-name-
```

## 3. Separate replicas across synthetic racks

```sh
use_config domains.conf
load domains/topology.json
kubectl get hypernode
for policy in required preferred; do
  for i in 0 1; do load "domains/$policy-$i.json" && ready "replica-$i"; done
  load "domains/$policy-2.json"
  sleep 15
  list
  reset_round
done
kubectl delete hypernode v116-lab-site v116-lab-rack-a v116-lab-rack-b
```

## 4. Same-queue preemption and cross-queue reclaim

Use bare Pods so that a controller cannot replace an evicted victim during measurement. Compare original UIDs with surviving Running Pods. With equal priority and separate queues in the last round, examine the borrower's deserved resources. The five-Pod request needs 20 GPUs and cannot fit.

```sh
load eviction/priorities.json
for action in preempt gangpreempt gangreclaim; do
  use_config "$action.conf"
  scope=same
  sizes='2 5'
  if [ "$action" = gangreclaim ]; then scope=cross; sizes=2; fi
  load "eviction/$scope-queues.json"
  for size in $sizes; do
    load "eviction/$scope-incumbent.json" && ready incumbent
    kubectl -n "$N" get pod -l experiment=incumbent -o custom-columns=NAME:.metadata.name,UID:.metadata.uid
    load "eviction/$scope-arrival-$size.json"
    sleep 20
    list
    kubectl -n "$N" get events --sort-by=.lastTimestamp
    reset_round
  done
  kubectl delete -f "eviction/$scope-queues.json"
done
kubectl delete -f eviction/priorities.json
```

## Incumbent pairs at minimum membership

Repeat from an empty namespace after the previous eviction series. Both two-member groups need both members. One four-GPU challenger arrives. Compare the number of surviving members in each original group.

```sh
load eviction/priorities.json
load eviction/same-queues.json
for conf in tight-classic tight-whole tight-protected; do
  use_config "$conf.conf"
  load eviction/pair-1.json && ready pair-1
  load eviction/pair-2.json && ready pair-2
  load eviction/single.json
  sleep 20
  list
  kubectl -n "$N" get events --sort-by=.lastTimestamp
  reset_round
done
kubectl delete -f eviction/same-queues.json
kubectl delete -f eviction/priorities.json
```

## Restore

On early exit remove only the objects created in this run. Reconcile any externally changed configuration before restoring. On a clean run:

```sh
use_config original.conf
kubectl delete -f namespace.json
kubectl -n "$K" get deploy volcano-scheduler
kubectl get pg -A
kubectl get hypernode,queue
kubectl get nodes -L volcano.sh/nodegroup-name
```

## 5. Device attributes and claims with Volcano

Start this section after full cleanup of the earlier rounds, including restoration of the original scheduler configuration. Run on the same disposable cluster, with no existing gpu.example.com driver, ResourceSlices or DeviceClass. Install the SIGs example driver only on worker A. Its two synthetic 80Gi devices are independent of the fake B300 device plugin. Do not expose the same physical devices simultaneously through both inventory systems.

```sh
export A=first-worker
export N=v116-dra-lab
export KUBELET_ROOT=/var/lib/kubelet    # substitute the actual node kubelet root
kubectl api-resources --api-group=resource.k8s.io
kubectl get deviceclass,resourceslice
git clone --depth 1 --branch v0.5.0 https://github.com/kubernetes-sigs/dra-example-driver.git
helm install placement-dra ./dra-example-driver/deployments/helm/dra-example-driver \
  -n "$N" --create-namespace \
  --set kubeletPlugin.numDevices=2 \
  --set-string "kubeletPlugin.nodeSelector.kubernetes\\.io/hostname=$A" \
  --set-string "kubeletPlugin.kubeletRegistrarDirectoryPath=$KUBELET_ROOT/plugins_registry" \
  --set-string "kubeletPlugin.kubeletPluginsDirectoryPath=$KUBELET_ROOT/plugins"
kubectl -n "$N" rollout status ds/placement-dra-dra-example-driver-kubeletplugin
kubectl get resourceslice -o yaml
use_config dra/predicates.conf
kubectl create -f dra/template-need-96.json -f dra/template-index-one.json
kubectl create -f dra/pod-large-memory.json -f dra/pod-holder.json
kubectl -n "$N" wait --for=condition=Ready pod/holder --timeout=180s
kubectl -n "$N" logs holder
kubectl create -f dra/pod-waiter.json
kubectl -n "$N" get pod,resourceclaim
kubectl -n "$N" get pod waiter -o jsonpath='{.metadata.uid}'
kubectl -n "$N" delete pod holder
kubectl -n "$N" wait --for=condition=Ready pod/waiter --timeout=90s
kubectl -n "$N" get pod waiter -o jsonpath='{.metadata.uid}'
kubectl -n "$N" logs waiter
kubectl create -f dra/template-fallback.json -f dra/pod-fallback.json
kubectl -n "$N" get resourceclaim -o yaml
```

The templates ask for 96Gi, for 80Gi with index 1, or for the first available request in an ordered list. A fresh ResourceClaim is generated for each Pod. Capture Pod events, allocated device and subrequest names, and the container environment before cleanup. If the claim is allocated but the Pod is waiting, check kubelet events, both plugin socket directories and the container runtime's CDI support.

```sh
kubectl -n "$N" delete pod holder waiter fallback large-memory --ignore-not-found
kubectl -n "$N" get resourceclaim
helm uninstall placement-dra -n "$N"
kubectl delete ns "$N"
use_config original.conf
kubectl get resourceslice,deviceclass
```
