#!/usr/bin/env python3
"""
Reproducible Single-L20 Benchmark Suite:
  Qwen3.5-2B (Hybrid Full Attention + Gated DeltaNet Linear Attention) on vLLM 0.33.0
  - Exp 1: Online Multi-LoRA vs Offline Merged numerical equivalence (text + multimodal)
  - Exp 2: Single-L20 Multi-LoRA limit sweep (Base / 1 / 4 / 8 LoRAs x Concurrency; text short, text gen, multimodal 1:1)
  - Exp 3: Hybrid Architecture Prefix Cache (PC-Off vs mamba=align vs mamba=all, Multi-LoRA sharing/isolation, block alignment probe)
  - Exp 4: VRAM & slot accounting across max_loras and mamba_cache_mode

100% synthetic deterministic PEFT LoRA weights and synthetic PNG images; zero private data.
"""
import argparse
import asyncio
import base64
import io
import json
import math
import os
import re
import shutil
import signal
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path

import aiohttp
import torch
from PIL import Image, ImageDraw
from safetensors import safe_open
from safetensors.torch import save_file

MODEL_DIR = Path(os.environ.get("MODEL_DIR", "/models/Qwen3.5-2B"))
WORK_DIR = Path(os.environ.get("WORK_DIR", "/work"))
LORA_ROOT = WORK_DIR / "loras"
MERGED_DIR = WORK_DIR / "merged-lora-01"
IMG_DIR = WORK_DIR / "images"
RESULTS_PATH = WORK_DIR / "results.json"

# Standard Qwen3.5 text linear modules (both Full Attention, GDN Linear Attention, and MLP)
TARGET_SUFFIXES = (
    ".self_attn.q_proj.weight",
    ".self_attn.k_proj.weight",
    ".self_attn.v_proj.weight",
    ".self_attn.o_proj.weight",
    ".linear_attn.in_proj_qkv.weight",
    ".linear_attn.in_proj_z.weight",
    ".linear_attn.in_proj_a.weight",
    ".linear_attn.in_proj_b.weight",
    ".linear_attn.out_proj.weight",
    ".mlp.gate_proj.weight",
    ".mlp.up_proj.weight",
    ".mlp.down_proj.weight",
)


def log(msg: str):
    ts = time.strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def pct(vals, p):
    if not vals:
        return 0.0
    s = sorted(vals)
    idx = min(len(s) - 1, max(0, int(math.ceil(len(s) * p / 100.0)) - 1))
    return s[idx]


def median_round(rounds, key):
    return round(statistics.median([r[key] for r in rounds]), 3)


def discover_safetensor_files(model_dir: Path):
    index_file = model_dir / "model.safetensors.index.json"
    if index_file.exists():
        idx = json.loads(index_file.read_text())
        files = sorted(set(idx["weight_map"].values()))
        return [model_dir / f for f in files], idx["weight_map"]
    single = model_dir / "model.safetensors"
    if single.exists():
        with safe_open(str(single), framework="pt", device="cpu") as f:
            wm = {k: "model.safetensors" for k in f.keys()}
        return [single], wm
    raise FileNotFoundError(f"No safetensors found in {model_dir}")


def generate_synthetic_loras_and_merged(num_loras: int = 8, rank: int = 16, alpha: int = 32):
    """Deterministically generate PEFT LoRAs matching exact Qwen3.5-2B shapes + 1 exact merged copy."""
    LORA_ROOT.mkdir(parents=True, exist_ok=True)
    files, weight_map = discover_safetensor_files(MODEL_DIR)

    # Collect target tensor shapes & file ownership
    targets = []
    file_handles = {}
    try:
        for fp in files:
            file_handles[fp.name] = safe_open(str(fp), framework="pt", device="cpu")
        for k, fname in sorted(weight_map.items()):
            if "language_model.layers." in k and any(k.endswith(suf) for suf in TARGET_SUFFIXES):
                sl = file_handles[fname].get_slice(k)
                shape = tuple(sl.get_shape())
                if len(shape) == 2:
                    targets.append((k, fname, shape))
    finally:
        file_handles.clear()

    log(f"Discovered {len(targets)} target linear weights in {MODEL_DIR.name} (Full Attn + Linear Attn + MLP)")
    target_modules_short = sorted(set(k.split(".")[-2] for k, _, _ in targets))
    log(f"Target module types ({len(target_modules_short)}): {target_modules_short}")

    lora_01_tensors = None
    scale = alpha / float(rank)

    for idx in range(1, num_loras + 1):
        ldir = LORA_ROOT / f"lora-{idx:02d}"
        ldir.mkdir(parents=True, exist_ok=True)
        out_st = ldir / "adapter_model.safetensors"
        out_cfg = ldir / "adapter_config.json"
        if out_st.exists() and out_cfg.exists() and idx > 1:
            continue

        gen = torch.Generator().manual_seed(10000 + idx * 97)
        tensors = {}
        for k, _, (out_f, in_f) in targets:
            base_prefix = "base_model.model." + k[:-len(".weight")]
            # Non-zero small B so LoRA genuinely shifts logits while preserving coherent generation
            A = torch.randn((rank, in_f), generator=gen, dtype=torch.float32) * (1.0 / math.sqrt(in_f))
            B = torch.randn((out_f, rank), generator=gen, dtype=torch.float32) * 0.0025
            tensors[f"{base_prefix}.lora_A.weight"] = A.to(torch.bfloat16).contiguous()
            tensors[f"{base_prefix}.lora_B.weight"] = B.to(torch.bfloat16).contiguous()

        save_file(tensors, str(out_st))
        cfg = {
            "alpha_pattern": {},
            "auto_mapping": None,
            "base_model_name_or_path": str(MODEL_DIR),
            "bias": "none",
            "fan_in_fan_out": False,
            "inference_mode": True,
            "init_lora_weights": True,
            "lora_alpha": alpha,
            "lora_dropout": 0.0,
            "modules_to_save": None,
            "peft_type": "LORA",
            "r": rank,
            "rank_pattern": {},
            "revision": None,
            "target_modules": target_modules_short,
            "task_type": "CAUSAL_LM",
        }
        out_cfg.write_text(json.dumps(cfg, indent=2))
        size_mb = out_st.stat().st_size / (1024 * 1024)
        if idx == 1:
            lora_01_tensors = tensors
            log(f"Generated lora-01 .. lora-{num_loras:02d}: r={rank}, alpha={alpha}, {len(tensors)} tensors, {size_mb:.1f} MB each")

    # Build exact offline merged model for lora-01
    if not (MERGED_DIR / "merged_ready.flag").exists():
        log("Building exact offline-merged copy of lora-01 for numerical equivalence check...")
        if MERGED_DIR.exists():
            shutil.rmtree(MERGED_DIR)
        MERGED_DIR.mkdir(parents=True, exist_ok=True)
        # Symlink non-safetensor files (config, tokenizer, etc.)
        for item in MODEL_DIR.iterdir():
            if not item.name.endswith(".safetensors"):
                dst = MERGED_DIR / item.name
                if not dst.exists():
                    os.symlink(str(item), str(dst))
        # Merge weights shard by shard
        target_set = {k for k, _, _ in targets}
        for fp in files:
            merged_shard = {}
            with safe_open(str(fp), framework="pt", device="cpu") as f:
                for k in f.keys():
                    t = f.get_tensor(k)
                    if k in target_set:
                        bp = "base_model.model." + k[:-len(".weight")]
                        A = lora_01_tensors[f"{bp}.lora_A.weight"].to(torch.float32)
                        B = lora_01_tensors[f"{bp}.lora_B.weight"].to(torch.float32)
                        delta = (B @ A) * scale
                        t = (t.to(torch.float32) + delta).to(t.dtype).contiguous()
                    merged_shard[k] = t
            save_file(merged_shard, str(MERGED_DIR / fp.name))
        (MERGED_DIR / "merged_ready.flag").write_text("ok\n")
        log(f"Offline-merged model ready at {MERGED_DIR}")

    return {
        "num_loras": num_loras,
        "rank": rank,
        "alpha": alpha,
        "num_target_weights": len(targets),
        "target_modules": target_modules_short,
        "adapter_size_mb": round((LORA_ROOT / "lora-01/adapter_model.safetensors").stat().st_size / (1024 * 1024), 2),
    }


def generate_synthetic_images(count: int = 20):
    """Generate 20 clean synthetic 448x448 PNG images (charts/diagrams/geometric patterns)."""
    IMG_DIR.mkdir(parents=True, exist_ok=True)
    b64_list = []
    palette = [
        (46, 111, 94), (71, 85, 105), (180, 83, 9), (37, 99, 235),
        (124, 58, 237), (190, 24, 93), (15, 118, 110), (101, 163, 13),
    ]
    for i in range(count):
        p = IMG_DIR / f"img_{i:02d}.png"
        if not p.exists():
            im = Image.new("RGB", (448, 448), (248, 250, 252))
            d = ImageDraw.Draw(im)
            # Draw deterministic geometric bars & shapes
            c1 = palette[i % len(palette)]
            c2 = palette[(i + 3) % len(palette)]
            d.rectangle((24, 24, 424, 80), fill=c1)
            d.text((40, 44), f"SYNTHETIC BENCHMARK CARD #{i:02d}", fill=(255, 255, 255))
            for b in range(5):
                h = 60 + ((i * 37 + b * 53) % 200)
                x0 = 44 + b * 76
                d.rectangle((x0, 380 - h, x0 + 50, 380), fill=c1 if b % 2 == 0 else c2)
            d.ellipse((300 - (i * 7) % 120, 100, 380 - (i * 7) % 120, 180), outline=c2, width=5)
            d.line((30, 382, 418, 382), fill=(30, 41, 59), width=3)
            im.save(p, format="PNG")
        b64 = base64.b64encode(p.read_bytes()).decode("ascii")
        b64_list.append(f"data:image/png;base64,{b64}")
    return b64_list


class GpuSampler:
    def __init__(self, interval=0.3):
        self.interval = interval
        self.stop_evt = threading.Event()
        self.utils = []
        self.mems = []
        self.thread = None

    def _run(self):
        while not self.stop_evt.is_set():
            try:
                out = subprocess.check_output(
                    ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used", "--format=csv,noheader,nounits"],
                    text=True,
                    timeout=2,
                ).strip()
                parts = [x.strip() for x in out.splitlines()[0].split(",")]
                self.utils.append(float(parts[0]))
                self.mems.append(float(parts[1]))
            except Exception:
                pass
            self.stop_evt.wait(self.interval)

    def start(self):
        self.utils.clear()
        self.mems.clear()
        self.stop_evt.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_evt.set()
        if self.thread:
            self.thread.join(timeout=2)
        return {
            "gpu_util_avg": round(statistics.mean(self.utils), 1) if self.utils else 0.0,
            "gpu_util_max": round(max(self.utils), 1) if self.utils else 0.0,
            "vram_used_mib_max": round(max(self.mems), 1) if self.mems else 0.0,
        }


def parse_vllm_startup_log(log_path: Path):
    txt = log_path.read_text(errors="replace")
    info = {}
    m = re.search(r"Model loading took ([0-9.]+) GiB", txt)
    if m:
        info["model_weight_gib"] = float(m.group(1))
    m = re.search(r"Available KV cache memory:\s*([0-9.]+)\s*GiB", txt)
    if m:
        info["available_kv_gib"] = float(m.group(1))
    m = re.search(r"GPU KV cache size:\s*([0-9,]+)\s*tokens", txt)
    if m:
        info["kv_cache_tokens"] = int(m.group(1).replace(",", ""))
    m = re.search(r"Maximum concurrency for [^:]+:\s*([0-9.]+)x", txt)
    if m:
        info["max_concurrency_8k"] = float(m.group(1))
    # Capture hybrid/mamba lines
    hybrid_lines = [
        ln.strip()
        for ln in txt.splitlines()
        if any(k in ln.lower() for k in ["mamba", "hybrid", "kv cache", "block_size", "prefix caching", "lora", "page size"])
    ]
    info["key_log_lines"] = hybrid_lines[-30:]
    return info


class VllmServer:
    def __init__(self, port: int, model: str, extra_args: list, log_name: str):
        self.port = port
        self.model = model
        self.extra_args = extra_args
        self.log_path = WORK_DIR / log_name
        self.proc = None

    def start(self, timeout: int = 420):
        cmd = [
            "vllm", "serve", self.model,
            "--host", "127.0.0.1",
            "--port", str(self.port),
            "--dtype", "bfloat16",
            "--max-model-len", "8192",
            "--max-cudagraph-capture-size", "64",
            "--trust-remote-code",
        ] + self.extra_args
        log(f"Starting vLLM on :{self.port}: {' '.join(cmd[:14])} ...")
        self.log_f = open(self.log_path, "w")
        env = os.environ.copy()
        env["VLLM_LOGGING_LEVEL"] = "INFO"
        self.proc = subprocess.Popen(cmd, stdout=self.log_f, stderr=subprocess.STDOUT, env=env, preexec_fn=os.setsid)
        t0 = time.monotonic()
        import urllib.request
        while time.monotonic() - t0 < timeout:
            if self.proc.poll() is not None:
                self.log_f.flush()
                tail = "\n".join(self.log_path.read_text(errors="replace").splitlines()[-50:])
                raise RuntimeError(f"vLLM :{self.port} exited early (rc={self.proc.returncode}):\n{tail}")
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{self.port}/health", timeout=2) as r:
                    if r.status == 200:
                        elapsed = time.monotonic() - t0
                        log(f"vLLM :{self.port} ready in {elapsed:.1f}s")
                        return parse_vllm_startup_log(self.log_path)
            except Exception:
                pass
            time.sleep(1.5)
        raise TimeoutError(f"vLLM :{self.port} timed out after {timeout}s")

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
                self.proc.wait(timeout=15)
            except Exception:
                try:
                    os.killpg(os.getpgid(self.proc.pid), signal.SIGKILL)
                except Exception:
                    pass
        if hasattr(self, "log_f") and self.log_f:
            self.log_f.close()
        time.sleep(2.0)


async def fetch_metrics(session: aiohttp.ClientSession, port: int):
    async with session.get(f"http://127.0.0.1:{port}/metrics", timeout=aiohttp.ClientTimeout(total=5)) as r:
        txt = await r.text()
    out = {}
    for name in [
        "vllm:prefix_cache_hits_total",
        "vllm:prefix_cache_queries_total",
        "vllm:prompt_tokens_total",
        "vllm:generation_tokens_total",
        "vllm:request_success_total",
    ]:
        total = 0.0
        for ln in txt.splitlines():
            if ln.startswith(name) and not ln.startswith("#"):
                try:
                    total += float(ln.split()[-1])
                except Exception:
                    pass
        out[name] = total
    return out


def make_filler_text(target_words: int, seed: int) -> str:
    vocab = [
        "kubernetes", "scheduler", "adapter", "throughput", "latency", "tensor", "memory",
        "bandwidth", "cluster", "container", "inference", "context", "attention", "linear",
        "recurrent", "cache", "prefill", "decode", "routing", "batch", "quantization",
        "pipeline", "replica", "workload", "metrics", "profile", "benchmark", "gateway",
        "checkpoint", "dispatch", "isolation", "capacity", "scaling", "topology", "network",
    ]
    words = [vocab[(seed * 13 + i * 7 + (i // 5) * 3) % len(vocab)] for i in range(target_words)]
    return " ".join(words)


def make_shared_system_prompt(target_tokens_approx: int = 900) -> str:
    # Structured deterministic policy prompt (~900 tokens)
    clauses = []
    for i in range(1, 35):
        clauses.append(
            f"Rule {i:02d}: Inspect incoming technical telemetry record category-{i:02d}, "
            f"check GPU memory pressure, queue depth, KV cache residency, prefix alignment, "
            f"and classify operational status strictly as PASS, WARN, or ALERT with concise rationale."
        )
    text = (
        "You are an automated Kubernetes AI infrastructure evaluator. "
        "Follow every compliance and routing rule below without exception.\n"
        + "\n".join(clauses)
    )
    # Trim or pad to ~target_tokens_approx (approx 1.3 tokens/word in English technical text)
    words = text.split()
    want_words = int(target_tokens_approx / 1.35)
    while len(words) < want_words:
        words.extend(clauses[len(words) % len(clauses)].split())
    return " ".join(words[:want_words])


async def send_chat_stream(session, url, payload):
    t0 = time.perf_counter()
    ttft = None
    chunks = 0
    prompt_tokens = 0
    completion_tokens = 0
    ok = False
    err = None
    try:
        async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=120)) as resp:
            if resp.status != 200:
                err = f"HTTP {resp.status}: {(await resp.text())[:160]}"
                return {"ok": False, "err": err, "e2e_ms": (time.perf_counter() - t0) * 1000}
            async for raw in resp.content:
                line = raw.decode("utf-8", errors="ignore").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                except Exception:
                    continue
                if obj.get("usage"):
                    prompt_tokens = obj["usage"].get("prompt_tokens", prompt_tokens)
                    completion_tokens = obj["usage"].get("completion_tokens", completion_tokens)
                choices = obj.get("choices") or []
                if choices:
                    delta = choices[0].get("delta") or {}
                    content = delta.get("content") or delta.get("reasoning_content") or ""
                    if content:
                        if ttft is None:
                            ttft = (time.perf_counter() - t0) * 1000.0
                        chunks += 1
            ok = True
    except Exception as e:
        err = repr(e)
    e2e = (time.perf_counter() - t0) * 1000.0
    if ttft is None:
        ttft = e2e
    tpot = (e2e - ttft) / max(1, (completion_tokens or chunks) - 1) if (completion_tokens or chunks) > 1 else 0.0
    return {
        "ok": ok,
        "err": err,
        "ttft_ms": ttft,
        "e2e_ms": e2e,
        "tpot_ms": tpot,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens or chunks,
    }


async def run_load_round(port: int, payloads: list, concurrency: int):
    url = f"http://127.0.0.1:{port}/v1/chat/completions"
    sem = asyncio.Semaphore(concurrency)
    connector = aiohttp.TCPConnector(limit=max(128, concurrency * 2))
    sampler = GpuSampler(0.25)
    async with aiohttp.ClientSession(connector=connector) as session:
        m0 = await fetch_metrics(session, port)
        sampler.start()
        t_start = time.perf_counter()

        async def worker(p):
            async with sem:
                return await send_chat_stream(session, url, p)

        results = await asyncio.gather(*(worker(p) for p in payloads))
        wall_s = time.perf_counter() - t_start
        gpu_stats = sampler.stop()
        m1 = await fetch_metrics(session, port)

    ok_res = [r for r in results if r["ok"]]
    ttfts = [r["ttft_ms"] for r in ok_res]
    e2es = [r["e2e_ms"] for r in ok_res]
    tpots = [r["tpot_ms"] for r in ok_res if r["tpot_ms"] > 0]
    total_prompt = sum(r["prompt_tokens"] for r in ok_res) or (m1["vllm:prompt_tokens_total"] - m0["vllm:prompt_tokens_total"])
    total_comp = sum(r["completion_tokens"] for r in ok_res) or (m1["vllm:generation_tokens_total"] - m0["vllm:generation_tokens_total"])
    pc_hits = m1["vllm:prefix_cache_hits_total"] - m0["vllm:prefix_cache_hits_total"]
    pc_queries = m1["vllm:prefix_cache_queries_total"] - m0["vllm:prefix_cache_queries_total"]
    pc_rate = (pc_hits / pc_queries * 100.0) if pc_queries > 0 else 0.0

    return {
        "n_total": len(payloads),
        "n_ok": len(ok_res),
        "n_err": len(payloads) - len(ok_res),
        "wall_s": round(wall_s, 3),
        "qps": round(len(ok_res) / wall_s, 2) if wall_s > 0 else 0.0,
        "output_tok_s": round(total_comp / wall_s, 1) if wall_s > 0 else 0.0,
        "prompt_tok_s": round(total_prompt / wall_s, 1) if wall_s > 0 else 0.0,
        "avg_prompt_tok": round(total_prompt / max(1, len(ok_res)), 1),
        "avg_comp_tok": round(total_comp / max(1, len(ok_res)), 1),
        "ttft_p50_ms": round(pct(ttfts, 50), 1),
        "ttft_p95_ms": round(pct(ttfts, 95), 1),
        "ttft_p99_ms": round(pct(ttfts, 99), 1),
        "tpot_p50_ms": round(pct(tpots, 50), 2) if tpots else 0.0,
        "e2e_p50_ms": round(pct(e2es, 50), 1),
        "e2e_p95_ms": round(pct(e2es, 95), 1),
        "e2e_p99_ms": round(pct(e2es, 99), 1),
        "pc_hits": round(pc_hits, 1),
        "pc_queries": round(pc_queries, 1),
        "pc_hit_rate_pct": round(pc_rate, 2),
        **gpu_stats,
    }


def summarize_rounds(rounds):
    keys = [
        "qps", "output_tok_s", "prompt_tok_s", "avg_prompt_tok", "avg_comp_tok",
        "ttft_p50_ms", "ttft_p95_ms", "ttft_p99_ms", "tpot_p50_ms",
        "e2e_p50_ms", "e2e_p95_ms", "e2e_p99_ms", "pc_hit_rate_pct",
        "gpu_util_avg", "gpu_util_max", "vram_used_mib_max",
    ]
    med = {k: median_round(rounds, k) for k in keys}
    med["n_ok_total"] = sum(r["n_ok"] for r in rounds)
    med["n_total_all"] = sum(r["n_total"] for r in rounds)
    med["rounds"] = rounds
    return med


async def exp1_equivalence(images_b64):
    """Exp 1: Online Multi-LoRA vs Offline Merged exact numerical equivalence."""
    log("=== EXP 1: Online Multi-LoRA vs Offline Merged Equivalence (Text + Multimodal) ===")
    lora_args = [
        "--served-model-name", "qwen35-2b-base",
        "--gpu-memory-utilization", "0.40",
        "--enable-lora",
        "--max-loras", "4",
        "--max-lora-rank", "16",
        "--lora-modules",
        f"lora-01={LORA_ROOT}/lora-01",
        f"lora-02={LORA_ROOT}/lora-02",
        f"lora-03={LORA_ROOT}/lora-03",
        f"lora-04={LORA_ROOT}/lora-04",
    ]
    merged_args = [
        "--served-model-name", "merged-lora-01",
        "--gpu-memory-utilization", "0.40",
    ]
    s_lora = VllmServer(8000, str(MODEL_DIR), lora_args, "vllm_exp1_lora.log")
    s_merged = VllmServer(8001, str(MERGED_DIR), merged_args, "vllm_exp1_merged.log")
    try:
        s_lora.start()
        s_merged.start()

        async def query_one(session, port, model, messages):
            payload = {
                "model": model,
                "messages": messages,
                "temperature": 0.0,
                "max_tokens": 16,
                "logprobs": True,
                "top_logprobs": 3,
                "chat_template_kwargs": {"enable_thinking": False},
            }
            async with session.post(f"http://127.0.0.1:{port}/v1/chat/completions", json=payload, timeout=aiohttp.ClientTimeout(total=60)) as r:
                obj = await r.json()
            ch = obj["choices"][0]
            txt = ch["message"]["content"]
            lp_content = (ch.get("logprobs") or {}).get("content") or []
            first_tok = lp_content[0]["token"] if lp_content else ""
            first_lp = lp_content[0]["logprob"] if lp_content else 0.0
            return txt, first_tok, first_lp

        text_prompts = [
            f"Sample {i:02d}: Summarize in one short sentence the key engineering trade-off of {make_filler_text(18, i)}."
            for i in range(50)
        ]

        text_exact = 0
        text_first_tok_match = 0
        text_lp_diffs = []
        base_diff_count = 0
        base_lp_diffs = []

        img_exact = 0
        img_first_tok_match = 0
        img_lp_diffs = []
        img_base_diff = 0

        async with aiohttp.ClientSession() as session:
            for i, pr in enumerate(text_prompts):
                msgs = [{"role": "user", "content": pr}]
                t_lora, ft_lora, lp_lora = await query_one(session, 8000, "lora-01", msgs)
                t_mrg, ft_mrg, lp_mrg = await query_one(session, 8001, "merged-lora-01", msgs)
                if t_lora == t_mrg:
                    text_exact += 1
                if ft_lora == ft_mrg:
                    text_first_tok_match += 1
                    text_lp_diffs.append(abs(lp_lora - lp_mrg))
                if i < 20:
                    t_base, ft_base, lp_base = await query_one(session, 8000, "qwen35-2b-base", msgs)
                    if t_base != t_lora or abs(lp_base - lp_lora) > 0.01:
                        base_diff_count += 1
                    base_lp_diffs.append(abs(lp_base - lp_lora))

            for i in range(20):
                msgs = [{
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": images_b64[i]}},
                        {"type": "text", "text": f"Card #{i:02d}: Briefly describe the header color and bar chart layout in one sentence."},
                    ],
                }]
                t_lora, ft_lora, lp_lora = await query_one(session, 8000, "lora-01", msgs)
                t_mrg, ft_mrg, lp_mrg = await query_one(session, 8001, "merged-lora-01", msgs)
                if t_lora == t_mrg:
                    img_exact += 1
                if ft_lora == ft_mrg:
                    img_first_tok_match += 1
                    img_lp_diffs.append(abs(lp_lora - lp_mrg))
                if i < 10:
                    t_base, ft_base, lp_base = await query_one(session, 8000, "qwen35-2b-base", msgs)
                    if t_base != t_lora or abs(lp_base - lp_lora) > 0.01:
                        img_base_diff += 1

        res = {
            "text_samples": 50,
            "text_exact_16tok_match": text_exact,
            "text_first_tok_match": text_first_tok_match,
            "text_first_tok_lp_mae": round(statistics.mean(text_lp_diffs), 6) if text_lp_diffs else 0.0,
            "text_first_tok_lp_max": round(max(text_lp_diffs), 6) if text_lp_diffs else 0.0,
            "text_base_vs_lora_diverged_of_20": base_diff_count,
            "text_base_vs_lora_lp_mae": round(statistics.mean(base_lp_diffs), 5) if base_lp_diffs else 0.0,
            "image_samples": 20,
            "image_exact_16tok_match": img_exact,
            "image_first_tok_match": img_first_tok_match,
            "image_first_tok_lp_mae": round(statistics.mean(img_lp_diffs), 6) if img_lp_diffs else 0.0,
            "image_first_tok_lp_max": round(max(img_lp_diffs), 6) if img_lp_diffs else 0.0,
            "image_base_vs_lora_diverged_of_10": img_base_diff,
        }
        log(f"EXP 1 RESULT: {json.dumps(res)}")
        return res
    finally:
        s_merged.stop()
        s_lora.stop()


def build_unique_text_payloads(models: list, count: int, prompt_words: int, max_tokens: int, seed_offset: int):
    payloads = []
    for i in range(count):
        m = models[i % len(models)]
        # Unique prefix so prefix caching cannot mask pure compute
        txt = f"[req-{seed_offset}-{i:04d}] Evaluate system log trace: " + make_filler_text(prompt_words, seed_offset * 1000 + i)
        payloads.append({
            "model": m,
            "messages": [{"role": "user", "content": txt}],
            "temperature": 0.0,
            "max_tokens": max_tokens,
            "ignore_eos": True,
            "stream": True,
            "stream_options": {"include_usage": True},
            "chat_template_kwargs": {"enable_thinking": False},
        })
    return payloads


def build_multimodal_mixed_payloads(models: list, images_b64: list, count: int, max_tokens: int, seed_offset: int):
    payloads = []
    for i in range(count):
        m = models[i % len(models)]
        if i % 2 == 0:
            txt = f"[mm-txt-{seed_offset}-{i:04d}] Audit record: " + make_filler_text(360, seed_offset * 1000 + i)
            msgs = [{"role": "user", "content": txt}]
        else:
            img = images_b64[i % len(images_b64)]
            msgs = [{
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": img}},
                    {"type": "text", "text": f"[mm-img-{seed_offset}-{i:04d}] Classify card #{i} status as PASS or ALERT."},
                ],
            }]
        payloads.append({
            "model": m,
            "messages": msgs,
            "temperature": 0.0,
            "max_tokens": max_tokens,
            "ignore_eos": True,
            "stream": True,
            "stream_options": {"include_usage": True},
            "chat_template_kwargs": {"enable_thinking": False},
        })
    return payloads


async def exp2_limit_sweep(images_b64):
    """Exp 2: Single-L20 Multi-LoRA limit sweep (PC-Off to measure raw compute + LoRA scaling)."""
    log("=== EXP 2: Single-L20 Multi-LoRA Limit Sweep (PC-Off, 3 Rounds Median) ===")
    lora_mods = [f"lora-{i:02d}={LORA_ROOT}/lora-{i:02d}" for i in range(1, 9)]
    args = [
        "--served-model-name", "qwen35-2b-base",
        "--gpu-memory-utilization", "0.90",
        "--max-num-seqs", "128",
        "--no-enable-prefix-caching",
        "--enable-lora",
        "--max-loras", "8",
        "--max-lora-rank", "16",
        "--lora-modules", *lora_mods,
    ]
    srv = VllmServer(8000, str(MODEL_DIR), args, "vllm_exp2_limit.log")
    out = {"startup": {}, "short_classification": {}, "standard_generation": {}, "multimodal_4lora": {}}
    try:
        out["startup"] = srv.start()
        # Warmup
        await run_load_round(8000, build_unique_text_payloads(["qwen35-2b-base", "lora-01", "lora-02", "lora-03", "lora-04", "lora-05", "lora-06", "lora-07", "lora-08"], 16, 120, 4, 999), 8)

        # 2A: Short classification (~512 tok in -> 4 tok out)
        profiles = [
            ("base", ["qwen35-2b-base"]),
            ("lora_1", ["lora-01"]),
            ("lora_4", [f"lora-{i:02d}" for i in range(1, 5)]),
            ("lora_8", [f"lora-{i:02d}" for i in range(1, 9)]),
        ]
        for pname, models in profiles:
            out["short_classification"][pname] = {}
            for conc in [1, 8, 16, 32, 64]:
                n_req = 16 if conc == 1 else max(48, conc * 2)
                rounds = []
                for rd in range(3):
                    pl = build_unique_text_payloads(models, n_req, 360, 4, 100 + rd * 10 + conc)
                    r = await run_load_round(8000, pl, conc)
                    rounds.append(r)
                med = summarize_rounds(rounds)
                out["short_classification"][pname][f"c{conc}"] = med
                log(f"2A [{pname:6s} c={conc:2d}] QPS={med['qps']:6.2f} | TTFT p50/p95={med['ttft_p50_ms']:5.1f}/{med['ttft_p95_ms']:5.1f}ms | E2E p50/p95={med['e2e_p50_ms']:5.1f}/{med['e2e_p95_ms']:5.1f}ms | GPU={med['gpu_util_avg']:4.1f}%")

        # 2B: Standard generation (~512 tok in -> 64 tok out)
        for pname, models in profiles:
            out["standard_generation"][pname] = {}
            for conc in [1, 16, 32]:
                n_req = 8 if conc == 1 else max(32, conc * 2)
                rounds = []
                for rd in range(3):
                    pl = build_unique_text_payloads(models, n_req, 360, 64, 300 + rd * 10 + conc)
                    r = await run_load_round(8000, pl, conc)
                    rounds.append(r)
                med = summarize_rounds(rounds)
                out["standard_generation"][pname][f"c{conc}"] = med
                log(f"2B [{pname:6s} c={conc:2d}] QPS={med['qps']:5.2f} | OutTok/s={med['output_tok_s']:6.1f} | TTFT p50={med['ttft_p50_ms']:5.1f}ms | TPOT p50={med['tpot_p50_ms']:4.2f}ms | GPU={med['gpu_util_avg']:4.1f}%")

        # 2C: Multimodal 1:1 mixed (4 LoRAs, ~512 tok text + 448x448 PNG -> 4 tok out)
        mm_models = [f"lora-{i:02d}" for i in range(1, 5)]
        for conc in [1, 8, 16, 32]:
            n_req = 20 if conc == 1 else max(48, conc * 2)
            rounds = []
            for rd in range(3):
                pl = build_multimodal_mixed_payloads(mm_models, images_b64, n_req, 4, 500 + rd * 10 + conc)
                r = await run_load_round(8000, pl, conc)
                rounds.append(r)
            med = summarize_rounds(rounds)
            out["multimodal_4lora"][f"c{conc}"] = med
            log(f"2C [mm-4lora c={conc:2d}] QPS={med['qps']:6.2f} | TTFT p50/p95={med['ttft_p50_ms']:5.1f}/{med['ttft_p95_ms']:5.1f}ms | E2E p50/p95={med['e2e_p50_ms']:5.1f}/{med['e2e_p95_ms']:5.1f}ms | GPU={med['gpu_util_avg']:4.1f}%")

        return out
    finally:
        srv.stop()


def build_shared_prefix_payloads(models: list, sys_prompt: str, count: int, max_tokens: int, seed_offset: int):
    payloads = []
    for i in range(count):
        m = models[i % len(models)]
        user_msg = f"Event #{seed_offset}-{i:04d}: node-{(i%8)+1} gpu-util={(i*17)%100}% queue={i%6} kv={(i*13)%95}%. Return status."
        payloads.append({
            "model": m,
            "messages": [
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": user_msg},
            ],
            "temperature": 0.0,
            "max_tokens": max_tokens,
            "ignore_eos": True,
            "stream": True,
            "stream_options": {"include_usage": True},
            "chat_template_kwargs": {"enable_thinking": False},
        })
    return payloads


async def exp3_hybrid_prefix_cache():
    """Exp 3: Hybrid Architecture (Full Attn + GDN Linear Attn) Prefix Cache modes & Multi-LoRA interaction."""
    log("=== EXP 3: Hybrid Prefix Cache Modes (PC-Off vs align vs align+ckpt) & Multi-LoRA Sharing ===")
    sys_prompt_1150 = make_shared_system_prompt(1150)
    lora_mods = [f"lora-{i:02d}={LORA_ROOT}/lora-{i:02d}" for i in range(1, 5)]
    base_lora_args = [
        "--served-model-name", "qwen35-2b-base",
        "--gpu-memory-utilization", "0.90",
        "--max-num-seqs", "128",
        "--enable-lora",
        "--max-loras", "4",
        "--max-lora-rank", "16",
        "--lora-modules", *lora_mods,
    ]
    modes = [
        ("pc_off", ["--no-enable-prefix-caching"]),
        ("pc_align", ["--enable-prefix-caching", "--mamba-cache-mode", "align"]),
        ("pc_align_ckpt", ["--enable-prefix-caching", "--mamba-cache-mode", "align", "--enable-mamba-shared-prefix-checkpoint"]),
    ]
    out = {}
    for mname, extra in modes:
        srv = VllmServer(8000, str(MODEL_DIR), base_lora_args + extra, f"vllm_exp3_{mname}.log")
        mode_res = {"startup": {}, "workloads": {}, "prefix_length_probe": {}}
        try:
            mode_res["startup"] = srv.start()
            patterns = [
                ("base", ["qwen35-2b-base"]),
                ("lora_1", ["lora-01"]),
                ("lora_4", [f"lora-{i:02d}" for i in range(1, 5)]),
            ]
            for pat_name, models in patterns:
                mode_res["workloads"][pat_name] = {}
                await run_load_round(8000, build_shared_prefix_payloads(models, sys_prompt_1150, max(8, len(models) * 3), 4, 880), 4)
                for conc in [1, 8, 16, 32]:
                    n_req = 16 if conc == 1 else max(48, conc * 2)
                    rounds = []
                    for rd in range(3):
                        pl = build_shared_prefix_payloads(models, sys_prompt_1150, n_req, 4, 700 + rd * 20 + conc)
                        r = await run_load_round(8000, pl, conc)
                        rounds.append(r)
                    med = summarize_rounds(rounds)
                    mode_res["workloads"][pat_name][f"c{conc}"] = med
                    log(f"3 [{mname:13s} | {pat_name:6s} | c={conc:2d}] QPS={med['qps']:6.2f} | TTFT p50/p95={med['ttft_p50_ms']:5.1f}/{med['ttft_p95_ms']:5.1f}ms | PC_hit={med['pc_hit_rate_pct']:5.1f}% | AvgIn={med['avg_prompt_tok']}")

            # Prefix length alignment probe straddling 544 and 1088 hybrid block boundaries!
            if mname != "pc_off":
                for approx_len in [450, 560, 980, 1140]:
                    sp = make_shared_system_prompt(approx_len)
                    await run_load_round(8000, build_shared_prefix_payloads(["lora-01"], sp, 3, 4, 910 + approx_len), 1)
                    r = await run_load_round(8000, build_shared_prefix_payloads(["lora-01"], sp, 20, 4, 950 + approx_len), 4)
                    mode_res["prefix_length_probe"][f"len_{approx_len}"] = r
                    log(f"3-PROBE [{mname:13s} | len~{approx_len:4d}] AvgIn={r['avg_prompt_tok']:6.1f} | PC_hit={r['pc_hit_rate_pct']:5.1f}% | TTFT p50={r['ttft_p50_ms']:5.1f}ms | QPS={r['qps']:6.2f}")
        finally:
            srv.stop()
        out[mname] = mode_res
    return out


async def exp4_vram_accounting():
    """Exp 4: Startup VRAM & KV/Mamba cache capacity accounting across max_loras & mamba_cache_mode."""
    log("=== EXP 4: Startup VRAM & KV/GDN Cache Accounting ===")
    configs = [
        ("base_no_lora_pc_off", ["--no-enable-prefix-caching"]),
        ("base_no_lora_pc_align", ["--enable-prefix-caching", "--mamba-cache-mode", "align"]),
        ("base_no_lora_pc_align_ckpt", ["--enable-prefix-caching", "--mamba-cache-mode", "align", "--enable-mamba-shared-prefix-checkpoint"]),
        ("lora_max4_pc_align", ["--enable-prefix-caching", "--mamba-cache-mode", "align", "--enable-lora", "--max-loras", "4", "--max-lora-rank", "16"]),
        ("lora_max8_pc_align", ["--enable-prefix-caching", "--mamba-cache-mode", "align", "--enable-lora", "--max-loras", "8", "--max-lora-rank", "16"]),
        ("lora_max16_pc_align", ["--enable-prefix-caching", "--mamba-cache-mode", "align", "--enable-lora", "--max-loras", "16", "--max-lora-rank", "16"]),
    ]
    out = {}
    for name, extra in configs:
        args = ["--served-model-name", "qwen35-2b-base", "--gpu-memory-utilization", "0.90", "--max-num-seqs", "128"] + extra
        srv = VllmServer(8000, str(MODEL_DIR), args, f"vllm_exp4_{name}.log")
        try:
            info = srv.start()
            # Capture live nvidia-smi used memory
            mem_out = subprocess.check_output(["nvidia-smi", "--query-gpu=memory.used,memory.total", "--format=csv,noheader,nounits"], text=True).strip()
            used_mib, total_mib = [float(x.strip()) for x in mem_out.splitlines()[0].split(",")]
            info["nvidia_smi_used_mib"] = used_mib
            info["nvidia_smi_total_mib"] = total_mib
            out[name] = info
            log(f"4 [{name:24s}] weight={info.get('model_weight_gib')} GiB | avail_kv={info.get('available_kv_gib')} GiB | kv_toks={info.get('kv_cache_tokens')} | smi_used={used_mib:.0f} MiB")
        finally:
            srv.stop()
    return out


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-exp1", action="store_true")
    parser.add_argument("--skip-exp4", action="store_true")
    args = parser.parse_args()

    WORK_DIR.mkdir(parents=True, exist_ok=True)
    gpu_info = subprocess.check_output(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"], text=True).strip()
    import vllm, transformers
    results = json.loads(RESULTS_PATH.read_text()) if RESULTS_PATH.exists() else {}
    results["meta"] = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
        "gpu": gpu_info,
        "vllm_version": vllm.__version__,
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "transformers_version": transformers.__version__,
        "model": MODEL_DIR.name,
    }

    if not args.skip_exp1:
        results["lora_spec"] = generate_synthetic_loras_and_merged(num_loras=8, rank=16, alpha=32)
    else:
        # Only generate LoRAs (no need to rebuild merged model)
        (MERGED_DIR).mkdir(parents=True, exist_ok=True)
        (MERGED_DIR / "merged_ready.flag").write_text("skip\n")
        results["lora_spec"] = generate_synthetic_loras_and_merged(num_loras=8, rank=16, alpha=32)
    images_b64 = generate_synthetic_images(20)
    RESULTS_PATH.write_text(json.dumps(results, indent=2))

    if not args.skip_exp1:
        results["exp1_equivalence"] = await exp1_equivalence(images_b64)
        RESULTS_PATH.write_text(json.dumps(results, indent=2))

    results["exp2_limit_sweep"] = await exp2_limit_sweep(images_b64)
    RESULTS_PATH.write_text(json.dumps(results, indent=2))

    results["exp3_hybrid_prefix_cache"] = await exp3_hybrid_prefix_cache()
    RESULTS_PATH.write_text(json.dumps(results, indent=2))

    if not args.skip_exp4:
        results["exp4_vram_accounting"] = await exp4_vram_accounting()
        RESULTS_PATH.write_text(json.dumps(results, indent=2))

    log(f"ALL EXPERIMENTS COMPLETE! Results saved to {RESULTS_PATH}")


if __name__ == "__main__":
    asyncio.run(main())
