# Single-L20 Qwen3.5-2B Hybrid Multi-LoRA & Prefix Cache Benchmark Kit

Reproducible benchmark script used in the aik8s practice guide.

## Contents
- `run_bench.py`: Generates 8 deterministic synthetic PEFT LoRAs (`r=16, alpha=32`, 186 weights across Full Attention, GDN Linear Attention, and MLP), 1 exact offline-merged reference model, and 20 synthetic 448x448 PNG images, then runs all 4 controlled experiments with 3-round medians.

## Quick Start
```bash
export MODEL_DIR=/path/to/Qwen3.5-2B
export WORK_DIR=/tmp/hybrid-lora-bench
python3 run_bench.py
```
