# Kubernetes v1.37 DRA Advanced Lab Kit

Reproduces three hands-on DRA suites on Kubernetes v1.37.2, Volcano v1.16.0, and dra-example-driver v0.5.0:
1. Cross-driver PCIe Root topology alignment (`gpu.example.com` + `net.example.com`, `matchAttribute: resource.kubernetes.io/pcieRoot`) on both `kube-scheduler` and Volcano v1.16.0.
2. Consumable capacity (`AllowMultipleAllocations`) fractional GPU sharing with distinct `ShareID`s + Volcano v1.16.0 `memory.deviceclass/*` queue quota.
3. KEP-4680 device health reporting (`allocatedResourcesStatus`) + single-GPU fault quarantine via `DeviceTaintRule (NoExecute)`.

## Quick Start
1. Install `dra-example-driver` v0.5.0 twice into `dra-adv-lab` (`deviceProfile=gpu` with `gpuPublishPCIeRoot=true,gpuAllowMultipleAllocations=true,kubeletPlugin.numDevices=4,kubeletPlugin.deviceHealth=true` and `deviceProfile=net` with `netPublishPCIeRoot=true,kubeletPlugin.numDevices=2`). Set custom `kubeletRegistrarDirectoryPath` / `kubeletPluginsDirectoryPath` if your kubelet root is nonstandard.
2. Apply `volcano-dra-queue.yaml` and run an isolated Volcano v1.16.0 scheduler with `predicate.DynamicResourceAllocationEnable: true`, `capacity.DynamicResourceAllocationEnable: true`, and `capacity.DRAConsumableCapacityEnable: true`.
3. Set `export LAB_CONTEXT=<your-test-context>` and `export LAB_NODE=<worker-hostname>`, then run `python3 run_dra_suite.py`.
