import os
#!/usr/bin/env python3
"""Kubernetes v1.37.2 DRA Advanced Lab Runner:
Suite 1: Cross-Driver PCIe Root Topology Alignment (gpu.example.com + net.example.com)
  1A: Control (no matchAttribute) -> cross-PCIe-root mismatch (gpu-1 pci0000:80 + nic-0 pci0000:00)
  1B: Aligned (matchAttribute: resource.kubernetes.io/pcieRoot) across all 4 GPUs on kube-scheduler
  1C: Hard-constraint protection when matching-PCIe NIC is tainted (Pending instead of silent mis-placement)
  1D: Volcano v1.16.0 cross-driver matchAttribute compatibility check
Suite 2: Consumable Capacity (AllowMultipleAllocations) & Volcano v1.16.0 Queue Quota
  2A: 3 Pods sharing gpu-0 (3 x 24Gi/30 = 72Gi/90 <= 80Gi/100) with distinct ShareIDs + Pod 4 rejected (96Gi > 80Gi) + handoff on delete + invalid RequestPolicy check
  2B: Volcano v1.16.0 memory.deviceclass/gpu.example.com=48Gi Queue Quota across 4 GPUs (320Gi free)
Suite 3: KEP-4680 Device Health Reporting & Single-GPU Fault Quarantine (DeviceTaintRule)
  3A: Healthy -> Unhealthy -> Unknown -> Unhealthy propagation latency & proving kubelet does NOT auto-evict
  3B: Closed-loop watchdog applies DeviceTaintRule(NoExecute) on faulty GPU only -> replacement Pod heals onto spare healthy GPU with 0% disruption to sibling Pod on same node!
"""
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

CTX = os.environ.get("LAB_CONTEXT", "your-test-context")
NS = "dra-adv-lab"
NODE = os.environ.get("LAB_NODE", "worker-a")
IMAGE = "redis:7-alpine"
OUT_DIR = Path("./lab-output")
OUT_DIR.mkdir(parents=True, exist_ok=True)


def k(*args, stdin=None, check=True):
    cmd = ["kubectl", "--context", CTX, *args]
    res = subprocess.run(cmd, input=stdin, text=True, capture_output=True)
    if check and res.returncode != 0:
        raise RuntimeError(f"kubectl {' '.join(args)} failed:\nSTDOUT:{res.stdout}\nSTDERR:{res.stderr}")
    return res.stdout


def kjson(*args):
    return json.loads(k(*args, "-o", "json"))


def apply(objs):
    if not isinstance(objs, list):
        objs = [objs]
    payload = "\n---\n".join(json.dumps(x) for x in objs)
    return k("apply", "-f", "-", stdin=payload)


def now_ts():
    return time.time()


def iso_utc(ts=None):
    return datetime.fromtimestamp(ts or time.time(), tz=timezone.utc).isoformat(timespec="milliseconds")


def clean_lab_workloads():
    k("delete", "devicetaintrule", "-l", "lab=dra-adv", "--ignore-not-found=true", check=False)
    for kind in ["deployment", "pod", "resourceclaim", "resourceclaimtemplate", "podgroup.scheduling.volcano.sh"]:
        k("-n", NS, "delete", kind, "-l", "lab=dra-adv", "--ignore-not-found=true", "--wait=false", check=False)
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        pods = kjson("-n", NS, "get", "pods", "-l", "lab=dra-adv")["items"]
        claims = kjson("-n", NS, "get", "resourceclaims")["items"]
        if not pods and not claims:
            break
        time.sleep(1.0)
    # Remove any leftover auto-created podgroups in NS
    for pg in kjson("-n", NS, "get", "podgroups.scheduling.volcano.sh")["items"]:
        k("-n", NS, "delete", "podgroup.scheduling.volcano.sh", pg["metadata"]["name"], "--ignore-not-found=true", check=False)
    time.sleep(1.5)


def get_device_pcie_map():
    slices = kjson("get", "resourceslices")["items"]
    mp = {}
    for sl in slices:
        drv = sl["spec"]["driver"]
        for dev in sl["spec"].get("devices", []):
            root = dev.get("attributes", {}).get("resource.kubernetes.io/pcieRoot", {}).get("string")
            mp[(drv, dev["name"])] = root
    return mp


def wait_pod_phase(name, want="Running", timeout=60):
    t0 = now_ts()
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        p = kjson("-n", NS, "get", "pod", name)
        if p["status"].get("phase") == want:
            return round(now_ts() - t0, 2), p
        time.sleep(0.5)
    return None, kjson("-n", NS, "get", "pod", name)


def claim_allocation_info(claim_name):
    c = kjson("-n", NS, "get", "resourceclaim", claim_name)
    alloc = c.get("status", {}).get("allocation", {}).get("devices", {}).get("results", [])
    devs = c.get("status", {}).get("devices", [])
    return {"claim": claim_name, "results": alloc, "deviceStatuses": devs}


# ==============================================================================
# SUITE 1: Cross-Driver PCIe Root Topology Alignment (GPU + NIC)
# ==============================================================================
def run_suite1():
    print("\n================ SUITE 1: CROSS-DRIVER PCIe ROOT ALIGNMENT (GPU + NIC) ================", flush=True)
    clean_lab_workloads()
    pcie_map = get_device_pcie_map()
    print("[S1] Device PCIe map:", pcie_map, flush=True)

    # 1A: Control WITHOUT matchAttribute: pin gpu-1 (pci0000:80) + nic-0 (pci0000:00)
    rc_1a = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaim",
        "metadata": {"name": "s1a-unaligned-claim", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "devices": {
                "requests": [
                    {"name": "gpu", "exactly": {"deviceClassName": "gpu.example.com", "selectors": [{"cel": {"expression": "device.attributes['gpu.example.com'].index == 1"}}]}},
                    {"name": "nic", "exactly": {"deviceClassName": "net.example.com", "selectors": [{"cel": {"expression": "device.attributes['net.example.com'].index == 0"}}], "capacity": {"requests": {"ingressBandwidth": "25G", "egressBandwidth": "25G"}}}},
                ]
            }
        },
    }
    pod_1a = {
        "apiVersion": "v1", "kind": "Pod",
        "metadata": {"name": "s1a-unaligned", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "restartPolicy": "Never", "terminationGracePeriodSeconds": 2,
            "containers": [{
                "name": "w", "image": IMAGE, "imagePullPolicy": "IfNotPresent",
                "command": ["sh", "-c", "env | grep -E 'GPU_DEVICE|NET_DEVICE' | sort; trap 'exit 0' TERM; sleep 600"],
                "resources": {"requests": {"cpu": "20m", "memory": "32Mi"}, "claims": [{"name": "hw"}]},
            }],
            "resourceClaims": [{"name": "hw", "resourceClaimName": "s1a-unaligned-claim"}],
        },
    }
    apply([rc_1a, pod_1a])
    t_1a, _ = wait_pod_phase("s1a-unaligned", "Running")
    alloc_1a = claim_allocation_info("s1a-unaligned-claim")
    env_1a = k("-n", NS, "logs", "s1a-unaligned", check=False).strip().splitlines()
    pairs_1a = {r["request"]: {"driver": r["driver"], "device": r["device"], "pcieRoot": pcie_map[(r["driver"], r["device"])]} for r in alloc_1a["results"]}
    print(f"[1A-Control Unaligned] Running in {t_1a}s -> {pairs_1a}", flush=True)

    # 1B: 4 Pods WITH matchAttribute: resource.kubernetes.io/pcieRoot on default kube-scheduler
    clean_lab_workloads()
    rct_1b = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaimTemplate",
        "metadata": {"name": "s1b-aligned-tmpl", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "spec": {
                "devices": {
                    "requests": [
                        {"name": "gpu", "exactly": {"deviceClassName": "gpu.example.com", "capacity": {"requests": {"memory": "80Gi", "compute": "100"}}}},
                        {"name": "nic", "exactly": {"deviceClassName": "net.example.com", "capacity": {"requests": {"ingressBandwidth": "25G", "egressBandwidth": "25G"}}}},
                    ],
                    "constraints": [
                        {"requests": ["gpu", "nic"], "matchAttribute": "resource.kubernetes.io/pcieRoot"}
                    ],
                }
            }
        },
    }
    pods_1b = [
        {
            "apiVersion": "v1", "kind": "Pod",
            "metadata": {"name": f"s1b-aligned-{i}", "namespace": NS, "labels": {"lab": "dra-adv"}},
            "spec": {
                "restartPolicy": "Never", "terminationGracePeriodSeconds": 2,
                "containers": [{
                    "name": "w", "image": IMAGE, "imagePullPolicy": "IfNotPresent",
                    "command": ["sh", "-c", "env | grep -E 'GPU_DEVICE|NET_DEVICE' | sort; trap 'exit 0' TERM; sleep 600"],
                    "resources": {"requests": {"cpu": "20m", "memory": "32Mi"}, "claims": [{"name": "hw"}]},
                }],
                "resourceClaims": [{"name": "hw", "resourceClaimTemplateName": "s1b-aligned-tmpl"}],
            },
        }
        for i in range(4)
    ]
    apply([rct_1b, *pods_1b])
    res_1b = []
    for i in range(4):
        dt, pod_obj = wait_pod_phase(f"s1b-aligned-{i}", "Running")
        cname = pod_obj["status"]["resourceClaimStatuses"][0]["resourceClaimName"]
        info = claim_allocation_info(cname)
        pairs = {r["request"]: {"driver": r["driver"], "device": r["device"], "pcieRoot": pcie_map[(r["driver"], r["device"])]} for r in info["results"]}
        matched = pairs["gpu"]["pcieRoot"] == pairs["nic"]["pcieRoot"]
        logs = k("-n", NS, "logs", f"s1b-aligned-{i}", check=False).strip().splitlines()
        res_1b.append({"pod": f"s1b-aligned-{i}", "running_s": dt, "pairs": pairs, "pcie_matched": matched, "cdi_env_sample": logs[:8]})
    print(f"[1B-Aligned 4/4] all_matched={all(x['pcie_matched'] for x in res_1b)}", flush=True)
    for x in res_1b:
        print(f"  {x['pod']}: gpu={x['pairs']['gpu']['device']}({x['pairs']['gpu']['pcieRoot']}) + nic={x['pairs']['nic']['device']}({x['pairs']['nic']['pcieRoot']}) matched={x['pcie_matched']}", flush=True)

    # 1C: Hard-constraint protection when matching PCIe NIC (nic-1 on pci0000:80) is tainted NoSchedule
    clean_lab_workloads()
    dtr_nic1 = {
        "apiVersion": "resource.k8s.io/v1", "kind": "DeviceTaintRule",
        "metadata": {"name": "s1c-taint-nic1", "labels": {"lab": "dra-adv"}},
        "spec": {
            "deviceSelector": {"driver": "net.example.com", "pool": NODE, "device": "nic-1"},
            "taint": {"key": "maintenance.aik8s.io/nic", "value": "down", "effect": "NoSchedule"},
        },
    }
    rc_1c = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaim",
        "metadata": {"name": "s1c-strict-claim", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "devices": {
                "requests": [
                    {"name": "gpu", "exactly": {"deviceClassName": "gpu.example.com", "selectors": [{"cel": {"expression": "device.attributes['gpu.example.com'].index == 1"}}]}},
                    {"name": "nic", "exactly": {"deviceClassName": "net.example.com", "capacity": {"requests": {"ingressBandwidth": "25G", "egressBandwidth": "25G"}}}},
                ],
                "constraints": [{"requests": ["gpu", "nic"], "matchAttribute": "resource.kubernetes.io/pcieRoot"}],
            }
        },
    }
    pod_1c = {
        "apiVersion": "v1", "kind": "Pod",
        "metadata": {"name": "s1c-strict", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "restartPolicy": "Never", "terminationGracePeriodSeconds": 2,
            "containers": [{"name": "w", "image": IMAGE, "imagePullPolicy": "IfNotPresent", "command": ["sh", "-c", "sleep 600"], "resources": {"requests": {"cpu": "20m", "memory": "32Mi"}, "claims": [{"name": "hw"}]}}],
            "resourceClaims": [{"name": "hw", "resourceClaimName": "s1c-strict-claim"}],
        },
    }
    apply([dtr_nic1, rc_1c, pod_1c])
    time.sleep(8)
    p1c_before = kjson("-n", NS, "get", "pod", "s1c-strict")
    p1c_phase_blocked = p1c_before["status"].get("phase")
    p1c_msg_blocked = next((c.get("message") for c in p1c_before["status"].get("conditions", []) if c.get("type") == "PodScheduled"), "")
    print(f"[1C-Strict] While nic-1 tainted: phase={p1c_phase_blocked}, msg={p1c_msg_blocked}", flush=True)
    # Remove taint -> should schedule immediately onto gpu-1 + nic-1 (both pci0000:80)!
    t_untaint = now_ts()
    k("delete", "devicetaintrule", "s1c-taint-nic1")
    t_1c_heal, _ = wait_pod_phase("s1c-strict", "Running", timeout=45)
    alloc_1c = claim_allocation_info("s1c-strict-claim")
    pairs_1c = {r["request"]: {"driver": r["driver"], "device": r["device"], "pcieRoot": pcie_map[(r["driver"], r["device"])]} for r in alloc_1c["results"]}
    print(f"[1C-Strict] After untaint: Running in {t_1c_heal}s -> {pairs_1c}", flush=True)

    # 1D: Volcano v1.16.0 cross-driver matchAttribute test!
    clean_lab_workloads()
    rc_1d = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaim",
        "metadata": {"name": "s1d-volcano-claim", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "devices": {
                "requests": [
                    {"name": "gpu", "exactly": {"deviceClassName": "gpu.example.com", "selectors": [{"cel": {"expression": "device.attributes['gpu.example.com'].index == 1"}}], "capacity": {"requests": {"memory": "24Gi", "compute": "30"}}}},
                    {"name": "nic", "exactly": {"deviceClassName": "net.example.com", "capacity": {"requests": {"ingressBandwidth": "25G", "egressBandwidth": "25G"}}}},
                ],
                "constraints": [{"requests": ["gpu", "nic"], "matchAttribute": "resource.kubernetes.io/pcieRoot"}],
            }
        },
    }
    pod_1d = {
        "apiVersion": "v1", "kind": "Pod",
        "metadata": {"name": "s1d-volcano-aligned", "namespace": NS, "labels": {"lab": "dra-adv"}, "annotations": {"scheduling.volcano.sh/queue-name": "default"}},
        "spec": {
            "schedulerName": "dra-volcano", "restartPolicy": "Never", "terminationGracePeriodSeconds": 2,
            "containers": [{"name": "w", "image": IMAGE, "imagePullPolicy": "IfNotPresent", "command": ["sh", "-c", "sleep 600"], "resources": {"requests": {"cpu": "20m", "memory": "32Mi"}, "claims": [{"name": "hw"}]}}],
            "resourceClaims": [{"name": "hw", "resourceClaimName": "s1d-volcano-claim"}],
        },
    }
    apply([rc_1d, pod_1d])
    t_1d, _ = wait_pod_phase("s1d-volcano-aligned", "Running", timeout=45)
    alloc_1d = claim_allocation_info("s1d-volcano-claim")
    pairs_1d = {r["request"]: {"driver": r["driver"], "device": r["device"], "pcieRoot": pcie_map[(r["driver"], r["device"])]} for r in alloc_1d["results"]}
    print(f"[1D-Volcano v1.16.0] Running in {t_1d}s -> {pairs_1d} matched={pairs_1d['gpu']['pcieRoot']==pairs_1d['nic']['pcieRoot']}", flush=True)

    out = {
        "suite": "1_cross_driver_pcie_alignment",
        "device_pcie_map": {f"{k[0]}/{k[1]}": v for k, v in pcie_map.items()},
        "exp1a_control_unaligned": {"running_s": t_1a, "pairs": pairs_1a, "pcie_matched": pairs_1a["gpu"]["pcieRoot"] == pairs_1a["nic"]["pcieRoot"], "cdi_env": env_1a[:8]},
        "exp1b_aligned_4pods": res_1b,
        "exp1c_strict_rejection": {"blocked_phase": p1c_phase_blocked, "blocked_message": p1c_msg_blocked, "healed_running_s": t_1c_heal, "healed_pairs": pairs_1c},
        "exp1d_volcano_v116": {"running_s": t_1d, "pairs": pairs_1d, "pcie_matched": pairs_1d["gpu"]["pcieRoot"] == pairs_1d["nic"]["pcieRoot"]},
    }
    (OUT_DIR / "suite1_pcie.json").write_text(json.dumps(out, indent=2))
    return out


# ==============================================================================
# SUITE 2: Consumable Capacity (AllowMultipleAllocations) + Volcano Queue Quota
# ==============================================================================
def run_suite2():
    print("\n================ SUITE 2: CONSUMABLE CAPACITY FRACTIONAL SHARING & VOLCANO QUEUE QUOTA ================", flush=True)
    clean_lab_workloads()

    # 2A: Pin 4 Pods to gpu-0 (80Gi VRAM, 100 compute), each requesting 24Gi VRAM + 30 compute
    rct_2a = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaimTemplate",
        "metadata": {"name": "s2a-gpu0-slice", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "spec": {
                "devices": {
                    "requests": [{
                        "name": "gpu",
                        "exactly": {
                            "deviceClassName": "gpu.example.com",
                            "selectors": [{"cel": {"expression": "device.attributes['gpu.example.com'].index == 0"}}],
                            "capacity": {"requests": {"memory": "24Gi", "compute": "30"}},
                        },
                    }]
                }
            }
        },
    }
    apply(rct_2a)
    # Create pods 0, 1, 2 first (72Gi / 80Gi, 90 / 100 compute)
    pods_012 = [
        {
            "apiVersion": "v1", "kind": "Pod",
            "metadata": {"name": f"s2a-slice-{i}", "namespace": NS, "labels": {"lab": "dra-adv"}},
            "spec": {
                "restartPolicy": "Never", "terminationGracePeriodSeconds": 2,
                "containers": [{
                    "name": "w", "image": IMAGE, "imagePullPolicy": "IfNotPresent",
                    "command": ["sh", "-c", "env | grep GPU_DEVICE | sort; trap 'exit 0' TERM; sleep 600"],
                    "resources": {"requests": {"cpu": "20m", "memory": "32Mi"}, "claims": [{"name": "gpu"}]},
                }],
                "resourceClaims": [{"name": "gpu", "resourceClaimTemplateName": "s2a-gpu0-slice"}],
            },
        }
        for i in range(3)
    ]
    apply(pods_012)
    slices_info = []
    for i in range(3):
        dt, pobj = wait_pod_phase(f"s2a-slice-{i}", "Running")
        cname = pobj["status"]["resourceClaimStatuses"][0]["resourceClaimName"]
        info = claim_allocation_info(cname)
        r0 = info["results"][0]
        logs = k("-n", NS, "logs", f"s2a-slice-{i}", check=False).strip().splitlines()
        slices_info.append({
            "pod": f"s2a-slice-{i}", "running_s": dt, "claim": cname,
            "device": r0["device"], "shareID": r0.get("shareID"),
            "consumedCapacity": r0.get("consumedCapacity"),
            "deviceStatusData": info["deviceStatuses"][0].get("data") if info["deviceStatuses"] else None,
            "cdi_env": logs,
        })
    distinct_shares = len({x["shareID"] for x in slices_info if x["shareID"]})
    print(f"[2A] 3 Pods packed onto gpu-0! distinct_shareIDs={distinct_shares}, deviceStatus_present={bool(slices_info[0]['deviceStatusData'])}", flush=True)

    # Now submit Pod 3 (would require 96Gi > 80Gi, 120 > 100 compute) -> MUST stay Pending!
    pod3 = json.loads(json.dumps(pods_012[0]))
    pod3["metadata"]["name"] = "s2a-slice-3"
    apply(pod3)
    time.sleep(8)
    p3_blocked = kjson("-n", NS, "get", "pod", "s2a-slice-3")
    p3_phase_blocked = p3_blocked["status"].get("phase")
    p3_msg_blocked = next((c.get("message") for c in p3_blocked["status"].get("conditions", []) if c.get("type") == "PodScheduled"), "")
    print(f"[2A] Pod 3 (96Gi > 80Gi) blocked: phase={p3_phase_blocked}, msg={p3_msg_blocked}", flush=True)

    # Also test RequestPolicy violation (requesting 90Gi > max 80Gi)
    rc_bad = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaim",
        "metadata": {"name": "s2a-overmax-claim", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {"devices": {"requests": [{"name": "gpu", "exactly": {"deviceClassName": "gpu.example.com", "capacity": {"requests": {"memory": "90Gi", "compute": "30"}}}}]}},
    }
    pod_bad = {
        "apiVersion": "v1", "kind": "Pod",
        "metadata": {"name": "s2a-overmax", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "restartPolicy": "Never", "terminationGracePeriodSeconds": 2,
            "containers": [{"name": "w", "image": IMAGE, "imagePullPolicy": "IfNotPresent", "command": ["sh", "-c", "sleep 60"], "resources": {"requests": {"cpu": "20m", "memory": "32Mi"}, "claims": [{"name": "gpu"}]}}],
            "resourceClaims": [{"name": "gpu", "resourceClaimName": "s2a-overmax-claim"}],
        },
    }
    apply([rc_bad, pod_bad])
    time.sleep(5)
    pbad = kjson("-n", NS, "get", "pod", "s2a-overmax")
    pbad_msg = next((c.get("message") for c in pbad["status"].get("conditions", []) if c.get("type") == "PodScheduled"), "")
    print(f"[2A] Over-max (90Gi > 80Gi validRange) status: phase={pbad['status'].get('phase')}, msg={pbad_msg}", flush=True)

    # Delete Pod 0 -> Pod 3 should immediately acquire freed 24Gi slice on gpu-0!
    k("-n", NS, "delete", "pod", "s2a-slice-0", "--wait=false")
    t_p3_heal, p3_run = wait_pod_phase("s2a-slice-3", "Running", timeout=45)
    p3_cname = p3_run["status"]["resourceClaimStatuses"][0]["resourceClaimName"]
    p3_alloc = claim_allocation_info(p3_cname)["results"][0]
    print(f"[2A] After deleting slice-0, slice-3 Running in {t_p3_heal}s on {p3_alloc['device']} shareID={p3_alloc.get('shareID')}", flush=True)

    # 2B: Volcano v1.16.0 Queue Consumable-Capacity Quota (dra-vgpu-q: memory.deviceclass/gpu.example.com = 48Gi, compute = 60)
    # Across 4 GPUs (320Gi total node capacity), submit 3 Pods each requesting 24Gi/30 compute -> 2 Run, 3rd blocked by Queue Quota!
    clean_lab_workloads()
    rct_2b = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaimTemplate",
        "metadata": {"name": "s2b-anygpu-24g", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "spec": {
                "devices": {
                    "requests": [{
                        "name": "gpu",
                        "exactly": {
                            "deviceClassName": "gpu.example.com",
                            "capacity": {"requests": {"memory": "24Gi", "compute": "30"}},
                        },
                    }]
                }
            }
        },
    }
    apply(rct_2b)
    qpods = [
        {
            "apiVersion": "v1", "kind": "Pod",
            "metadata": {"name": f"s2b-qpod-{i}", "namespace": NS, "labels": {"lab": "dra-adv"}, "annotations": {"scheduling.volcano.sh/queue-name": "dra-vgpu-q"}},
            "spec": {
                "schedulerName": "dra-volcano", "restartPolicy": "Never", "terminationGracePeriodSeconds": 2,
                "containers": [{"name": "w", "image": IMAGE, "imagePullPolicy": "IfNotPresent", "command": ["sh", "-c", "trap 'exit 0' TERM; sleep 600"], "resources": {"requests": {"cpu": "20m", "memory": "32Mi"}, "claims": [{"name": "gpu"}]}}],
                "resourceClaims": [{"name": "gpu", "resourceClaimTemplateName": "s2b-anygpu-24g"}],
            },
        }
        for i in range(3)
    ]
    apply(qpods[:2])
    t_q0, _ = wait_pod_phase("s2b-qpod-0", "Running", timeout=45)
    t_q1, _ = wait_pod_phase("s2b-qpod-1", "Running", timeout=45)
    apply(qpods[2])
    time.sleep(10)
    q2_blocked = kjson("-n", NS, "get", "pod", "s2b-qpod-2")
    q2_phase_blocked = q2_blocked["status"].get("phase")
    vlogs = k("-n", "volcano-system", "logs", "deploy/dra-volcano", "--since=30s", check=False)
    quota_logs = [l for l in vlogs.splitlines() if any(tok in l for tok in ["dra-vgpu-q", "checkDRA", "memory", "s2b-qpod-2", "capability"])][-15:]
    print(f"[2B-Volcano DRA Queue Quota 48Gi] qpod-0({t_q0}s) & qpod-1({t_q1}s) Running; qpod-2 (72Gi > 48Gi cap, 272Gi free on node) phase={q2_phase_blocked}", flush=True)

    # Delete qpod-0 -> qpod-2 should immediately schedule as queue quota drops 48Gi -> 24Gi -> 48Gi!
    k("-n", NS, "delete", "pod", "s2b-qpod-0", "--wait=false")
    t_q2_heal, _ = wait_pod_phase("s2b-qpod-2", "Running", timeout=45)
    print(f"[2B-Volcano DRA Queue Quota] After deleting qpod-0, qpod-2 Running in {t_q2_heal}s!", flush=True)

    out = {
        "suite": "2_consumable_capacity_and_volcano_quota",
        "exp2a_fractional_gpu0": {
            "gpu0_total_memory": "80Gi", "gpu0_total_compute": "100",
            "packed_3_pods": slices_info,
            "distinct_share_ids": distinct_shares,
            "pod3_oversub_phase": p3_phase_blocked,
            "pod3_oversub_message": p3_msg_blocked,
            "overmax_90gi_phase": pbad["status"].get("phase"),
            "overmax_90gi_message": pbad_msg,
            "pod3_after_pod0_delete_running_s": t_p3_heal,
            "pod3_allocated": {"device": p3_alloc["device"], "shareID": p3_alloc.get("shareID"), "consumedCapacity": p3_alloc.get("consumedCapacity")},
        },
        "exp2b_volcano_dra_queue_quota": {
            "queue": "dra-vgpu-q",
            "queue_capability_memory": "48Gi",
            "queue_capability_compute": "60",
            "node_total_memory": "320Gi",
            "qpod0_running_s": t_q0, "qpod1_running_s": t_q1,
            "qpod2_blocked_phase": q2_phase_blocked,
            "qpod2_after_qpod0_delete_running_s": t_q2_heal,
            "scheduler_log_excerpt": quota_logs,
        },
    }
    (OUT_DIR / "suite2_consumable.json").write_text(json.dumps(out, indent=2))
    return out


# ==============================================================================
# SUITE 3: KEP-4680 Device Health Reporting + Single-GPU Quarantine (DeviceTaintRule)
# ==============================================================================
def run_suite3():
    print("\n================ SUITE 3: KEP-4680 DEVICE HEALTH & SINGLE-GPU QUARANTINE ================", flush=True)
    clean_lab_workloads()

    # Find dra-adv-gpu kubeletplugin pod name on NODE
    drv_pods = kjson("-n", NS, "get", "pods", "-l", "app.kubernetes.io/instance=dra-adv-gpu")["items"]
    drv_pod = next(p["metadata"]["name"] for p in drv_pods if p["spec"].get("nodeName") == NODE)
    print(f"[S3] GPU DRA driver pod on {NODE}: {drv_pod}", flush=True)

    # Clear any old health override annotations
    for idx in range(4):
        k("-n", NS, "annotate", "pod", drv_pod, f"health.example.com/gpu-{idx}-", check=False)

    # Deploy a 2-replica serving Deployment (each Pod claims 1 full 80Gi GPU; 2 spare healthy GPUs remain!)
    rct_3 = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaimTemplate",
        "metadata": {"name": "s3-full-gpu", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "spec": {
                "devices": {
                    "requests": [{
                        "name": "gpu",
                        "exactly": {
                            "deviceClassName": "gpu.example.com",
                            "capacity": {"requests": {"memory": "80Gi", "compute": "100"}},
                        },
                    }]
                }
            }
        },
    }
    dep_3 = {
        "apiVersion": "apps/v1", "kind": "Deployment",
        "metadata": {"name": "dra-serving", "namespace": NS, "labels": {"lab": "dra-adv"}},
        "spec": {
            "replicas": 2,
            "selector": {"matchLabels": {"app": "dra-serving", "lab": "dra-adv"}},
            "template": {
                "metadata": {"labels": {"app": "dra-serving", "lab": "dra-adv"}},
                "spec": {
                    "terminationGracePeriodSeconds": 3,
                    "containers": [{
                        "name": "serve", "image": IMAGE, "imagePullPolicy": "IfNotPresent",
                        "command": ["sh", "-c", "trap 'exit 0' TERM; while :; do sleep 1; done"],
                        "resources": {"requests": {"cpu": "20m", "memory": "32Mi"}, "claims": [{"name": "gpu"}]},
                    }],
                    "resourceClaims": [{"name": "gpu", "resourceClaimTemplateName": "s3-full-gpu"}],
                },
            },
        },
    }
    apply([rct_3, dep_3])
    k("-n", NS, "rollout", "status", "deploy/dra-serving", "--timeout=60s")
    time.sleep(3)

    pods = sorted(kjson("-n", NS, "get", "pods", "-l", "app=dra-serving")["items"], key=lambda p: p["metadata"]["name"])
    assert len(pods) == 2

    def pod_health_snapshot(pod_name):
        p = kjson("-n", NS, "get", "pod", pod_name)
        cname = p["status"]["resourceClaimStatuses"][0]["resourceClaimName"]
        dev = claim_allocation_info(cname)["results"][0]["device"]
        cs = p["status"].get("containerStatuses", [{}])[0]
        ars = cs.get("allocatedResourcesStatus", [])
        return {
            "pod": pod_name, "uid": p["metadata"]["uid"], "phase": p["status"].get("phase"),
            "restarts": cs.get("restartCount", 0), "device": dev, "claim": cname,
            "allocatedResourcesStatus": ars,
        }

    # Wait until both report Healthy in allocatedResourcesStatus
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        snaps = [pod_health_snapshot(p["metadata"]["name"]) for p in pods]
        if all(
            s["allocatedResourcesStatus"]
            and s["allocatedResourcesStatus"][0]["resources"][0].get("health") == "Healthy"
            for s in snaps
        ):
            break
        time.sleep(1.0)
    healthy_before = [pod_health_snapshot(p["metadata"]["name"]) for p in pods]
    victim = healthy_before[0]
    sibling = healthy_before[1]
    bad_gpu = victim["device"]
    good_gpu = sibling["device"]
    print(f"[3A] Baseline Healthy: victim={victim['pod']}({bad_gpu}), sibling={sibling['pod']}({good_gpu})", flush=True)
    print(f"  victim allocatedResourcesStatus={victim['allocatedResourcesStatus']}", flush=True)

    # Step 1: Inject hardware fault (unhealthy) on bad_gpu and measure propagation latency!
    t_inject = now_ts()
    k("-n", NS, "annotate", "pod", drv_pod, f"health.example.com/{bad_gpu}=unhealthy", "--overwrite")
    t_unhealthy = None
    unhealthy_status = None
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        s = pod_health_snapshot(victim["pod"])
        ars = s["allocatedResourcesStatus"]
        if ars and ars[0]["resources"][0].get("health") == "Unhealthy":
            t_unhealthy = round(now_ts() - t_inject, 2)
            unhealthy_status = ars
            break
        time.sleep(0.3)
    print(f"[3A] Fault detected in Pod status at t+{t_unhealthy}s! status={unhealthy_status}", flush=True)

    # Observe for 10s WITHOUT remediation -> verify kubelet does NOT auto-evict!
    time.sleep(10)
    after_10s = pod_health_snapshot(victim["pod"])
    kubelet_auto_evicted = (after_10s["phase"] != "Running")
    print(f"[3A] After 10s with Unhealthy GPU (no watchdog): phase={after_10s['phase']}, kubelet_auto_evicted={kubelet_auto_evicted}", flush=True)

    # Quick check of Unknown state as well (third KEP-4680 state)
    t_unk_start = now_ts()
    k("-n", NS, "annotate", "pod", drv_pod, f"health.example.com/{bad_gpu}=unknown", "--overwrite")
    t_unknown = None
    unknown_status = None
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        s = pod_health_snapshot(victim["pod"])
        ars = s["allocatedResourcesStatus"]
        if ars and ars[0]["resources"][0].get("health") == "Unknown":
            t_unknown = round(now_ts() - t_unk_start, 2)
            unknown_status = ars
            break
        time.sleep(0.3)
    print(f"[3A] Unknown state observed at t+{t_unknown}s: {unknown_status}", flush=True)

    # Switch back to unhealthy and trigger 3B closed-loop single-GPU quarantine via DeviceTaintRule!
    k("-n", NS, "annotate", "pod", drv_pod, f"health.example.com/{bad_gpu}=unhealthy", "--overwrite")
    time.sleep(1.5)

    t_taint = now_ts()
    dtr_bad = {
        "apiVersion": "resource.k8s.io/v1", "kind": "DeviceTaintRule",
        "metadata": {"name": f"quarantine-{bad_gpu}", "labels": {"lab": "dra-adv"}},
        "spec": {
            "deviceSelector": {"driver": "gpu.example.com", "pool": NODE, "device": bad_gpu},
            "taint": {"key": "health.aik8s.io/unhealthy", "value": "true", "effect": "NoExecute"},
        },
    }
    apply(dtr_bad)

    t_evicted = None
    t_replaced_running = None
    replacement_snap = None
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        dt = round(now_ts() - t_taint, 2)
        cur_pods = kjson("-n", NS, "get", "pods", "-l", "app=dra-serving")["items"]
        victim_cur = next((p for p in cur_pods if p["metadata"]["uid"] == victim["uid"]), None)
        if (victim_cur is None or victim_cur["metadata"].get("deletionTimestamp")) and t_evicted is None:
            t_evicted = dt
        new_pods = [p for p in cur_pods if p["metadata"]["uid"] not in (victim["uid"], sibling["uid"]) and p["status"].get("phase") == "Running"]
        if new_pods:
            np_snap = pod_health_snapshot(new_pods[0]["metadata"]["name"])
            if np_snap["allocatedResourcesStatus"] and np_snap["allocatedResourcesStatus"][0]["resources"][0].get("health") == "Healthy":
                t_replaced_running = dt
                replacement_snap = np_snap
                break
        time.sleep(0.5)

    sibling_after = pod_health_snapshot(sibling["pod"])
    sibling_untouched = (
        sibling_after["uid"] == sibling["uid"]
        and sibling_after["device"] == good_gpu
        and sibling_after["restarts"] == 0
        and sibling_after["phase"] == "Running"
    )
    print(f"[3B] Quarantine & Self-Heal: evicted at t+{t_evicted}s, replacement {replacement_snap['pod']} Healthy on {replacement_snap['device']} at t+{t_replaced_running}s!", flush=True)
    print(f"[3B] Sibling Pod {sibling['pod']} ({good_gpu}) on SAME node untouched={sibling_untouched} (restarts={sibling_after['restarts']})", flush=True)

    # Clear health override
    k("-n", NS, "annotate", "pod", drv_pod, f"health.example.com/{bad_gpu}-", check=False)

    out = {
        "suite": "3_device_health_and_single_gpu_quarantine",
        "baseline": {"victim": victim, "sibling": sibling},
        "exp3a_kep4680_health": {
            "fault_device": bad_gpu,
            "unhealthy_propagation_s": t_unhealthy,
            "unhealthy_status": unhealthy_status,
            "kubelet_auto_evicted_after_10s": kubelet_auto_evicted,
            "unknown_propagation_s": t_unknown,
            "unknown_status": unknown_status,
        },
        "exp3b_single_gpu_quarantine": {
            "quarantined_device": bad_gpu,
            "eviction_triggered_s": t_evicted,
            "replacement_healthy_running_s": t_replaced_running,
            "replacement": replacement_snap,
            "avoided_bad_gpu": replacement_snap["device"] != bad_gpu,
            "sibling_same_node_untouched": sibling_untouched,
            "sibling_after": sibling_after,
        },
    }
    (OUT_DIR / "suite3_health.json").write_text(json.dumps(out, indent=2))
    return out


if __name__ == "__main__":
    run_suite1()
    run_suite2()
    run_suite3()
    print("\nALL 3 DRA ADVANCED SUITES COMPLETED!", flush=True)
