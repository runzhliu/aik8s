import os
#!/usr/bin/env python3
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

CTX = os.environ.get("LAB_CONTEXT", "your-test-context")
NS = "keda-tide-lab"
SCHED = "tide-volcano"
REDIS_IMAGE = "redis:7-alpine"
OUT_DIR = Path("./lab-output")
OUT_DIR.mkdir(parents=True, exist_ok=True)


def k(*args, stdin=None, check=True):
    cmd = ["kubectl", "--context", CTX, *args]
    res = subprocess.run(cmd, input=stdin, text=True, capture_output=True)
    if check and res.returncode != 0:
        raise RuntimeError(f"kubectl {' '.join(args)} failed ({res.returncode}):\nSTDOUT:{res.stdout}\nSTDERR:{res.stderr}")
    return res.stdout


def kjson(*args):
    return json.loads(k(*args, "-o", "json"))


def apply(obj):
    if isinstance(obj, list):
        payload = "\n---\n".join(json.dumps(x) for x in obj)
    else:
        payload = json.dumps(obj)
    return k("apply", "-f", "-", stdin=payload)


def redis_cmd(*args):
    out = k("-n", NS, "exec", "deploy/tide-redis", "--", "redis-cli", "--raw", *map(str, args))
    return out.strip()


def redis_flush():
    redis_cmd("FLUSHALL")


def now_ts():
    return time.time()


def iso_utc(ts=None):
    return datetime.fromtimestamp(ts or time.time(), tz=timezone.utc).isoformat(timespec="milliseconds")


def clean_workloads():
    for kind in ["scaledobject.keda.sh", "vcjob.batch.volcano.sh", "deployment", "job", "pod", "podgroup.scheduling.volcano.sh", "resourceclaim.resource.k8s.io", "resourceclaimtemplate.resource.k8s.io", "devicetaintrule.resource.k8s.io"]:
        if kind == "devicetaintrule.resource.k8s.io":
            k("delete", kind, "-l", "lab=tide-v2", "--ignore-not-found=true", check=False)
        else:
            k("-n", NS, "delete", kind, "-l", "lab=tide-v2", "--ignore-not-found=true", "--wait=false", check=False)
    # Wait until no lab=tide-v2 pods remain
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
        claims = kjson("-n", NS, "get", "resourceclaims", "-l", "lab=tide-v2")["items"]
        if not pods and not claims:
            break
        time.sleep(1.5)
    # Also clean auto-created podgroups left over in NS
    pgs = kjson("-n", NS, "get", "podgroups.scheduling.volcano.sh")["items"]
    for pg in pgs:
        name = pg["metadata"]["name"]
        k("-n", NS, "delete", "podgroup.scheduling.volcano.sh", name, "--ignore-not-found=true", check=False)
    time.sleep(2)


def get_scheduler_logs(since="120s"):
    return k("-n", "volcano-system", "logs", "deploy/tide-volcano", f"--since={since}", check=False)


def get_ns_events():
    return kjson("-n", NS, "get", "events")["items"]


def make_podgroup(name, queue="tide-online", priority="tide-online-high", min_member=1):
    return {
        "apiVersion": "scheduling.volcano.sh/v1beta1",
        "kind": "PodGroup",
        "metadata": {"name": name, "namespace": NS, "labels": {"lab": "tide-v2"}},
        "spec": {
            "minMember": min_member,
            "queue": queue,
            "priorityClassName": priority,
        },
    }

