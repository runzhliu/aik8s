# 16-GPU Tidal Reclaim & DRA DeviceTaintRule Lab Kit

Reproduces the five hands-on trials tested on Kubernetes v1.37.2, Volcano v1.16.0, KEDA v2.21.1,
fake-gpu-operator v0.2.1 (2x8 simulated B300 GPUs), and dra-example-driver v0.5.0 (4 DRA devices).

## Included Files
- `volcano-scheduler-cm.yaml` — `tide-volcano` scheduler config (`capacity` + `reclaim` + `binpack` + DRA, with `overcommit` disabled and `gang.enableReclaimable: false`)
- `queues-and-priorities.yaml` — `tide-online` (`reclaimable: false`, `guarantee: 4`, `deserved: 8`) & `tide-offline` (`reclaimable: true`, `deserved: 8`) queues and PriorityClasses
- `device-taint-rule.yaml` — Kubernetes v1.37 `DeviceTaintRule` (`NoExecute`) for DRA device recall
- `lab_common.py`, `exp1_multiqueue_reclaim.py`, `exp2_gang_and_fragmentation.py`, `exp3_chaos_drills.py` — sanitized experiment runners
- `grafana-dashboard-16gpu.json` — light-theme Grafana 12.x dashboard definition

## Quick Start
1. Set `export LAB_CONTEXT=<your-test-context>` and edit `CTX` / `REDIS_IMAGE` / worker hostnames in `lab_common.py` (default image `redis:7-alpine`).
2. Install Volcano v1.16.0, KEDA v2.21.1 (watching `keda-tide-lab`), `dra-example-driver` v0.5.0 (set custom kubelet paths if your cluster uses a nonstandard kubelet root), and a 2x8 GPU pool (or `fake-gpu-operator`).
3. Apply `volcano-scheduler-cm.yaml`, `queues-and-priorities.yaml`, and deploy isolated `tide-volcano` + `tide-pg-controller` (`--controllers=pg-controller --scheduler-name=tide-volcano`).
4. Run:
```sh
python3 exp1_multiqueue_reclaim.py
python3 exp2_gang_and_fragmentation.py
python3 exp3_chaos_drills.py
```
