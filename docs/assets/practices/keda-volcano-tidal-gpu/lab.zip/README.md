# Whole-device lending lab

Use a disposable Kubernetes cluster. The tested combination is Kubernetes 1.37.2, Volcano 1.16.0, KEDA 2.21.1 and kubernetes-sigs/dra-example-driver v0.5.0. Work happens in keda-tide-lab. A second scheduler named tide-volcano uses the existing volcano-scheduler service account in volcano-system. Start with no objects bearing these names, no other GPU example driver and an empty dedicated Redis. If your cluster already runs KEDA, reuse it after confirming it watches the lab namespace. Only one adapter can own the external.metrics.k8s.io APIService.

Install Kubernetes, Volcano and Helm first. The scheduler setup expects the upstream Volcano release names, a config line "  - name: predicates", and two example devices on one worker. Select an idle worker. For a nonstandard kubelet directory set both driver Helm paths to plugins_registry and plugins under the correct kubelet root. Inspect the generated scheduler options if the source scheduler uses leader election, host ports or a custom scheduler name. This kit was tested with leader election disabled and without host ports.

```sh
export LAB_CONTEXT=your-test-context
export LAB_NODE=your-worker-hostname
kubectl --context "$LAB_CONTEXT" create namespace keda-tide-lab
git clone --depth=1 --branch v0.5.0 https://github.com/kubernetes-sigs/dra-example-driver.git
helm --kube-context "$LAB_CONTEXT" install tide-dra dra-example-driver/deployments/helm/dra-example-driver -n keda-tide-lab --set kubeletPlugin.numDevices=2 --set-string "kubeletPlugin.nodeSelector.kubernetes\.io/hostname=$LAB_NODE" --set webhook.enabled=false
helm repo add kedacore https://kedacore.github.io/charts
helm --kube-context "$LAB_CONTEXT" install tide-keda kedacore/keda --version 2.21.1 -n tide-keda-system --create-namespace --set watchNamespace=keda-tide-lab --set image.pullPolicy=IfNotPresent
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python tidalinfra.py
python workloads.py
kubectl --context "$LAB_CONTEXT" -n keda-tide-lab rollout status deploy/base
kubectl --context "$LAB_CONTEXT" wait apiservice/v1beta1.external.metrics.k8s.io --for=condition=Available --timeout=180s
```

Open two terminals with the same LAB_CONTEXT. Leave these commands running throughout the experiment. Redis and the API must belong to the same cluster as the workload. Do not expose these forwards externally.

```sh
kubectl --context "$LAB_CONTEXT" -n keda-tide-lab port-forward --address 127.0.0.1 svc/tide-redis 18386:6379
kubectl --context "$LAB_CONTEXT" proxy --address 127.0.0.1 --port 18387
```

Run once against the empty lab. The controller derives a UTC cron window from the current minute. Wait for the printout VERIFIED and inspect verified.json, events.jsonl and the scheduler events. The observer is optional and can run in a separate shell.

```sh
.venv/bin/python observe.py
# in a separate terminal
.venv/bin/python run.py
touch sample.stop
```

All traffic, checkpoints and pauses are synthetic CPU work. All scale, scheduling and claim transitions are real cluster actions. A failure ends the experiment rather than continuing an unverified handoff. Redis has no persistence across Pod loss. This runner is for a single trial. Use a fresh isolated namespace and Redis before another run.

Clean up owned test resources. Omit release removal if reusing existing operators. Shut down both port forwards and the observer. Remove the created KEDA namespace only after the release is gone and the namespace has no unrelated workloads. Check KEDA CRDs for existing resources and ownership before considering their removal.

```sh
kubectl --context "$LAB_CONTEXT" -n keda-tide-lab delete scaledobject tide --ignore-not-found
helm --kube-context "$LAB_CONTEXT" uninstall tide-dra -n keda-tide-lab
kubectl --context "$LAB_CONTEXT" delete ns keda-tide-lab
kubectl --context "$LAB_CONTEXT" -n volcano-system delete deploy/tide-volcano cm/tide-volcano
helm --kube-context "$LAB_CONTEXT" uninstall tide-keda -n tide-keda-system
```
