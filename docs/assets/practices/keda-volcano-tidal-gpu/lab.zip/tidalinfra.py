import json, subprocess, os
from pathlib import Path
ns="keda-tide-lab"
def k(*args,stdin=None):
    return subprocess.check_output(["kubectl","--context",os.environ["LAB_CONTEXT"],*args],input=stdin,text=True).strip()
def get(*args):return json.loads(k(*args,"-o","json"))
def apply(o):return k("apply","-f","-",stdin=json.dumps(o))
sched="tide-volcano"
def obj(kind,name,spec,api="v1",namespace=ns):
    return {"apiVersion":api,"kind":kind,"metadata":{"name":name,"namespace":namespace},"spec":spec}
if __name__=="__main__":
    vns="volcano-system"
    config=get("-n",vns,"get","cm","volcano-scheduler-configmap")["data"]["volcano-scheduler.conf"]
    assert config.count("  - name: predicates\n")==1
    apply({"apiVersion":"v1","kind":"ConfigMap","metadata":{"namespace":vns,"name":sched},"data":{"volcano-scheduler.conf":config.replace("  - name: predicates\n","  - name: predicates\n    arguments:\n      predicate.DynamicResourceAllocationEnable: true\n")}})
    old=get("-n",vns,"get","deploy","volcano-scheduler")["spec"]["template"]["spec"]
    c=old["containers"][0]
    c["args"]=[s for s in c["args"] if s!="2>&1"]+["--scheduler-name="+sched]
    for v in old["volumes"]:
        if v["name"]=="scheduler-config":v["configMap"]["name"]=sched
    labels={"app":sched}
    apply(obj("Deployment",sched,{"replicas":1,"selector":{"matchLabels":labels},"template":{"metadata":{"labels":labels},"spec":old}},"apps/v1",vns))
    redis=os.environ.get("REDIS_IMAGE","redis:7-alpine")
    labels={"app":"tide-redis"}
    apply(obj("Deployment","tide-redis",{"replicas":1,"selector":{"matchLabels":labels},"template":{"metadata":{"labels":labels},"spec":{"containers":[{"name":"redis","image":redis,"command":["redis-server","--save","","--appendonly","no"],"readinessProbe":{"exec":{"command":["redis-cli","ping"]}}}]}}},"apps/v1"))
    apply(obj("Service","tide-redis",{"selector":labels,"ports":[{"port":6379}]}))
    Path("redis-image.txt").write_text(redis)
