from workloads import *
from observe import snapshot,redis,endpoint
import time,json
from pathlib import Path
def record(label,s=None):
    s=s or snapshot()
    with open("events.jsonl","a") as f:f.write(json.dumps({"event":label,**s})+"\n")
    print(label, {r:(p["phase"],p["device"]) for r,p in s["roles"].items()},s["queue"],s["committed"],flush=True)
    return s
def wait(label,predicate,limit=100):
    end=time.monotonic()+limit
    while time.monotonic()<end:
        s=snapshot()
        if predicate(s):return record(label,s)
        time.sleep(.7)
    raise RuntimeError(label+": deadline "+str(s))
def role(s,r,phase,device=None):
    p=s["roles"].get(r,{})
    return p.get("phase")==phase and p.get("device")==device
def job(name):
    apply(group(name));apply(workload(name))
def remove(name):
    k("-n",ns,"delete","job",name,"--cascade=foreground","--timeout=50s")
def run():
    assert redis.dbsize()==0, "use an empty isolated Redis"
    api=get("get","apiservice","v1beta1.external.metrics.k8s.io")
    assert any(c["type"]=="Available" and c["status"]=="True" for c in api["status"]["conditions"])
    sc,end=scaled()
    Path("scaled-tested.json").write_text(json.dumps(sc,indent=2))
    print("cron ends",end,flush=True);apply(sc)
    a=wait("day_ready",lambda s:role(s,"base","Running","gpu-0") and role(s,"elastic","Running","gpu-1"))
    redis.set("pause:elastic",1)
    deadline=time.monotonic()+12
    while redis.get("paused:elastic")!="1" and time.monotonic()<deadline:time.sleep(.15)
    assert redis.get("paused:elastic")=="1"
    job("probe")
    s=wait("paused_probe_pending",lambda s:role(s,"probe","Pending") and bool(s["roles"]["probe"]["claim"]) and role(s,"elastic","Running","gpu-1"))
    time.sleep(8)
    s=record("paused_probe_still_pending")
    assert role(s,"probe","Pending") and a["roles"]["elastic"]["claim"]==s["roles"]["elastic"]["claim"]
    remove("probe")
    redis.delete("pause:elastic")
    wait("night_released",lambda s:s["elasticDesired"]==0 and "elastic" not in s["roles"],240)
    redis.set("lend",1);job("batch")
    b=wait("batch_owns_slot",lambda s:role(s,"batch","Running","gpu-1") and s["committed"]>=2)
    before=record("burst_before_enqueue")
    with redis.pipeline() as tx:
        tx.rpush("online",*[str(i) for i in range(1,97)]).execute()
    record("burst_enqueued")
    p=wait("recall_waiting",lambda s:s["elasticDesired"]==1 and role(s,"elastic","Pending") and s["roles"]["elastic"]["claim"] and role(s,"batch","Running","gpu-1"),45)
    redis.set("lend",0); record("admission_closed")
    wait("batch_checkpointed",lambda s:redis.get("exit:batch") is not None)
    wait("batch_terminal",lambda s:s["roles"].get("batch",{}).get("phase")=="Succeeded",50)
    remove("batch")
    w=wait("online_reallocated",lambda s:role(s,"elastic","Running","gpu-1"))
    assert w["roles"]["elastic"]["pod"]==p["roles"]["elastic"]["pod"] and w["roles"]["elastic"]["claim"]!=b["roles"]["batch"]["claim"]
    wait("first_elastic_reply",lambda s:s["elasticServed"]>0)
    wait("online_complete",lambda s:s["baseServed"]+s["elasticServed"]==96)
    assert set(redis.hkeys("served"))=={str(n) for n in range(1,97)}
    wait("second_release",lambda s:s["elasticDesired"]==0 and "elastic" not in s["roles"])
    redis.set("lend",1);job("resume")
    wait("resumed",lambda s:role(s,"resume","Running","gpu-1") and s["committed"]>int(redis.get("exit:batch")))
    final=wait("offline_complete",lambda s:s["committed"]==80 and redis.get("exit:resume"),130)
    assert set(redis.hkeys("committed"))=={str(n) for n in range(1,81)}
    assert list(set(redis.hvals("executions")))==["1"]
    assert a["roles"]["base"]["pod"]==final["roles"]["base"]["pod"]
    counts={r:list(redis.hvals("committed")).count(r) for r in ["batch","resume"]}
    ev=endpoint("/api/v1/namespaces/"+ns+"/events")["items"]
    scheds=sorted({e.get("reportingComponent") or e.get("source",{}).get("component","") for e in ev if e.get("reason")=="Scheduled" and e["involvedObject"]["name"].startswith(("base-","elastic-","batch-","resume-"))})
    Path("verified.json").write_text(json.dumps({"passed":True,"batch":counts,"executionsPerItem":1,"served":{"base":final["baseServed"],"elastic":final["elasticServed"]},"schedulers":scheds,"basePodUnchanged":True,"waitingPodUnchanged":True,"claimChanged":True},indent=2))
    print("VERIFIED",counts,scheds,flush=True)
if __name__=="__main__":run()
