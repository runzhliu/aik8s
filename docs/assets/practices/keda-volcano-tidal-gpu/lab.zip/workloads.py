from tidalinfra import *
from datetime import datetime,timedelta,timezone
image=Path("redis-image.txt").read_text()
online_script="""set -eu
r() { redis-cli -h tide-redis --raw "$@"; }
while :; do
  if [ "$(r GET pause:$ROLE)" = 1 ]; then
    r SET paused:$ROLE 1 >/dev/null
    sleep 0.2
    continue
  fi
  item=$(r LPOP online)
  if [ -n "$item" ]; then
    sleep 0.6
    r HSETNX served "$item" "$ROLE" >/dev/null
  else
    sleep 0.2
  fi
done"""
offline_script="""set -eu
r() { redis-cli -h tide-redis --raw "$@"; }
for n in $(seq 1 80); do
  [ "$(r GET lend)" = 1 ] || break
  [ "$(r HEXISTS committed "$n")" = 0 ] || continue
  sleep 0.65
  r EVAL "redis.call('HINCRBY','executions',ARGV[1],1); return redis.call('HSETNX','committed',ARGV[1],ARGV[2])" 0 "$n" "$ROLE" >/dev/null
done
r SET "exit:$ROLE" "$(r HLEN committed)"
"""
def tmpl(which,idx):
    req={"name":"accel","exactly":{"deviceClassName":"gpu.example.com","selectors":[{"cel":{"expression":f"device.attributes['gpu.example.com'].index == {idx}"}}]}}
    return obj("ResourceClaimTemplate",which,{"spec":{"devices":{"requests":[req]}}},"resource.k8s.io/v1")
def group(role):return obj("PodGroup",role,{"minMember":1,"queue":"default"},"scheduling.volcano.sh/v1beta1")
def workload(role,deploy=False,replicas=1):
    claim="base-slot" if role=="base" else "loan-slot"
    labels={"app":role}
    c={"name":"worker","image":image,"env":[{"name":"ROLE","value":role}],"command":["sh","-c",online_script if deploy else offline_script],"resources":{"requests":{"cpu":"20m","memory":"24Mi"},"claims":[{"name":"slot"}]}}
    spec={"schedulerName":sched,"restartPolicy":"Always" if deploy else "Never","terminationGracePeriodSeconds":3,"containers":[c],"resourceClaims":[{"name":"slot","resourceClaimTemplateName":claim}]}
    template={"metadata":{"labels":labels,"annotations":{"scheduling.k8s.io/group-name":role}},"spec":spec}
    if deploy:return obj("Deployment",role,{"replicas":replicas,"strategy":{"type":"Recreate"},"selector":{"matchLabels":labels},"template":template},"apps/v1")
    return obj("Job",role,{"backoffLimit":0,"activeDeadlineSeconds":420,"template":template},"batch/v1")
def scaled():
    now=datetime.now(timezone.utc)
    def cron(t):return f"{t.minute} {t.hour} * * *"
    end=(now+timedelta(minutes=3)).replace(second=0,microsecond=0)
    spec={"scaleTargetRef":{"name":"elastic"},"minReplicaCount":0,"maxReplicaCount":1,"pollingInterval":3,"cooldownPeriod":8,"advanced":{"horizontalPodAutoscalerConfig":{"behavior":{"scaleDown":{"stabilizationWindowSeconds":0}}}},"triggers":[{"type":"cron","metadata":{"timezone":"Etc/UTC","start":cron(now-timedelta(minutes=3)),"end":cron(end),"desiredReplicas":"1"}},{"type":"redis","metadata":{"address":"tide-redis."+ns+".svc.cluster.local:6379","listName":"online","listLength":"2","activationListLength":"0"}}]}
    return obj("ScaledObject","tide",spec,"keda.sh/v1alpha1"),end
if __name__=="__main__":
    for o in [tmpl("base-slot",0),tmpl("loan-slot",1),group("base"),group("elastic"),workload("base",True),workload("elastic",True,0)]:
        print(apply(o),flush=True)
