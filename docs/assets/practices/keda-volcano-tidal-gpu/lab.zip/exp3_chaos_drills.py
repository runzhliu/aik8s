#!/usr/bin/env python3
"""Experiment 3 (Module 4): Production Chaos Drills.
4A: Rogue / Stuck Offline Worker ignoring SIGTERM -> Compare graceful SIGTERM exit (~2s) vs
    SIGTERM-ignoring worker bounded by terminationGracePeriodSeconds=15s (kubelet SIGKILL).
4B: KEDA Scaler / Redis Outage -> Compare ScaledObject WITHOUT fallback vs WITH fallback
    (failureThreshold=2, replicas=2) when tide-redis scales to 0 during nighttime.
4C: Kubernetes v1.37 DRA DeviceTaintRule (NoExecute) Emergency Device Recall ->
    Offline Pod holds DRA device gpu-1 (with optional tolerationSeconds=0);
    Online Pod waits for gpu-1 with toleration for tide.aik8s.io/reclaim=online-only:NoExecute;
    Applying DeviceTaintRule evicts offline Pod, deallocates its claim, blocks offline re-entry,
    and hands gpu-1 cleanly to the online Pod!
"""
import json
import time
from datetime import datetime, timedelta, timezone
from lab_common import (
    NS, OUT_DIR, REDIS_IMAGE, SCHED, apply, clean_workloads,
    get_ns_events, get_scheduler_logs, iso_utc, k, kjson,
    make_podgroup, now_ts, redis_cmd, redis_flush
)


def run_exp4a_rogue_offline():
    print("\n================ EXP 4A: GRACEFUL VS ROGUE (SIGTERM-IGNORING) OFFLINE WORKER ================", flush=True)
    results = {}
    for mode, script, grace in [
        ("graceful_sigterm", "trap 'echo got-term; sleep 1; exit 0' TERM INT; while :; do sleep 0.5; done", 15),
        ("rogue_ignore_sigterm", "trap '' TERM INT; while :; do sleep 1; done", 15),
    ]:
        print(f"\n--- Running 4A mode: {mode} (terminationGracePeriodSeconds={grace}s) ---", flush=True)
        clean_workloads()
        # Online base=4, elastic=0; Offline=12 (so 16/16 full, offline 12 > deserved 8)
        base = {
            "apiVersion": "apps/v1", "kind": "Deployment",
            "metadata": {"name": "base", "namespace": NS, "labels": {"lab": "tide-v2", "role": "base"}},
            "spec": {
                "replicas": 4,
                "selector": {"matchLabels": {"app": "base", "lab": "tide-v2"}},
                "template": {
                    "metadata": {"labels": {"app": "base", "lab": "tide-v2", "role": "base"},
                                 "annotations": {"scheduling.volcano.sh/queue-name": "tide-online", "volcano.sh/preemptable": "false"}},
                    "spec": {
                        "schedulerName": SCHED, "priorityClassName": "tide-online-high", "terminationGracePeriodSeconds": 3,
                        "containers": [{"name": "w", "image": REDIS_IMAGE, "imagePullPolicy": "IfNotPresent",
                                        "command": ["sh", "-c", "trap 'exit 0' TERM; while :; do sleep 1; done"],
                                        "resources": {"requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                                      "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"}}}],
                    },
                },
            },
        }
        elastic = json.loads(json.dumps(base))
        elastic["metadata"]["name"] = "elastic"
        elastic["metadata"]["labels"]["role"] = "elastic"
        elastic["metadata"]["annotations"] = {"scheduling.volcano.sh/group-min-member": "2"}
        elastic["spec"]["replicas"] = 0
        elastic["spec"]["selector"]["matchLabels"]["app"] = "elastic"
        elastic["spec"]["template"]["metadata"]["labels"]["app"] = "elastic"
        elastic["spec"]["template"]["metadata"]["labels"]["role"] = "elastic"

        off_vcjob = {
            "apiVersion": "batch.volcano.sh/v1alpha1", "kind": "Job",
            "metadata": {"name": f"off-{mode.split('_')[0]}", "namespace": NS, "labels": {"lab": "tide-v2", "role": "offline"}},
            "spec": {
                "minAvailable": 1, "schedulerName": SCHED, "queue": "tide-offline", "priorityClassName": "tide-offline-low", "maxRetry": 50,
                "policies": [{"event": "PodEvicted", "action": "RestartPod"}],
                "tasks": [{
                    "replicas": 12, "name": "worker",
                    "policies": [{"event": "PodEvicted", "action": "RestartPod"}],
                    "template": {
                        "metadata": {"labels": {"app": f"off-{mode.split('_')[0]}", "lab": "tide-v2", "role": "offline"},
                                     "annotations": {"volcano.sh/preemptable": "true"}},
                        "spec": {
                            "restartPolicy": "OnFailure", "priorityClassName": "tide-offline-low",
                            "terminationGracePeriodSeconds": grace,
                            "containers": [{"name": "w", "image": REDIS_IMAGE, "imagePullPolicy": "IfNotPresent",
                                            "command": ["sh", "-c", script],
                                            "resources": {"requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                                          "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"}}}],
                        },
                    },
                }],
            },
        }
        apply([base, elastic, off_vcjob])

        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
            b = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "base" and p["status"].get("phase") == "Running")
            o = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "offline" and p["status"].get("phase") == "Running")
            if b == 4 and o == 12:
                break
            time.sleep(1.5)

        t0 = now_ts()
        k("-n", NS, "scale", "deploy/elastic", "--replicas=2")
        t_evict_seen = None
        t_el_sched = None
        t_el_ready = None
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
            term = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "offline" and p["metadata"].get("deletionTimestamp"))
            el_pods = [p for p in pods if p["metadata"]["labels"]["role"] == "elastic"]
            if term > 0 and t_evict_seen is None:
                t_evict_seen = round(now_ts() - t0, 2)
            if len(el_pods) == 2 and all(p["spec"].get("nodeName") for p in el_pods) and t_el_sched is None:
                t_el_sched = round(now_ts() - t0, 2)
            if len(el_pods) == 2 and all(p["status"].get("phase") == "Running" for p in el_pods):
                t_el_ready = round(now_ts() - t0, 2)
                break
            time.sleep(0.5)

        results[mode] = {
            "termination_grace_period_s": grace,
            "eviction_seen_s": t_evict_seen,
            "elastic_2_scheduled_s": t_el_sched,
            "elastic_2_running_s": t_el_ready,
        }
        print(f"[4A-{mode}] {results[mode]}", flush=True)

    (OUT_DIR / "exp4a_rogue_offline.json").write_text(json.dumps(results, indent=2))
    return results


def run_exp4b_keda_fallback():
    print("\n================ EXP 4B: KEDA METRIC SOURCE OUTAGE & FALLBACK PROTECTION ================", flush=True)
    results = {}

    for mode, fallback_cfg in [
        ("without_fallback", None),
        ("with_fallback_2", {"failureThreshold": 2, "replicas": 2}),
    ]:
        print(f"\n--- Running 4B mode: {mode} ---", flush=True)
        clean_workloads()
        # Ensure tide-redis is running and empty before starting
        k("-n", NS, "scale", "deploy/tide-redis", "--replicas=1")
        k("-n", NS, "rollout", "status", "deploy/tide-redis", "--timeout=60s")
        redis_flush()

        # Deploy base=4, elastic=0, offline=12 (16/16 GPUs full at night!)
        base = {
            "apiVersion": "apps/v1", "kind": "Deployment",
            "metadata": {"name": "base", "namespace": NS, "labels": {"lab": "tide-v2", "role": "base"}},
            "spec": {
                "replicas": 4,
                "selector": {"matchLabels": {"app": "base", "lab": "tide-v2"}},
                "template": {
                    "metadata": {"labels": {"app": "base", "lab": "tide-v2", "role": "base"},
                                 "annotations": {"scheduling.volcano.sh/queue-name": "tide-online", "volcano.sh/preemptable": "false"}},
                    "spec": {
                        "schedulerName": SCHED, "priorityClassName": "tide-online-high", "terminationGracePeriodSeconds": 3,
                        "containers": [{"name": "w", "image": REDIS_IMAGE, "imagePullPolicy": "IfNotPresent",
                                        "command": ["sh", "-c", "trap 'exit 0' TERM; while :; do sleep 1; done"],
                                        "resources": {"requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                                      "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"}}}],
                    },
                },
            },
        }
        elastic = json.loads(json.dumps(base))
        elastic["metadata"]["name"] = "elastic"
        elastic["metadata"]["labels"]["role"] = "elastic"
        elastic["metadata"]["annotations"] = {"scheduling.volcano.sh/group-min-member": "2"}
        elastic["spec"]["replicas"] = 0
        elastic["spec"]["selector"]["matchLabels"]["app"] = "elastic"
        elastic["spec"]["template"]["metadata"]["labels"]["app"] = "elastic"
        elastic["spec"]["template"]["metadata"]["labels"]["role"] = "elastic"

        off_vcjob = {
            "apiVersion": "batch.volcano.sh/v1alpha1", "kind": "Job",
            "metadata": {"name": "off-fallback", "namespace": NS, "labels": {"lab": "tide-v2", "role": "offline"}},
            "spec": {
                "minAvailable": 1, "schedulerName": SCHED, "queue": "tide-offline", "priorityClassName": "tide-offline-low", "maxRetry": 50,
                "policies": [{"event": "PodEvicted", "action": "RestartPod"}],
                "tasks": [{
                    "replicas": 12, "name": "worker",
                    "policies": [{"event": "PodEvicted", "action": "RestartPod"}],
                    "template": {
                        "metadata": {"labels": {"app": "off-fallback", "lab": "tide-v2", "role": "offline"},
                                     "annotations": {"volcano.sh/preemptable": "true"}},
                        "spec": {
                            "restartPolicy": "OnFailure", "priorityClassName": "tide-offline-low",
                            "terminationGracePeriodSeconds": 5,
                            "containers": [{"name": "w", "image": REDIS_IMAGE, "imagePullPolicy": "IfNotPresent",
                                            "command": ["sh", "-c", "trap 'exit 0' TERM; while :; do sleep 1; done"],
                                            "resources": {"requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                                          "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"}}}],
                        },
                    },
                }],
            },
        }

        so_spec = {
            "scaleTargetRef": {"name": "elastic"},
            "minReplicaCount": 0,
            "maxReplicaCount": 4,
            "pollingInterval": 3,
            "cooldownPeriod": 8,
            "triggers": [
                {
                    "type": "redis",
                    "metadata": {
                        "address": f"tide-redis.{NS}.svc.cluster.local:6379",
                        "listName": "online:todo",
                        "listLength": "5",
                        "activationListLength": "0",
                    },
                }
            ],
        }
        if fallback_cfg:
            so_spec["fallback"] = fallback_cfg

        so = {
            "apiVersion": "keda.sh/v1alpha1", "kind": "ScaledObject",
            "metadata": {"name": "tide-fallback-test", "namespace": NS, "labels": {"lab": "tide-v2"}},
            "spec": so_spec,
        }
        apply([base, elastic, off_vcjob, so])

        # Wait for base=4, offline=12, ScaledObject Ready=True
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
            b = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "base" and p["status"].get("phase") == "Running")
            o = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "offline" and p["status"].get("phase") == "Running")
            so_obj = kjson("-n", NS, "get", "scaledobject", "tide-fallback-test")
            conds = {c["type"]: c["status"] for c in so_obj.get("status", {}).get("conditions", [])}
            if b == 4 and o == 12 and conds.get("Ready") == "True":
                break
            time.sleep(1.5)
        print(f"[4B-{mode}] Pre-outage steady state ready (base=4, elastic=0, offline=12).", flush=True)

        # Inject fault: scale tide-redis to 0!
        t_fault = now_ts()
        k("-n", NS, "scale", "deploy/tide-redis", "--replicas=0")
        timeline = []
        t_fb_active = None
        t_el2_running = None
        for _ in range(18):
            time.sleep(2.0)
            so_obj = kjson("-n", NS, "get", "scaledobject", "tide-fallback-test")
            conds = {c["type"]: c["status"] for c in so_obj.get("status", {}).get("conditions", [])}
            dep = kjson("-n", NS, "get", "deploy", "elastic")
            pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
            el_run = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "elastic" and p["status"].get("phase") == "Running")
            off_run = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "offline" and p["status"].get("phase") == "Running")
            dt = round(now_ts() - t_fault, 2)
            rec = {"t_plus": dt, "desired": dep["spec"]["replicas"], "elastic_running": el_run, "offline_running": off_run, "conditions": conds}
            timeline.append(rec)
            if conds.get("Fallback") == "True" and t_fb_active is None:
                t_fb_active = dt
            if el_run == 2 and t_el2_running is None:
                t_el2_running = dt
                break

        # Restore tide-redis and verify automatic recovery back to 0!
        t_restore = now_ts()
        k("-n", NS, "scale", "deploy/tide-redis", "--replicas=1")
        k("-n", NS, "rollout", "status", "deploy/tide-redis", "--timeout=60s")
        t_recovered_zero = None
        if fallback_cfg:
            deadline = time.monotonic() + 60
            while time.monotonic() < deadline:
                so_obj = kjson("-n", NS, "get", "scaledobject", "tide-fallback-test")
                conds = {c["type"]: c["status"] for c in so_obj.get("status", {}).get("conditions", [])}
                dep = kjson("-n", NS, "get", "deploy", "elastic")
                if conds.get("Fallback") == "False" and dep["spec"]["replicas"] == 0:
                    t_recovered_zero = round(now_ts() - t_restore, 2)
                    break
                time.sleep(1.5)

        results[mode] = {
            "fallback_config": fallback_cfg,
            "fallback_activated_s": t_fb_active,
            "elastic_2_running_s": t_el2_running,
            "final_during_outage": timeline[-1],
            "recovered_to_zero_after_restore_s": t_recovered_zero,
        }
        print(f"[4B-{mode}] RESULT: {results[mode]}", flush=True)

    (OUT_DIR / "exp4b_keda_fallback.json").write_text(json.dumps(results, indent=2))
    return results


def run_exp4c_dra_device_taint_rule():
    print("\n================ EXP 4C: K8S v1.37 DRA DEVICETAINTRULE (NoExecute) EMERGENCY RECALL ================", flush=True)
    clean_workloads()

    # Create two ResourceClaimTemplates targeting specific DRA device gpu-1 on worker-a:
    # 1. offline-slot-gpu1: NO toleration (or tolerationSeconds=2 for graceful window)
    # 2. online-slot-gpu1: tolerates tide.aik8s.io/reclaim=online-only (both NoSchedule and NoExecute!)
    off_rct = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaimTemplate",
        "metadata": {"name": "offline-gpu1-slot", "namespace": NS, "labels": {"lab": "tide-v2"}},
        "spec": {
            "spec": {
                "devices": {
                    "requests": [{
                        "name": "gpu",
                        "exactly": {
                            "deviceClassName": "gpu.example.com",
                            "selectors": [{"cel": {"expression": "device.attributes['gpu.example.com'].index == 1"}}],
                            "tolerations": [
                                {"key": "tide.aik8s.io/reclaim", "operator": "Equal", "value": "online-only", "effect": "NoExecute", "tolerationSeconds": 2}
                            ],
                        },
                    }]
                }
            }
        },
    }
    on_rct = {
        "apiVersion": "resource.k8s.io/v1", "kind": "ResourceClaimTemplate",
        "metadata": {"name": "online-gpu1-slot", "namespace": NS, "labels": {"lab": "tide-v2"}},
        "spec": {
            "spec": {
                "devices": {
                    "requests": [{
                        "name": "gpu",
                        "exactly": {
                            "deviceClassName": "gpu.example.com",
                            "selectors": [{"cel": {"expression": "device.attributes['gpu.example.com'].index == 1"}}],
                            "tolerations": [
                                {"key": "tide.aik8s.io/reclaim", "operator": "Equal", "value": "online-only", "effect": "NoExecute"},
                                {"key": "tide.aik8s.io/reclaim", "operator": "Equal", "value": "online-only", "effect": "NoSchedule"},
                            ],
                        },
                    }]
                }
            }
        },
    }
    apply([off_rct, on_rct])

    # Offline Pod claims gpu-1 and runs
    off_pod = {
        "apiVersion": "v1", "kind": "Pod",
        "metadata": {"name": "dra-offline-holder", "namespace": NS, "labels": {"lab": "tide-v2", "role": "offline"},
                     "annotations": {"scheduling.k8s.io/group-name": "dra-offline-holder", "scheduling.volcano.sh/queue-name": "tide-offline"}},
        "spec": {
            "schedulerName": SCHED, "restartPolicy": "Never", "terminationGracePeriodSeconds": 5,
            "containers": [{"name": "w", "image": REDIS_IMAGE, "imagePullPolicy": "IfNotPresent",
                            "command": ["sh", "-c", "trap 'echo offline-checkpoint-done; sleep 1; exit 0' TERM; while :; do sleep 1; done"],
                            "resources": {"requests": {"cpu": "50m", "memory": "48Mi"}, "claims": [{"name": "gpu"}]}}],
            "resourceClaims": [{"name": "gpu", "resourceClaimTemplateName": "offline-gpu1-slot"}],
        },
    }
    apply([make_podgroup("dra-offline-holder", "tide-offline", "tide-offline-low", 1), off_pod])
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        p = kjson("-n", NS, "get", "pod", "dra-offline-holder")
        if p["status"].get("phase") == "Running":
            break
        time.sleep(1.0)
    off_claim_before = kjson("-n", NS, "get", "pod", "dra-offline-holder")["status"].get("resourceClaimStatuses", [])
    print(f"[4C] Offline pod Running and holding gpu-1: {off_claim_before}", flush=True)

    # Online Pod requests gpu-1 (with toleration) -> starts Pending because offline holds gpu-1
    on_pod = {
        "apiVersion": "v1", "kind": "Pod",
        "metadata": {"name": "dra-online-waiter", "namespace": NS, "labels": {"lab": "tide-v2", "role": "online"},
                     "annotations": {"scheduling.k8s.io/group-name": "dra-online-waiter", "scheduling.volcano.sh/queue-name": "tide-online"}},
        "spec": {
            "schedulerName": SCHED, "restartPolicy": "Never", "terminationGracePeriodSeconds": 5,
            "containers": [{"name": "w", "image": REDIS_IMAGE, "imagePullPolicy": "IfNotPresent",
                            "command": ["sh", "-c", "trap 'exit 0' TERM; while :; do sleep 1; done"],
                            "resources": {"requests": {"cpu": "50m", "memory": "48Mi"}, "claims": [{"name": "gpu"}]}}],
            "resourceClaims": [{"name": "gpu", "resourceClaimTemplateName": "online-gpu1-slot"}],
        },
    }
    apply([make_podgroup("dra-online-waiter", "tide-online", "tide-online-high", 1), on_pod])
    time.sleep(6)
    on_before = kjson("-n", NS, "get", "pod", "dra-online-waiter")["status"].get("phase")
    print(f"[4C] Online pod before DeviceTaintRule: phase={on_before}", flush=True)

    # Now apply Kubernetes v1.37 DeviceTaintRule (NoExecute) targeting gpu-1!
    t_taint = now_ts()
    dtr = {
        "apiVersion": "resource.k8s.io/v1",
        "kind": "DeviceTaintRule",
        "metadata": {"name": "tide-reclaim-gpu1", "labels": {"lab": "tide-v2"}},
        "spec": {
            "deviceSelector": {
                "driver": "gpu.example.com",
                "pool": "worker-a",
                "device": "gpu-1",
            },
            "taint": {
                "key": "tide.aik8s.io/reclaim",
                "value": "online-only",
                "effect": "NoExecute",
            },
        },
    }
    apply(dtr)
    print(f"[4C] Applied DeviceTaintRule tide-reclaim-gpu1 at {iso_utc(t_taint)}", flush=True)

    t_off_evicted = None
    t_off_gone = None
    t_on_running = None
    dtr_status = None
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        dt = round(now_ts() - t_taint, 2)
        try:
            op = kjson("-n", NS, "get", "pod", "dra-offline-holder")
            if op["metadata"].get("deletionTimestamp") and t_off_evicted is None:
                t_off_evicted = dt
        except Exception:
            if t_off_evicted is None:
                t_off_evicted = dt
            if t_off_gone is None:
                t_off_gone = dt
        onp = kjson("-n", NS, "get", "pod", "dra-online-waiter")
        if onp["status"].get("phase") == "Running" and t_on_running is None:
            t_on_running = dt
            dtr_status = kjson("get", "devicetaintrule", "tide-reclaim-gpu1").get("status", {})
            break
        time.sleep(0.5)

    on_claims = kjson("-n", NS, "get", "pod", "dra-online-waiter")["status"].get("resourceClaimStatuses", [])
    evs = [
        {"obj": e["involvedObject"]["name"], "reason": e.get("reason"), "msg": e.get("message")}
        for e in get_ns_events()
        if e["involvedObject"]["name"] in ("dra-offline-holder", "dra-online-waiter")
    ]
    res4c = {
        "exp": "4C_dra_device_taint_rule",
        "toleration_seconds_offline": 2,
        "online_phase_before_taint": on_before,
        "offline_eviction_started_s": t_off_evicted,
        "offline_pod_deleted_s": t_off_gone,
        "online_running_with_gpu1_s": t_on_running,
        "online_claim_status": on_claims,
        "device_taint_rule_status": dtr_status,
        "events": evs,
    }
    (OUT_DIR / "exp4c_device_taint_rule.json").write_text(json.dumps(res4c, indent=2))
    print(f"[4C] RESULT: {json.dumps(res4c, indent=2)}", flush=True)
    return res4c


if __name__ == "__main__":
    run_exp4a_rogue_offline()
    run_exp4b_keda_fallback()
    run_exp4c_dra_device_taint_rule()
