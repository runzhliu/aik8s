import json
from pathlib import Path
panels=[]
def panel(title,series,unit,description,step=False):
    opts={"drawStyle":"line","lineInterpolation":"stepAfter" if step else "linear","lineWidth":2,"fillOpacity":6,"showPoints":"never","spanNulls":False}
    idx=len(panels)
    colors=["#227768","#ae7839","#536aa3"]
    fields={"defaults":{"unit":unit,"min":0,"custom":opts},"overrides":[{"matcher":{"id":"byName","options":label},"properties":[{"id":"color","value":{"mode":"fixed","fixedColor":colors[i]}}]} for i,(metric,label) in enumerate(series)]}
    panels.append({"id":idx+1,"type":"timeseries","title":title,"description":description,"datasource":{"type":"prometheus","uid":"tide-prom"},"gridPos":{"x":(idx%2)*12,"y":(idx//2)*8,"w":12,"h":8},"fieldConfig":fields,"targets":[{"expr":"tide_"+metric,"legendFormat":label,"refId":chr(65+i),"range":True,"interval":"2s"} for i,(metric,label) in enumerate(series)],"options":{"legend":{"displayMode":"list","placement":"bottom","showLegend":True},"tooltip":{"mode":"multi"}}})
panel("Who holds device 1?",[("online_owns_slot","Online replica"),("offline_owns_slot","Batch worker")],"short","1 = allocated claim for this role. The base replica holds a separate device.",True)
panel("Online queue",[("queue","Requests waiting")],"short","Redis list length, sampled from the lab.")
panel("Requests completed",[("base_served","Base replica"),("elastic_served","Elastic replica")],"short","Unique request IDs committed after processing by CPU workers.")
panel("Batch progress",[("committed","Items committed")],"short","A Redis hash keyed by item ID survives Job replacement.")
Path("labdash/tide.json").write_text(json.dumps({"uid":"tide-handoff","title":"GPU handoff lab","timezone":"utc","tags":["DRA","KEDA","Volcano"],"schemaVersion":39,"time":{"from":"now-8m","to":"now"},"refresh":"","panels":panels}))
