#!/usr/bin/env python3
"""Experiment 2 (Module 3): 16-GPU Multi-Node Fragmentation Governance & Gang vcjob Reclamation.
2A: Fragmentation Trap (Spread across 2x8 GPU nodes leaves 5+5 free -> 8-GPU single-node vcjob stuck Pending)
    vs Binpack + pod-deletion-cost (Online packs to Node 1 -> Node 2 has 8/8 contiguous -> 8-GPU vcjob runs immediately!).
2B: Multi-Node 8-GPU Gang vcjob (2 nodes x 4 pods x 1 GPU = 8 GPUs) Partial Reclaim:
    - Anti-pattern (PodEvicted -> RestartPod): when online needs 2 GPUs, 2 ranks evicted while 6 ranks stay alive (zombie Gang deadlock!).
    - Production pattern (PodEvicted -> RestartJob): Volcano evicts/restarts whole Gang cleanly, all 8 GPUs released,
      online gets 2 GPUs immediately, and after online scales back down, Gang vcjob resumes from last barrier epoch and finishes!
"""
import json
import time
from lab_common import (
    NS, OUT_DIR, REDIS_IMAGE, SCHED, apply, clean_workloads,
    get_ns_events, get_scheduler_logs, iso_utc, k, kjson,
    make_podgroup, now_ts, redis_cmd, redis_flush
)


def node_gpu_map():
    pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
    m = {"worker-a": {"online": 0, "offline": 0, "pods": []}, "worker-b": {"online": 0, "offline": 0, "pods": []}}
    for p in pods:
        if p["status"].get("phase") != "Running" or p["metadata"].get("deletionTimestamp"):
            continue
        node = p["spec"].get("nodeName")
        if node not in m:
            continue
        role = p["metadata"]["labels"].get("role", "other")
        gpus = sum(int(c.get("resources", {}).get("requests", {}).get("nvidia.com/gpu", 0)) for c in p["spec"].get("containers", []))
        if role in ("base", "elastic", "online"):
            m[node]["online"] += gpus
        else:
            m[node]["offline"] += gpus
        m[node]["pods"].append((p["metadata"]["name"], role, gpus))
    return m


def make_online_pod(name, node=None, deletion_cost=None, scheduler=SCHED):
    ann = {
        "scheduling.k8s.io/group-name": "online-spread",
        "scheduling.volcano.sh/queue-name": "tide-online",
        "volcano.sh/preemptable": "false",
    }
    if deletion_cost is not None:
        ann["controller.kubernetes.io/pod-deletion-cost"] = str(deletion_cost)
    spec = {
        "schedulerName": scheduler,
        "priorityClassName": "tide-online-high",
        "terminationGracePeriodSeconds": 3,
        "containers": [
            {
                "name": "worker",
                "image": REDIS_IMAGE,
                "imagePullPolicy": "IfNotPresent",
                "command": ["sh", "-c", "trap 'exit 0' TERM INT; while :; do sleep 1; done"],
                "resources": {
                    "requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                    "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"},
                },
            }
        ],
    }
    if node:
        spec["nodeSelector"] = {"kubernetes.io/hostname": node}
    return {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {"name": name, "namespace": NS, "labels": {"lab": "tide-v2", "role": "online"}, "annotations": ann},
        "spec": spec,
    }


def make_8gpu_single_node_vcjob(name="train-8gpu-nvlink"):
    return {
        "apiVersion": "batch.volcano.sh/v1alpha1",
        "kind": "Job",
        "metadata": {"name": name, "namespace": NS, "labels": {"lab": "tide-v2", "role": "offline"}},
        "spec": {
            "minAvailable": 1,
            "schedulerName": SCHED,
            "queue": "tide-offline",
            "priorityClassName": "tide-offline-low",
            "tasks": [
                {
                    "replicas": 1,
                    "name": "trainer",
                    "template": {
                        "metadata": {
                            "labels": {"app": name, "lab": "tide-v2", "role": "offline"},
                            "annotations": {"volcano.sh/preemptable": "true"},
                        },
                        "spec": {
                            "restartPolicy": "OnFailure",
                            "priorityClassName": "tide-offline-low",
                            "terminationGracePeriodSeconds": 5,
                            "containers": [
                                {
                                    "name": "trainer",
                                    "image": REDIS_IMAGE,
                                    "imagePullPolicy": "IfNotPresent",
                                    "command": ["sh", "-c", "trap 'exit 0' TERM INT; sleep 120"],
                                    "resources": {
                                        "requests": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "8"},
                                        "limits": {"cpu": "500m", "memory": "256Mi", "nvidia.com/gpu": "8"},
                                    },
                                }
                            ],
                        },
                    },
                }
            ],
        },
    }


def run_exp2a_fragmentation():
    print("\n================ EXP 2A: GPU FRAGMENTATION TRAP VS BINPACK + POD-DELETION-COST ================", flush=True)
    clean_workloads()

    # Scenario A (Unoptimized Spread):
    # Online holds 6 GPUs at night, spread 3 on node .111 and 3 on node .112 (10 GPUs free total: 5 + 5).
    # Submit an 8-GPU single-node NVLink training job -> STUCK PENDING despite 10 free GPUs!
    spread_pods = [
        make_online_pod(f"online-spread-a-{i}", node="worker-a") for i in range(3)
    ] + [
        make_online_pod(f"online-spread-b-{i}", node="worker-b") for i in range(3)
    ]
    apply([make_podgroup("online-spread", "tide-online", "tide-online-high", 1), *spread_pods])
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        m = node_gpu_map()
        if m["worker-a"]["online"] == 3 and m["worker-b"]["online"] == 3:
            break
        time.sleep(1.5)
    before_spread = node_gpu_map()
    print("[2A-Spread] Online placement:", {k: (v["online"], v["offline"]) for k, v in before_spread.items()}, flush=True)

    apply(make_8gpu_single_node_vcjob("train-8gpu-spread-test"))
    time.sleep(15)
    train_pod = kjson("-n", NS, "get", "pods", "-l", "app=train-8gpu-spread-test")["items"]
    spread_phase = train_pod[0]["status"].get("phase") if train_pod else "Missing"
    spread_conds = train_pod[0]["status"].get("conditions", []) if train_pod else []
    print(f"[2A-Spread] 8-GPU job status after 15s (with 10 free GPUs = 5+5): phase={spread_phase}", flush=True)

    # Scenario B (Optimized: Deployment with binpack + pod-deletion-cost):
    # Start with 10 daytime online replicas (packed: 8 on node A + 2 on node B via binpack!).
    # Annotate pods on the fuller node (node with 8 GPUs) with higher pod-deletion-cost=100 and pods on the sparse node with cost=0.
    # Scale Deployment 10 -> 6 -> K8s ReplicaSet deletes the 2 sparse-node pods FIRST + 2 on fuller node, OR start with 8+2=10 and scale to 6:
    # Let's make it even clearer: 8 daytime replicas (say 6 on Node1 + 2 on Node2, or 8+2=10 -> scale to 6 -> all 6 remain on Node1, 0 on Node2 -> 8 contiguous GPUs free on Node2!).
    clean_workloads()
    dep = {
        "apiVersion": "apps/v1",
        "kind": "Deployment",
        "metadata": {"name": "online-packed", "namespace": NS, "labels": {"lab": "tide-v2", "role": "online"}},
        "spec": {
            "replicas": 10,
            "selector": {"matchLabels": {"app": "online-packed", "lab": "tide-v2"}},
            "template": {
                "metadata": {
                    "labels": {"app": "online-packed", "lab": "tide-v2", "role": "online"},
                    "annotations": {
                        "scheduling.k8s.io/group-name": "online-packed",
                        "scheduling.volcano.sh/queue-name": "tide-online",
                        "volcano.sh/preemptable": "false",
                    },
                },
                "spec": {
                    "schedulerName": SCHED,
                    "priorityClassName": "tide-online-high",
                    "terminationGracePeriodSeconds": 3,
                    "containers": [
                        {
                            "name": "worker",
                            "image": REDIS_IMAGE,
                            "imagePullPolicy": "IfNotPresent",
                            "command": ["sh", "-c", "trap 'exit 0' TERM INT; while :; do sleep 1; done"],
                            "resources": {
                                "requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"},
                            },
                        }
                    ],
                },
            },
        },
    }
    apply([make_podgroup("online-packed", "tide-online", "tide-online-high", 1), dep])
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        m = node_gpu_map()
        if m["worker-a"]["online"] + m["worker-b"]["online"] == 10:
            break
        time.sleep(1.5)
    packed_day = node_gpu_map()
    print("[2A-Binpack] Daytime 10-GPU placement via Volcano binpack:", {k: v["online"] for k, v in packed_day.items()}, flush=True)

    # Identify fuller node (8 GPUs) vs sparse node (2 GPUs) and annotate pod-deletion-cost accordingly!
    fuller_node = max(packed_day, key=lambda n: packed_day[n]["online"])
    sparse_node = min(packed_day, key=lambda n: packed_day[n]["online"])
    pods = kjson("-n", NS, "get", "pods", "-l", "app=online-packed")["items"]
    for p in pods:
        cost = "100" if p["spec"].get("nodeName") == fuller_node else "-100"
        k("-n", NS, "annotate", "pod", p["metadata"]["name"], f"controller.kubernetes.io/pod-deletion-cost={cost}", "--overwrite")

    # Now scale down 10 -> 6 (nighttime)! ReplicaSet MUST evict the sparse_node pods first!
    k("-n", NS, "scale", "deploy/online-packed", "--replicas=6")
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        m = node_gpu_map()
        if m["worker-a"]["online"] + m["worker-b"]["online"] == 6:
            break
        time.sleep(1.5)
    packed_night = node_gpu_map()
    print("[2A-Binpack+DeletionCost] Nighttime 6-GPU placement:", {k: v["online"] for k, v in packed_night.items()}, flush=True)

    # Submit the exact same 8-GPU single-node NVLink training job -> should schedule IMMEDIATELY on sparse_node!
    t_sub = now_ts()
    apply(make_8gpu_single_node_vcjob("train-8gpu-binpack-test"))
    binpack_phase = "Pending"
    binpack_node = None
    t_run = None
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        tp = kjson("-n", NS, "get", "pods", "-l", "app=train-8gpu-binpack-test")["items"]
        if tp and tp[0]["status"].get("phase") == "Running":
            binpack_phase = "Running"
            binpack_node = tp[0]["spec"].get("nodeName")
            t_run = round(now_ts() - t_sub, 2)
            break
        time.sleep(1.0)
    print(f"[2A-Binpack] 8-GPU job result: phase={binpack_phase}, node={binpack_node}, schedule_to_running={t_run}s", flush=True)

    res2a = {
        "exp": "2A_gpu_fragmentation",
        "spread": {
            "online_per_node": {k: v["online"] for k, v in before_spread.items()},
            "free_gpus_total": 10,
            "train_8gpu_phase": spread_phase,
            "train_8gpu_conditions": spread_conds,
        },
        "binpack_deletion_cost": {
            "daytime_10gpu_per_node": {k: v["online"] for k, v in packed_day.items()},
            "fuller_node": fuller_node,
            "sparse_node": sparse_node,
            "nighttime_6gpu_per_node": {k: v["online"] for k, v in packed_night.items()},
            "free_gpus_total": 10,
            "train_8gpu_phase": binpack_phase,
            "train_8gpu_node": binpack_node,
            "schedule_to_running_s": t_run,
        },
    }
    (OUT_DIR / "exp2a_fragmentation.json").write_text(json.dumps(res2a, indent=2))
    return res2a


# Multi-node 8-GPU Gang training script with barrier synchronization & epoch checkpointing in Redis!
GANG_TRAIN_SCRIPT = r"""set -eu
r() { redis-cli -h tide-redis --raw "$@"; }
STOP=0
trap 'STOP=1; r RPUSH gang:sigterm "$JOB_NAME:$POD_NAME:$(date -u +%s)" >/dev/null || true' TERM INT
WORLD=8
TARGET_EPOCHS=10

while [ "$STOP" = 0 ]; do
  cur=$(r GET "gang:$JOB_NAME:epoch" || echo 0)
  [ -n "$cur" ] || cur=0
  if [ "$cur" -ge "$TARGET_EPOCHS" ]; then
    r RPUSH "gang:$JOB_NAME:completed" "$POD_NAME:$cur" >/dev/null || true
    exit 0
  fi
  next=$((cur + 1))
  # Register rank arrival at barrier for epoch $next
  r SADD "gang:$JOB_NAME:barrier:$next" "$POD_NAME" >/dev/null
  # Wait for all 8 ranks to arrive at barrier (simulating NCCL AllReduce sync!)
  while [ "$STOP" = 0 ]; do
    arrived=$(r SCARD "gang:$JOB_NAME:barrier:$next" || echo 0)
    if [ "$arrived" -ge "$WORLD" ]; then
      break
    fi
    sleep 0.3
  done
  if [ "$STOP" = 1 ]; then
    break
  fi
  # Simulate step compute (1.5s)
  sleep 1.5
  # Rank 0 commits checkpoint atomically after all 8 ranks finished the step
  if echo "$POD_NAME" | grep -q -- '-0$'; then
    r SET "gang:$JOB_NAME:epoch" "$next" >/dev/null
    r RPUSH "gang:$JOB_NAME:ckpt_log" "epoch=$next:ts=$(date -u +%s)" >/dev/null
  else
    # Wait for rank 0 to advance epoch
    while [ "$STOP" = 0 ]; do
      c2=$(r GET "gang:$JOB_NAME:epoch" || echo 0)
      [ "${c2:-0}" -ge "$next" ] && break
      sleep 0.2
    done
  fi
done
r RPUSH "gang:$JOB_NAME:exited" "$POD_NAME:epoch=$(r GET gang:$JOB_NAME:epoch || echo 0):ts=$(date -u +%s)" >/dev/null || true
"""


def make_gang_vcjob(name, pod_evicted_action, replicas=8, min_avail=8):
    return {
        "apiVersion": "batch.volcano.sh/v1alpha1",
        "kind": "Job",
        "metadata": {"name": name, "namespace": NS, "labels": {"lab": "tide-v2", "role": "offline"}},
        "spec": {
            "minAvailable": min_avail,
            "schedulerName": SCHED,
            "queue": "tide-offline",
            "priorityClassName": "tide-offline-low",
            "maxRetry": 50,
            "policies": [
                {"event": "PodEvicted", "action": pod_evicted_action},
                {"event": "PodFailed", "action": pod_evicted_action},
            ],
            "tasks": [
                {
                    "replicas": replicas,
                    "name": "rank",
                    "policies": [
                        {"event": "PodEvicted", "action": pod_evicted_action},
                        {"event": "PodFailed", "action": pod_evicted_action},
                    ],
                    "template": {
                        "metadata": {
                            "labels": {"app": name, "lab": "tide-v2", "role": "offline"},
                            "annotations": {"volcano.sh/preemptable": "true"},
                        },
                        "spec": {
                            "restartPolicy": "OnFailure",
                            "priorityClassName": "tide-offline-low",
                            "terminationGracePeriodSeconds": 10,
                            "containers": [
                                {
                                    "name": "trainer",
                                    "image": REDIS_IMAGE,
                                    "imagePullPolicy": "IfNotPresent",
                                    "command": ["sh", "-c", GANG_TRAIN_SCRIPT],
                                    "env": [
                                        {"name": "JOB_NAME", "value": name},
                                        {"name": "POD_NAME", "valueFrom": {"fieldRef": {"fieldPath": "metadata.name"}}},
                                    ],
                                    "resources": {
                                        "requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                        "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"},
                                    },
                                }
                            ],
                        },
                    },
                }
            ],
        },
    }


def make_online_deploy_simple(name, replicas, min_member=None):
    ann = {"scheduling.volcano.sh/group-min-member": str(min_member)} if min_member else {}
    return {
        "apiVersion": "apps/v1",
        "kind": "Deployment",
        "metadata": {"name": name, "namespace": NS, "labels": {"lab": "tide-v2", "role": "online"}, "annotations": ann},
        "spec": {
            "replicas": replicas,
            "selector": {"matchLabels": {"app": name, "lab": "tide-v2"}},
            "template": {
                "metadata": {
                    "labels": {"app": name, "lab": "tide-v2", "role": "online"},
                    "annotations": {
                        "scheduling.volcano.sh/queue-name": "tide-online",
                        "volcano.sh/preemptable": "false",
                    },
                },
                "spec": {
                    "schedulerName": SCHED,
                    "priorityClassName": "tide-online-high",
                    "terminationGracePeriodSeconds": 3,
                    "containers": [
                        {
                            "name": "worker",
                            "image": REDIS_IMAGE,
                            "imagePullPolicy": "IfNotPresent",
                            "command": ["sh", "-c", "trap 'exit 0' TERM INT; while :; do sleep 1; done"],
                            "resources": {
                                "requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"},
                            },
                        }
                    ],
                },
            },
        },
    }


def run_exp2b_gang_reclaim():
    print("\n================ EXP 2B: 8-GPU MULTI-NODE GANG VCJOB RECLAIM (RESTARTPOD VS RESTARTJOB) ================", flush=True)
    # Cluster has 16 GPUs total.
    # Setup: online-base holds 4 GPUs, offline-filler holds 4 GPUs (or online holds 8 -> wait:
    # tide-online deserved=8, tide-offline deserved=8.
    # To make an 8-GPU Gang vcjob reclaimable by tide-online:
    # Nighttime: online-base holds 4 GPUs; offline holds 4 GPUs (filler) + 8-GPU Gang vcjob = 12 offline GPUs (12 > 8 deserved!).
    # Wait: if offline has ONLY the 12-GPU Gang vcjob OR 8-GPU Gang vcjob when online holds 4 ->
    # Wait! If tide-offline deserved=8 and offline only uses 8 GPUs, tide-offline is NOT overused (8 <= 8)!
    # Let's give offline a 12-GPU Gang vcjob (12 > 8 deserved!) OR 4-GPU filler + 8-GPU Gang vcjob ->
    # Even cleaner: a 12-GPU Multi-Node Gang vcjob (minAvailable: 12, spanning both 8-GPU nodes = 8 + 4 GPUs!) OR adjust tide-offline deserved=4 during this sub-test?
    # Better: keep the EXACT SAME queues (tide-online deserved=8, tide-offline deserved=8) and run an 8-GPU Gang vcjob PLUS a 4-GPU non-preemptable/higher-prio or just 12-GPU Gang?
    # Wait: 8-GPU Gang with 4 online base + 4 online elastic = 16 GPUs:
    # If online holds 4 at night, and offline runs a 10-GPU or 12-GPU Gang vcjob across 2 nodes (e.g., 12 ranks across 2 nodes, 8 on node1 + 4 on node2? No, online base takes 4 on node1 -> node1 has 4 free, node2 has 8 free -> 12-GPU Gang takes 4 on node1 + 8 on node2 = ALL 12 free GPUs across BOTH nodes!).
    # Let's check: 4 online-base + 12 offline Gang = 16/16 GPUs! tide-offline uses 12 > 8 deserved!
    # When online-elastic scales 0 -> 4 (needs 4 GPUs, total online = 8 <= 8 deserved!), Volcano MUST reclaim from the 12-GPU Gang vcjob!
    # WAIT: Let's use 12 ranks (`WORLD=12`)? Even simpler: let's patch `WORLD=12` in script or pass env `WORLD`!
    results = {}

    for mode, action in [("antipattern_RestartPod", "RestartPod"), ("production_RestartJob", "RestartJob")]:
        print(f"\n--- Running 2B mode: {mode} (PodEvicted -> {action}) ---", flush=True)
        clean_workloads()
        redis_flush()

        # Online base=4 GPUs, elastic=0 GPUs
        apply([
            make_online_deploy_simple("base", 4, min_member=4),
            make_online_deploy_simple("elastic", 0, min_member=4),
        ])
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            m = node_gpu_map()
            if m["worker-a"]["online"] + m["worker-b"]["online"] == 4:
                break
            time.sleep(1.5)

        # Submit 12-GPU Multi-Node Gang vcjob (spanning both nodes: 4 on nodeA + 8 on nodeB!)
        job_name = f"gang12-{action.lower()}"
        vj = make_gang_vcjob(job_name, action, replicas=12, min_avail=12)
        # Update WORLD=12 in container command (index 2 is the shell script)
        vj["spec"]["tasks"][0]["template"]["spec"]["containers"][0]["command"][2] = GANG_TRAIN_SCRIPT.replace("WORLD=8", "WORLD=12")
        apply(vj)

        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            m = node_gpu_map()
            epoch = int(redis_cmd("GET", f"gang:{job_name}:epoch") or 0)
            if m["worker-a"]["offline"] + m["worker-b"]["offline"] == 12 and epoch >= 2:
                break
            time.sleep(1.5)
        pre_map = node_gpu_map()
        pre_epoch = int(redis_cmd("GET", f"gang:{job_name}:epoch") or 0)
        print(f"[{mode}] Gang12 running across both nodes: { {k:(v['online'],v['offline']) for k,v in pre_map.items()} }, epoch={pre_epoch}", flush=True)

        # Trigger online burst: scale elastic 0 -> 4 (needs 4 GPUs!)
        t_burst = now_ts()
        k("-n", NS, "scale", "deploy/elastic", "--replicas=4")
        t_el4 = None
        timeline = []
        for step in range(25):
            time.sleep(1.5)
            pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
            el_run = sum(1 for p in pods if p["metadata"]["labels"].get("app") == "elastic" and p["status"].get("phase") == "Running")
            off_run = sum(1 for p in pods if p["metadata"]["labels"].get("role") == "offline" and p["status"].get("phase") == "Running" and not p["metadata"].get("deletionTimestamp"))
            off_pend = sum(1 for p in pods if p["metadata"]["labels"].get("role") == "offline" and p["status"].get("phase") == "Pending")
            ep = int(redis_cmd("GET", f"gang:{job_name}:epoch") or 0)
            vj_status = kjson("-n", NS, "get", "vcjob", job_name).get("status", {}).get("state", {}).get("phase", "")
            rec = {"t_plus": round(now_ts() - t_burst, 2), "elastic_running": el_run, "gang_running": off_run, "gang_pending": off_pend, "epoch": ep, "vcjob_phase": vj_status}
            timeline.append(rec)
            if el_run == 4 and t_el4 is None:
                t_el4 = rec["t_plus"]
                print(f"[{mode}] All 4 elastic pods Running at t+{t_el4}s! gang_running={off_run}, gang_pending={off_pend}, epoch={ep}, vcjob={vj_status}", flush=True)
            if t_el4 is not None and (rec["t_plus"] - t_el4) >= 12.0:
                break

        during_burst = timeline[-1]
        print(f"[{mode}] Steady state during burst (+12s after elastic Ready): {during_burst}", flush=True)

        # Scale elastic back 4 -> 0 and see if Gang vcjob resumes to epoch 10!
        t_release = now_ts()
        k("-n", NS, "scale", "deploy/elastic", "--replicas=0")
        completed = False
        t_resume_done = None
        if action == "RestartJob":
            deadline = time.monotonic() + 140
            while time.monotonic() < deadline:
                ep = int(redis_cmd("GET", f"gang:{job_name}:epoch") or 0)
                if ep >= 10:
                    completed = True
                    t_resume_done = round(now_ts() - t_release, 2)
                    break
                time.sleep(1.5)
        else:
            # Wait 15s to check final epoch
            time.sleep(15)
        final_epoch = int(redis_cmd("GET", f"gang:{job_name}:epoch") or 0)
        ckpt_log = k("-n", NS, "exec", "deploy/tide-redis", "--", "redis-cli", "--raw", "LRANGE", f"gang:{job_name}:ckpt_log", "0", "-1").splitlines()
        results[mode] = {
            "action": action,
            "pre_burst_nodes": {k: {"online": v["online"], "offline": v["offline"]} for k, v in pre_map.items()},
            "pre_burst_epoch": pre_epoch,
            "elastic_4_ready_s": t_el4,
            "during_burst_steady": during_burst,
            "zombie_gpus_held_during_burst": during_burst["gang_running"],
            "epoch_stalled_during_burst": during_burst["epoch"] == pre_epoch or during_burst["epoch"] <= pre_epoch + 1,
            "resumed_to_epoch_10": completed,
            "resume_to_done_s": t_resume_done,
            "final_epoch": final_epoch,
            "ckpt_log": ckpt_log,
            "timeline": timeline,
        }
        print(f"[{mode}] DONE: zombie_gpus={during_burst['gang_running']}, final_epoch={final_epoch}, resumed={completed}", flush=True)

    (OUT_DIR / "exp2b_gang_reclaim.json").write_text(json.dumps(results, indent=2))
    return results


if __name__ == "__main__":
    run_exp2a_fragmentation()
    run_exp2b_gang_reclaim()
