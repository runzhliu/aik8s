import datetime, time, urllib.request, json, hashlib, concurrent.futures, sys
from pathlib import Path
from redis import Redis
ns="keda-tide-lab"
redis=Redis(host="127.0.0.1",port=18386,decode_responses=True,socket_timeout=3)
def endpoint(path):
    with urllib.request.urlopen("http://127.0.0.1:18387"+path,timeout=6) as f:return json.load(f)
def short(uid):return hashlib.sha256(uid.encode()).hexdigest()[:8]
def snapshot():
    suffix="/namespaces/"+ns+"/"
    paths=["/api/v1"+suffix+"pods","/apis/resource.k8s.io/v1"+suffix+"resourceclaims","/apis/apps/v1"+suffix+"deployments"]
    with concurrent.futures.ThreadPoolExecutor(3) as pool:pods,claims,deploys=list(pool.map(endpoint,paths))
    cm={o["metadata"]["ownerReferences"][0]["uid"]:o for o in claims["items"] if o["metadata"].get("ownerReferences")}
    pp={}
    roles={"base","elastic","probe","batch","resume"}
    for p in pods["items"]:
        m=p["metadata"]; role=m.get("labels",{}).get("app")
        if role not in roles:continue
        uid=m["uid"]; claim=cm.get(uid,{})
        results=claim.get("status",{}).get("allocation",{}).get("devices",{}).get("results",[])
        pp[role]={"pod":short(uid),"phase":p["status"]["phase"],"claim":short(claim["metadata"]["uid"]) if claim else None,"device":results[0]["device"] if results else None,"deleting":bool(m.get("deletionTimestamp"))}
    want=next((d["spec"]["replicas"] for d in deploys["items"] if d["metadata"]["name"]=="elastic"),0)
    q,served,committed,gate=redis.pipeline().llen("online").hvals("served").hlen("committed").get("lend").execute()
    return {"ts":round(time.time(),2),"elasticDesired":want,"queue":q,"baseServed":served.count("base"),"elasticServed":served.count("elastic"),"committed":committed,"lend":int(gate or 0),"roles":pp}
if __name__=="__main__":
    with open("samples.jsonl","a",1) as f:
        while not Path("sample.stop").exists():
            try:f.write(json.dumps(snapshot(),separators=(",",":"))+"\n")
            except Exception as e:print(e,flush=True)
            time.sleep(1)
