#!/usr/bin/env python3
"""Experiment 1: Pure declarative KEDA + Volcano multi-queue reclaim.
1A: 16-GPU (nvidia.com/gpu) multi-queue reclaim with zero custom handoff script.
1B: DRA ResourceClaim under the exact same Volcano v1.16.0 capacity+reclaim setup.
"""
import json
import time
from datetime import datetime, timedelta, timezone
from lab_common import (
    NS, OUT_DIR, REDIS_IMAGE, SCHED, apply, clean_workloads,
    get_ns_events, get_scheduler_logs, iso_utc, k, kjson,
    make_podgroup, now_ts, redis_cmd, redis_flush
)

ONLINE_SCRIPT = r"""set -eu
r() { redis-cli -h tide-redis --raw "$@"; }
STOP=0
trap 'STOP=1' TERM INT
while [ "$STOP" = 0 ]; do
  item=$(r LPOP online:todo || true)
  if [ -n "$item" ]; then
    sleep 0.45
    r HSETNX online:served "$item" "$ROLE:$POD_NAME" >/dev/null
    r HINCRBY online:by_role "$ROLE" 1 >/dev/null
  else
    sleep 0.15
  fi
done
r RPUSH online:exits "$POD_NAME:$(date -u +%s)" >/dev/null || true
"""

OFFLINE_GRACEFUL_SCRIPT = r"""set -eu
r() { redis-cli -h tide-redis --raw "$@"; }
STOP=0
trap 'STOP=1; r RPUSH offline:sigterm "$POD_NAME:$(date -u +%s)" >/dev/null || true' TERM INT
while [ "$STOP" = 0 ]; do
  item=$(r LPOP offline:todo || true)
  if [ -z "$item" ]; then
    # Check if all items are done or still empty
    done_cnt=$(r HLEN offline:done || echo 0)
    target=$(r GET offline:target || echo 0)
    if [ "$done_cnt" -ge "$target" ] && [ "$target" -gt 0 ]; then
      break
    fi
    sleep 0.3
    continue
  fi
  # Simulate batch unit work (~1.6s), finish current item cleanly even if SIGTERM arrives
  sleep 1.6
  r EVAL "redis.call('HINCRBY','offline:exec',ARGV[1],1); return redis.call('HSETNX','offline:done',ARGV[1],ARGV[2])" 0 "$item" "$POD_NAME" >/dev/null
done
r RPUSH offline:graceful_exit "$POD_NAME:$(r HLEN offline:done):$(date -u +%s)" >/dev/null || true
"""


def make_gpu_deployment(name, role, replicas, queue="tide-online", min_member=None):
    dep_ann = {}
    if min_member is not None:
        dep_ann["scheduling.volcano.sh/group-min-member"] = str(min_member)
    return {
        "apiVersion": "apps/v1",
        "kind": "Deployment",
        "metadata": {
            "name": name,
            "namespace": NS,
            "labels": {"lab": "tide-v2", "role": role},
            "annotations": dep_ann,
        },
        "spec": {
            "replicas": replicas,
            "selector": {"matchLabels": {"app": name, "lab": "tide-v2"}},
            "template": {
                "metadata": {
                    "labels": {"app": name, "lab": "tide-v2", "role": role},
                    "annotations": {
                        "scheduling.volcano.sh/queue-name": queue,
                        "volcano.sh/preemptable": "false",
                    },
                },
                "spec": {
                    "schedulerName": SCHED,
                    "priorityClassName": "tide-online-high",
                    "terminationGracePeriodSeconds": 5,
                    "containers": [
                        {
                            "name": "worker",
                            "image": REDIS_IMAGE,
                            "imagePullPolicy": "IfNotPresent",
                            "command": ["sh", "-c", ONLINE_SCRIPT],
                            "env": [
                                {"name": "ROLE", "value": role},
                                {"name": "POD_NAME", "valueFrom": {"fieldRef": {"fieldPath": "metadata.name"}}},
                            ],
                            "resources": {
                                "requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"},
                            },
                        }
                    ],
                },
            },
        },
    }


def make_gpu_offline_vcjob(name="batch-elastic", replicas=12):
    return {
        "apiVersion": "batch.volcano.sh/v1alpha1",
        "kind": "Job",
        "metadata": {
            "name": name,
            "namespace": NS,
            "labels": {"lab": "tide-v2", "role": "offline"},
        },
        "spec": {
            "minAvailable": 1,
            "schedulerName": SCHED,
            "queue": "tide-offline",
            "priorityClassName": "tide-offline-low",
            "maxRetry": 50,
            "policies": [
                {"event": "PodEvicted", "action": "RestartPod"},
                {"event": "PodFailed", "action": "RestartPod"},
            ],
            "tasks": [
                {
                    "replicas": replicas,
                    "name": "worker",
                    "policies": [
                        {"event": "PodEvicted", "action": "RestartPod"},
                        {"event": "PodFailed", "action": "RestartPod"},
                    ],
                    "template": {
                        "metadata": {
                            "labels": {"app": name, "lab": "tide-v2", "role": "offline"},
                            "annotations": {
                                "volcano.sh/preemptable": "true",
                            },
                        },
                        "spec": {
                            "restartPolicy": "OnFailure",
                            "priorityClassName": "tide-offline-low",
                            "terminationGracePeriodSeconds": 15,
                            "containers": [
                                {
                                    "name": "worker",
                                    "image": REDIS_IMAGE,
                                    "imagePullPolicy": "IfNotPresent",
                                    "command": ["sh", "-c", OFFLINE_GRACEFUL_SCRIPT],
                                    "env": [
                                        {"name": "ROLE", "value": "offline"},
                                        {"name": "POD_NAME", "valueFrom": {"fieldRef": {"fieldPath": "metadata.name"}}},
                                    ],
                                    "resources": {
                                        "requests": {"cpu": "50m", "memory": "48Mi", "nvidia.com/gpu": "1"},
                                        "limits": {"cpu": "200m", "memory": "128Mi", "nvidia.com/gpu": "1"},
                                    },
                                }
                            ],
                        },
                    },
                }
            ],
        },
    }


def make_scaled_object(end_dt):
    start_dt = end_dt - timedelta(minutes=3)
    def cron(t):
        return f"{t.minute} {t.hour} * * *"
    return {
        "apiVersion": "keda.sh/v1alpha1",
        "kind": "ScaledObject",
        "metadata": {
            "name": "tide-gpu",
            "namespace": NS,
            "labels": {"lab": "tide-v2"},
        },
        "spec": {
            "scaleTargetRef": {"name": "elastic"},
            "minReplicaCount": 0,
            "maxReplicaCount": 4,
            "pollingInterval": 3,
            "cooldownPeriod": 10,
            "advanced": {
                "horizontalPodAutoscalerConfig": {
                    "behavior": {
                        "scaleDown": {"stabilizationWindowSeconds": 0}
                    }
                }
            },
            "triggers": [
                {
                    "type": "cron",
                    "metadata": {
                        "timezone": "Etc/UTC",
                        "start": cron(start_dt),
                        "end": cron(end_dt),
                        "desiredReplicas": "4",
                    },
                },
                {
                    "type": "redis",
                    "metadata": {
                        "address": f"tide-redis.{NS}.svc.cluster.local:6379",
                        "listName": "online:todo",
                        "listLength": "10",
                        "activationListLength": "0",
                    },
                },
            ],
        },
    }


def snapshot_1a():
    ts = now_ts()
    pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
    counts = {
        "base_running": 0,
        "elastic_running": 0,
        "elastic_pending": 0,
        "offline_running": 0,
        "offline_pending": 0,
        "offline_terminating": 0,
        "offline_succeeded": 0,
        "by_node": {"worker-a": {"online": 0, "offline": 0}, "worker-b": {"online": 0, "offline": 0}},
    }
    for p in pods:
        role = p["metadata"]["labels"].get("role", "")
        phase = p["status"].get("phase", "")
        deleting = p["metadata"].get("deletionTimestamp") is not None
        node = p["spec"].get("nodeName")
        if role == "base" and phase == "Running" and not deleting:
            counts["base_running"] += 1
            if node in counts["by_node"]:
                counts["by_node"][node]["online"] += 1
        elif role == "elastic":
            if phase == "Running" and not deleting:
                counts["elastic_running"] += 1
                if node in counts["by_node"]:
                    counts["by_node"][node]["online"] += 1
            elif phase == "Pending":
                counts["elastic_pending"] += 1
        elif role == "offline":
            if deleting:
                counts["offline_terminating"] += 1
            elif phase == "Running":
                counts["offline_running"] += 1
                if node in counts["by_node"]:
                    counts["by_node"][node]["offline"] += 1
            elif phase == "Pending":
                counts["offline_pending"] += 1
            elif phase == "Succeeded":
                counts["offline_succeeded"] += 1
    try:
        dep = kjson("-n", NS, "get", "deploy", "elastic")
        elastic_desired = dep["spec"].get("replicas", 0)
    except Exception:
        elastic_desired = 0

    r_out = k("-n", NS, "exec", "deploy/tide-redis", "--", "sh", "-c",
              "redis-cli --raw LLEN online:todo; redis-cli --raw HLEN online:served; "
              "redis-cli --raw HGET online:by_role base; redis-cli --raw HGET online:by_role elastic; "
              "redis-cli --raw LLEN offline:todo; redis-cli --raw HLEN offline:done; "
              "redis-cli --raw LLEN offline:sigterm; redis-cli --raw LLEN offline:graceful_exit")
    lines = r_out.splitlines()
    def iv(i):
        try:
            return int(lines[i]) if i < len(lines) and lines[i].strip() else 0
        except ValueError:
            return 0
    return {
        "ts": round(ts, 3),
        "utc": iso_utc(ts),
        "elastic_desired": elastic_desired,
        **counts,
        "online_queue": iv(0),
        "online_served": iv(1),
        "base_served": iv(2),
        "elastic_served": iv(3),
        "offline_queue": iv(4),
        "offline_done": iv(5),
        "offline_sigterm": iv(6),
        "offline_graceful_exit": iv(7),
    }


def run_exp1a():
    print("\n================ EXP 1A: 16-GPU DECLARATIVE MULTI-QUEUE RECLAIM ================", flush=True)
    clean_workloads()
    redis_flush()

    samples_path = OUT_DIR / "exp1a_samples.jsonl"
    events_path = OUT_DIR / "exp1a_events.jsonl"
    samples_path.write_text("")
    events_path.write_text("")

    def log_sample(tag=None):
        s = snapshot_1a()
        with samples_path.open("a") as f:
            f.write(json.dumps(s) + "\n")
        if tag:
            ev = {"event": tag, **s}
            with events_path.open("a") as f:
                f.write(json.dumps(ev) + "\n")
            print(f"[{tag}] {s['utc']} base={s['base_running']} el={s['elastic_running']}/{s['elastic_desired']}(pend={s['elastic_pending']}) "
                  f"off={s['offline_running']}(pend={s['offline_pending']},term={s['offline_terminating']}) "
                  f"onQ={s['online_queue']} served={s['online_served']}(b={s['base_served']},e={s['elastic_served']}) "
                  f"offDone={s['offline_done']} sigterm={s['offline_sigterm']}", flush=True)
        return s

    def wait_for(tag, pred, timeout=180, interval=1.2):
        deadline = time.monotonic() + timeout
        last = None
        while time.monotonic() < deadline:
            last = log_sample()
            if pred(last):
                return log_sample(tag)
            time.sleep(interval)
        raise RuntimeError(f"Timeout waiting for {tag}: last={last}")

    # Seed 720 offline items so offline stays busy across daytime -> nighttime -> burst -> resume
    offline_total = 720
    redis_cmd("SET", "offline:target", offline_total)
    k("-n", NS, "exec", "deploy/tide-redis", "--", "sh", "-c",
      f"seq 1 {offline_total} | xargs -n 100 redis-cli RPUSH offline:todo >/dev/null")

    # Compute Cron window ending at next whole minute + 1 min (so ~60-90s of daytime, then automatic night!)
    now_dt = datetime.now(timezone.utc)
    end_dt = (now_dt + timedelta(seconds=75)).replace(second=0, microsecond=0)
    if (end_dt - now_dt).total_seconds() < 40:
        end_dt += timedelta(minutes=1)
    print(f"Daytime cron window ends at {end_dt.isoformat()}", flush=True)

    apply([
        make_gpu_deployment("base", "base", 4, min_member=4),
        make_gpu_deployment("elastic", "elastic", 0, min_member=4),
    ])
    apply(make_scaled_object(end_dt))
    wait_for("day_online_ready", lambda s: s["base_running"] == 4 and s["elastic_running"] == 4, timeout=120)

    # Submit 12-replica offline vcjob during daytime -> 8 should run, 4 Pending (16/16 GPUs full!)
    apply(make_gpu_offline_vcjob("batch-elastic", 12))
    wait_for("day_full_16gpu", lambda s: s["base_running"] == 4 and s["elastic_running"] == 4 and s["offline_running"] == 8 and s["offline_pending"] == 4, timeout=90)

    # Wait for Cron window to end -> KEDA scales elastic 4->0 -> offline automatically borrows the 4 freed GPUs (12 running!)
    wait_for("night_elastic_scaled_zero", lambda s: s["elastic_desired"] == 0 and s["elastic_running"] == 0, timeout=180)
    wait_for("night_offline_borrowed_12gpu", lambda s: s["offline_running"] == 12 and s["base_running"] == 4, timeout=90)
    # Let offline run at 12 GPUs for ~8 seconds to make it crystal clear on Grafana
    for _ in range(5):
        log_sample()
        time.sleep(1.5)

    # MIDNIGHT BURST: Enqueue 400 online requests!
    log_sample("burst_before_enqueue")
    k("-n", NS, "exec", "deploy/tide-redis", "--", "sh", "-c",
      "seq 1 400 | xargs -n 80 redis-cli RPUSH online:todo >/dev/null")
    log_sample("burst_enqueued")

    # Watch KEDA scale elastic 0->4 AND Volcano reclaim 4 offline pods AUTOMATICALLY!
    wait_for("keda_scaled_up", lambda s: s["elastic_desired"] == 4, timeout=45, interval=0.8)
    wait_for("volcano_reclaim_triggered", lambda s: s["offline_sigterm"] > 0 or s["offline_running"] < 12, timeout=45, interval=0.8)
    wait_for("elastic_reclaimed_first_running", lambda s: s["elastic_running"] >= 1, timeout=60, interval=0.8)
    wait_for("elastic_all_4_running", lambda s: s["elastic_running"] == 4, timeout=60, interval=0.8)
    wait_for("elastic_first_reply", lambda s: s["elastic_served"] > 0, timeout=45, interval=0.8)
    wait_for("burst_all_400_served", lambda s: s["online_served"] == 400, timeout=150, interval=1.0)

    # Wait for KEDA cooldown -> elastic scales 4->0 -> offline automatically re-borrows back up to 12 (or finishes all 720 items!)
    wait_for("post_burst_scaled_zero", lambda s: s["elastic_desired"] == 0 and s["elastic_running"] == 0, timeout=90, interval=1.0)
    wait_for("offline_all_720_done", lambda s: s["offline_done"] == offline_total, timeout=240, interval=1.2)

    # Verify zero duplicates and collect Volcano Evicted events
    exec_vals = set(k("-n", NS, "exec", "deploy/tide-redis", "--", "redis-cli", "--raw", "HVALS", "offline:exec").splitlines())
    sigterm_list = k("-n", NS, "exec", "deploy/tide-redis", "--", "redis-cli", "--raw", "LRANGE", "offline:sigterm", "0", "-1").splitlines()
    graceful_list = k("-n", NS, "exec", "deploy/tide-redis", "--", "redis-cli", "--raw", "LRANGE", "offline:graceful_exit", "0", "-1").splitlines()
    evs = get_ns_events()
    reclaim_evs = [
        {
            "pod": e["involvedObject"]["name"],
            "reason": e.get("reason"),
            "message": e.get("message"),
            "time": e.get("lastTimestamp") or e.get("eventTime"),
        }
        for e in evs
        if e.get("reason") in ("Evicted", "Preempted", "Scheduled") and "batch-elastic" in e["involvedObject"]["name"]
    ]
    summary = {
        "exp": "1A_nvidia_gpu_declarative_reclaim",
        "online_served_total": int(redis_cmd("HLEN", "online:served")),
        "base_served": int(redis_cmd("HGET", "online:by_role", "base") or 0),
        "elastic_served": int(redis_cmd("HGET", "online:by_role", "elastic") or 0),
        "offline_done_total": int(redis_cmd("HLEN", "offline:done")),
        "offline_exec_unique_counts": sorted(exec_vals),
        "offline_sigterm_records": sigterm_list,
        "offline_graceful_exits": graceful_list,
        "reclaim_events": [e for e in reclaim_evs if e["reason"] == "Evicted"],
    }
    (OUT_DIR / "exp1a_summary.json").write_text(json.dumps(summary, indent=2))
    print("EXP 1A SUMMARY:", json.dumps(summary, indent=2), flush=True)
    return summary


def run_exp1b():
    print("\n================ EXP 1B: DRA RESOURCECLAIM UNDER VOLCANO v1.16.0 RECLAIM ================", flush=True)
    clean_workloads()
    redis_flush()

    # Create a generic ResourceClaimTemplate selecting any 1 device from gpu.example.com (4 devices on node worker-a)
    rct = {
        "apiVersion": "resource.k8s.io/v1",
        "kind": "ResourceClaimTemplate",
        "metadata": {"name": "dra-gpu-any", "namespace": NS, "labels": {"lab": "tide-v2"}},
        "spec": {
            "spec": {
                "devices": {
                    "requests": [
                        {
                            "name": "gpu",
                            "exactly": {
                                "deviceClassName": "gpu.example.com",
                                "allocationMode": "ExactCount",
                                "count": 1,
                            },
                        }
                    ]
                }
            }
        },
    }
    apply(rct)

    def make_dra_deploy(name, role, replicas):
        return {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {"name": name, "namespace": NS, "labels": {"lab": "tide-v2", "role": role}},
            "spec": {
                "replicas": replicas,
                "selector": {"matchLabels": {"app": name, "lab": "tide-v2"}},
                "template": {
                    "metadata": {
                        "labels": {"app": name, "lab": "tide-v2", "role": role},
                        "annotations": {
                            "scheduling.volcano.sh/queue-name": "tide-online",
                            "volcano.sh/preemptable": "false",
                        },
                    },
                    "spec": {
                        "schedulerName": SCHED,
                        "priorityClassName": "tide-online-high",
                        "terminationGracePeriodSeconds": 5,
                        "containers": [
                            {
                                "name": "worker",
                                "image": REDIS_IMAGE,
                                "imagePullPolicy": "IfNotPresent",
                                "command": ["sh", "-c", "trap 'exit 0' TERM INT; while :; do sleep 1; done"],
                                "resources": {
                                    "requests": {"cpu": "50m", "memory": "48Mi"},
                                    "claims": [{"name": "gpu"}],
                                },
                            }
                        ],
                        "resourceClaims": [{"name": "gpu", "resourceClaimTemplateName": "dra-gpu-any"}],
                    },
                },
            },
        }

    def make_dra_offline_vcjob(name="dra-batch", replicas=3):
        return {
            "apiVersion": "batch.volcano.sh/v1alpha1",
            "kind": "Job",
            "metadata": {"name": name, "namespace": NS, "labels": {"lab": "tide-v2", "role": "offline"}},
            "spec": {
                "minAvailable": 1,
                "schedulerName": SCHED,
                "queue": "tide-offline",
                "priorityClassName": "tide-offline-low",
                "maxRetry": 50,
                "policies": [{"event": "PodEvicted", "action": "RestartPod"}],
                "tasks": [
                    {
                        "replicas": replicas,
                        "name": "worker",
                        "policies": [{"event": "PodEvicted", "action": "RestartPod"}],
                        "template": {
                            "metadata": {
                                "labels": {"app": name, "lab": "tide-v2", "role": "offline"},
                                "annotations": {"volcano.sh/preemptable": "true"},
                            },
                            "spec": {
                                "restartPolicy": "OnFailure",
                                "priorityClassName": "tide-offline-low",
                                "terminationGracePeriodSeconds": 10,
                                "containers": [
                                    {
                                        "name": "worker",
                                        "image": REDIS_IMAGE,
                                        "imagePullPolicy": "IfNotPresent",
                                        "command": ["sh", "-c", "trap 'exit 0' TERM INT; while :; do sleep 1; done"],
                                        "resources": {
                                            "requests": {"cpu": "50m", "memory": "48Mi"},
                                            "claims": [{"name": "gpu"}],
                                        },
                                    }
                                ],
                                "resourceClaims": [{"name": "gpu", "resourceClaimTemplateName": "dra-gpu-any"}],
                            },
                        },
                    }
                ],
            },
        }

    # Nighttime state: dra-base holds 1 DRA device, dra-batch borrows 3 DRA devices (all 4 DRA devices full; tide-offline 3 > deserved 2!)
    apply([
        make_dra_deploy("dra-base", "base", 1),
        make_dra_deploy("dra-elastic", "elastic", 0),
    ])
    apply(make_dra_offline_vcjob("dra-batch", 3))

    # Wait for 1 base + 3 offline Running (4/4 DRA devices allocated!)
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
        b_run = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "base" and p["status"].get("phase") == "Running")
        o_run = sum(1 for p in pods if p["metadata"]["labels"]["role"] == "offline" and p["status"].get("phase") == "Running")
        if b_run == 1 and o_run == 3:
            break
        time.sleep(1.5)
    claims_before = kjson("-n", NS, "get", "resourceclaims")["items"]
    print(f"[1B] Night steady state: dra-base=1, dra-batch=3, claims={len(claims_before)}", flush=True)
    for c in claims_before:
        devs = [r["device"] for r in c.get("status", {}).get("allocation", {}).get("devices", {}).get("results", [])]
        print(f"  claim {c['metadata']['name']} -> {devs}", flush=True)

    # Now scale dra-elastic 0 -> 1 in tide-online (reclaimable: false, deserved: 2 DRA devices)
    t_scale = now_ts()
    k("-n", NS, "scale", "deploy/dra-elastic", "--replicas=1")
    print(f"[1B] Scaled dra-elastic to 1 at {iso_utc(t_scale)}; observing Volcano v1.16.0 reclaim behavior for 35s...", flush=True)

    timeline = []
    reclaimed = False
    for i in range(18):
        time.sleep(2.0)
        pods = kjson("-n", NS, "get", "pods", "-l", "lab=tide-v2")["items"]
        state = {p["metadata"]["name"]: (p["status"].get("phase"), p["metadata"].get("deletionTimestamp") is not None) for p in pods}
        el_running = any(p["metadata"]["labels"]["role"] == "elastic" and p["status"].get("phase") == "Running" for p in pods)
        timeline.append({"t_plus": round(now_ts() - t_scale, 2), "pods": state})
        if el_running:
            reclaimed = True
            print(f"[1B] dra-elastic BECAME RUNNING at t+{round(now_ts()-t_scale, 2)}s!", flush=True)
            break

    sched_logs = get_scheduler_logs(since="60s")
    relevant_logs = [
        line for line in sched_logs.splitlines()
        if any(tok in line for tok in ["reclaim", "Reclaim", "dra", "DRA", "dra-elastic", "dra-batch", "Predicate", "capacity", "Evict", "deserved", "deviceclass"])
    ][-80:]
    evs = [
        {"obj": e["involvedObject"]["name"], "reason": e.get("reason"), "msg": e.get("message")}
        for e in get_ns_events()
        if any(x in e["involvedObject"]["name"] for x in ["dra-elastic", "dra-batch"])
    ]
    res1b = {
        "exp": "1B_dra_resourceclaim_reclaim",
        "reclaimed_automatically": reclaimed,
        "timeline_tail": timeline[-5:],
        "events": evs,
        "scheduler_log_excerpt": relevant_logs,
    }
    (OUT_DIR / "exp1b_summary.json").write_text(json.dumps(res1b, indent=2))
    print(f"[1B] RESULT: reclaimed_automatically={reclaimed}", flush=True)
    print("[1B] Key scheduler logs:\n" + "\n".join(relevant_logs[-25:]), flush=True)
    return res1b


if __name__ == "__main__":
    run_exp1a()
    run_exp1b()
