#!/bin/bash
set -euo pipefail
r=$1
k() { kubectl "$@"; }
launch() {
  local tenant=$1 id=$2 sec=$3
  sed -e "s/name: quota-waiter, namespace: v116-team/name: $r-$id, namespace: v116-$tenant/" -e 's,queue: namespace/training,queue: v116-fair,' -e "s/sleep 18/sleep $sec/" quota-waiter.yaml > "$r-$id.yaml"
  k create -f "$r-$id.yaml"
}
launch team holder 45
k -n v116-team wait --for=jsonpath='{.status.state.phase}'=Running "vcjob/$r-holder" --timeout=75s
launch team older 18
sleep 3
launch guest newer 18
sleep 5
k -n v116-team get pod "$r-older-worker-0"; k -n v116-guest get pod "$r-newer-worker-0"
if [ "$r" = on ]; then k get --raw /api/v1/namespaces/volcano-system/services/volcano-scheduler-service:8080/proxy/metrics | awk '/^[^#]/ && /decayed_usage/ && /v116-fair/' > fair-usage.txt; fi
for key in 'team holder' 'team older' 'guest newer'; do
  read -r tenant id <<< "$key"
  k -n "v116-$tenant" wait --for=jsonpath='{.status.state.phase}'=Completed "vcjob/$r-$id" --timeout=150s
done
for key in 'team holder' 'team older' 'guest newer'; do
  read -r tenant id <<< "$key"
  k -n "v116-$tenant" get pod "$r-$id-worker-0" -o json | jq -r '[.metadata.namespace,.metadata.name,.metadata.creationTimestamp,.status.containerStatuses[0].state.terminated.startedAt,.status.containerStatuses[0].state.terminated.finishedAt]|@tsv'
done > "$r-timing.tsv"
