#!/bin/bash
set -euo pipefail
# Run only in the same disposable test cluster used to create these fixtures.
kubectl -n v116-team delete vcjob quota-holder quota-waiter cache-probe off-holder off-older on-holder on-older --ignore-not-found --wait=true
kubectl -n v116-guest delete vcjob off-newer on-newer --ignore-not-found --wait=true
for attempt in {1..20}; do
  if kubectl -n v116-team delete namespacequeue training --ignore-not-found --wait=true; then break; fi
  sleep 2
done
test -z "$(kubectl -n v116-team get namespacequeue training --ignore-not-found -o name)"
kubectl delete queue v116-fair v116-pool --ignore-not-found --wait=true
kubectl delete ns v116-team v116-guest --ignore-not-found
